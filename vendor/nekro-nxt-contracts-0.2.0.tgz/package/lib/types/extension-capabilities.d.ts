import { z } from 'zod';
/**
 * Host capability level this build implements. A Revision that declares `requires.sdk` above it is rejected at
 * import with an "upgrade NekroNXT" message instead of an opaque schema error. Bump only when a new optional
 * Manifest capability ships; never reuse a level for a different meaning.
 */
export declare const EXTENSION_SDK_LEVEL = 6;
export declare const ExtensionRequiresSchema: z.ZodObject<{
    sdk: z.ZodNumber;
}, z.core.$strict>;
export type ExtensionRequires = z.output<typeof ExtensionRequiresSchema>;
/** `api.example.com` or `*.example.com` (subdomains only); lower-case DNS labels, no scheme, port or path. */
export declare const ExtensionNetworkDomainSchema: z.ZodString;
export declare const ExtensionNetworkCapabilitySchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    mode: z.ZodLiteral<"domains">;
    domains: z.ZodArray<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    mode: z.ZodLiteral<"config">;
    fields: z.ZodArray<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    mode: z.ZodLiteral<"unrestricted">;
    purpose: z.ZodString;
}, z.core.$strict>], "mode">;
export type ExtensionNetworkCapability = z.output<typeof ExtensionNetworkCapabilitySchema>;
export declare const EXTENSION_STORAGE_SCOPES: readonly ["agent", "channel", "member", "shared"];
export declare const ExtensionStorageScopeSchema: z.ZodEnum<{
    agent: "agent";
    channel: "channel";
    member: "member";
    shared: "shared";
}>;
export type ExtensionStorageScope = z.output<typeof ExtensionStorageScopeSchema>;
export declare const EXTENSION_STORAGE_DEFAULT_QUOTA_BYTES: number;
export declare const EXTENSION_STORAGE_MAX_QUOTA_BYTES: number;
export declare const ExtensionStorageCapabilitySchema: z.ZodObject<{
    scopes: z.ZodArray<z.ZodEnum<{
        agent: "agent";
        channel: "channel";
        member: "member";
        shared: "shared";
    }>>;
    quotaBytes: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export type ExtensionStorageCapability = z.output<typeof ExtensionStorageCapabilitySchema>;
export declare const EXTENSION_CONTEXT_STATIC_MAX_CHARS = 4000;
export declare const EXTENSION_CONTEXT_DYNAMIC_MAX_CHARS = 2000;
export declare const ExtensionContextContributionSchema: z.ZodObject<{
    name: z.ZodString;
    kind: z.ZodEnum<{
        static: "static";
        dynamic: "dynamic";
    }>;
    maxChars: z.ZodNumber;
}, z.core.$strict>;
export type ExtensionContextContribution = z.output<typeof ExtensionContextContributionSchema>;
export declare const EXTENSION_LLM_MAX_CALLS_PER_TURN = 20;
export declare const EXTENSION_LLM_MAX_OUTPUT_TOKENS = 8192;
export declare const ExtensionLlmCapabilitySchema: z.ZodObject<{
    maxCallsPerTurn: z.ZodNumber;
    maxOutputTokens: z.ZodNumber;
}, z.core.$strict>;
export type ExtensionLlmCapability = z.output<typeof ExtensionLlmCapabilitySchema>;
export declare const EXTENSION_INBOUND_HOOK_MAX_TIMEOUT_MS = 15000;
export declare const ExtensionInboundHookCapabilitySchema: z.ZodObject<{
    reads: z.ZodEnum<{
        triggered: "triggered";
        all: "all";
    }>;
    mayHide: z.ZodBoolean;
    mayForceTrigger: z.ZodBoolean;
    timeoutMs: z.ZodNumber;
}, z.core.$strict>;
export type ExtensionInboundHookCapability = z.output<typeof ExtensionInboundHookCapabilitySchema>;
export declare const EXTENSION_JOB_MAX_RUNTIME = 50;
export declare const ExtensionDeclaredJobSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    cron: z.ZodString;
    timezone: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ExtensionDeclaredJob = z.output<typeof ExtensionDeclaredJobSchema>;
export declare const ExtensionJobsCapabilitySchema: z.ZodObject<{
    declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        cron: z.ZodString;
        timezone: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    runtime: z.ZodOptional<z.ZodObject<{
        maxActive: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ExtensionJobsCapability = z.output<typeof ExtensionJobsCapabilitySchema>;
export declare const ExtensionPlatformCapabilitySchema: z.ZodObject<{
    actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        adapter: z.ZodString;
        action: z.ZodString;
    }, z.core.$strict>>>;
    raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type ExtensionPlatformCapability = z.output<typeof ExtensionPlatformCapabilitySchema>;
/** A header or environment value: literal text, or the current value of a `meta.role: 'secret'` config field. */
export declare const ExtensionMcpValueSchema: z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
    secret: z.ZodString;
}, z.core.$strict>]>;
export type ExtensionMcpValue = z.output<typeof ExtensionMcpValueSchema>;
/** Becomes the model-facing tool prefix `mcp__<name>__`. */
export declare const ExtensionMcpServerNameSchema: z.ZodString;
export declare const ExtensionMcpServerSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    transport: z.ZodLiteral<"streamable-http">;
    name: z.ZodString;
    url: z.ZodString;
    headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
        secret: z.ZodString;
    }, z.core.$strict>]>>>;
}, z.core.$strict>, z.ZodObject<{
    transport: z.ZodLiteral<"stdio">;
    name: z.ZodString;
    command: z.ZodString;
    args: z.ZodDefault<z.ZodArray<z.ZodString>>;
    env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
        secret: z.ZodString;
    }, z.core.$strict>]>>>;
}, z.core.$strict>], "transport">;
export type ExtensionMcpServer = z.output<typeof ExtensionMcpServerSchema>;
/**
 * MCP servers the Host connects for the agent while the extension is enabled; their tools appear as
 * `mcp__<name>__<tool>`. `stdio` runs a program on the Host and is only created from the administrator's form.
 */
export declare const ExtensionMcpCapabilitySchema: z.ZodObject<{
    servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        transport: z.ZodLiteral<"streamable-http">;
        name: z.ZodString;
        url: z.ZodString;
        headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
            secret: z.ZodString;
        }, z.core.$strict>]>>>;
    }, z.core.$strict>, z.ZodObject<{
        transport: z.ZodLiteral<"stdio">;
        name: z.ZodString;
        command: z.ZodString;
        args: z.ZodDefault<z.ZodArray<z.ZodString>>;
        env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
            secret: z.ZodString;
        }, z.core.$strict>]>>>;
    }, z.core.$strict>], "transport">>;
}, z.core.$strict>;
export type ExtensionMcpCapability = z.output<typeof ExtensionMcpCapabilitySchema>;
export declare const McpServerFormSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    transport: z.ZodLiteral<"streamable-http">;
    name: z.ZodString;
    url: z.ZodString;
    headers: z.ZodDefault<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        value: z.ZodString;
        secret: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>>;
}, z.core.$strict>, z.ZodObject<{
    transport: z.ZodLiteral<"stdio">;
    name: z.ZodString;
    command: z.ZodString;
    args: z.ZodDefault<z.ZodArray<z.ZodString>>;
    env: z.ZodDefault<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        value: z.ZodString;
        secret: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>>;
}, z.core.$strict>], "transport">;
export type McpServerForm = z.output<typeof McpServerFormSchema>;
/** Secret config fields an MCP declaration reads. */
export declare const mcpSecretFields: (mcp: ExtensionMcpCapability | undefined) => readonly string[];
/**
 * Optional Host capabilities of an agent-scope Revision. Every field is additive to Manifest V6: an absent field
 * means the Revision cannot use that capability, exactly as before the field existed.
 */
export declare const ExtensionCapabilitiesSchema: z.ZodObject<{
    network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"domains">;
        domains: z.ZodArray<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"config">;
        fields: z.ZodArray<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"unrestricted">;
        purpose: z.ZodString;
    }, z.core.$strict>], "mode">>;
    storage: z.ZodOptional<z.ZodObject<{
        scopes: z.ZodArray<z.ZodEnum<{
            agent: "agent";
            channel: "channel";
            member: "member";
            shared: "shared";
        }>>;
        quotaBytes: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    assets: z.ZodOptional<z.ZodObject<{
        write: z.ZodLiteral<true>;
    }, z.core.$strict>>;
    history: z.ZodOptional<z.ZodObject<{
        read: z.ZodLiteral<true>;
    }, z.core.$strict>>;
    inboundHook: z.ZodOptional<z.ZodObject<{
        reads: z.ZodEnum<{
            triggered: "triggered";
            all: "all";
        }>;
        mayHide: z.ZodBoolean;
        mayForceTrigger: z.ZodBoolean;
        timeoutMs: z.ZodNumber;
    }, z.core.$strict>>;
    jobs: z.ZodOptional<z.ZodObject<{
        declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            cron: z.ZodString;
            timezone: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        runtime: z.ZodOptional<z.ZodObject<{
            maxActive: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    platform: z.ZodOptional<z.ZodObject<{
        actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
            adapter: z.ZodString;
            action: z.ZodString;
        }, z.core.$strict>>>;
        raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    llm: z.ZodOptional<z.ZodObject<{
        maxCallsPerTurn: z.ZodNumber;
        maxOutputTokens: z.ZodNumber;
    }, z.core.$strict>>;
    mcp: z.ZodOptional<z.ZodObject<{
        servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            transport: z.ZodLiteral<"streamable-http">;
            name: z.ZodString;
            url: z.ZodString;
            headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                secret: z.ZodString;
            }, z.core.$strict>]>>>;
        }, z.core.$strict>, z.ZodObject<{
            transport: z.ZodLiteral<"stdio">;
            name: z.ZodString;
            command: z.ZodString;
            args: z.ZodDefault<z.ZodArray<z.ZodString>>;
            env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                secret: z.ZodString;
            }, z.core.$strict>]>>>;
        }, z.core.$strict>], "transport">>;
    }, z.core.$strict>>;
    context: z.ZodOptional<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        kind: z.ZodEnum<{
            static: "static";
            dynamic: "dynamic";
        }>;
        maxChars: z.ZodNumber;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type ExtensionCapabilities = z.output<typeof ExtensionCapabilitiesSchema>;
/**
 * Whether `next` asks for something an approval of `previous` did not cover. Narrowing never needs approval;
 * storage quota is bounded by the Host maximum and is not an expansion. Context contributions are capped text
 * shown in the trace, so adding one is not an expansion either.
 */
export declare const extensionCapabilitiesExpand: (previous: ExtensionCapabilities | undefined, next: ExtensionCapabilities | undefined) => boolean;
/** Capability risk tiers shown on the approval page (§7 of the capability decision). */
export type ExtensionCapabilityRisk = 'normal' | 'sensitive' | 'high';
export interface ExtensionCapabilitySummaryItem {
    readonly key: string;
    readonly risk: ExtensionCapabilityRisk;
    readonly label: string;
    readonly detail?: string;
}
/** User-facing summary of declared capabilities, in a stable order, for approval and inspection pages. */
export declare const summarizeExtensionCapabilities: (capabilities: ExtensionCapabilities | undefined) => readonly ExtensionCapabilitySummaryItem[];
//# sourceMappingURL=extension-capabilities.d.ts.map