import { z } from 'zod';
export declare const HostUiPermissionSchema: z.ZodEnum<{
    "agents.read": "agents.read";
    "channels.read": "channels.read";
    "connections.read": "connections.read";
    "extensions.read": "extensions.read";
    "dsh-plugins.read": "dsh-plugins.read";
    "runtime.read": "runtime.read";
    "messages.read": "messages.read";
    "assets.read": "assets.read";
    "agents.manage": "agents.manage";
    "channels.manage": "channels.manage";
    "connections.manage": "connections.manage";
    "credentials.write": "credentials.write";
    "messages.send": "messages.send";
    "notifications.publish": "notifications.publish";
    "network.request": "network.request";
}>;
export type HostUiPermission = z.output<typeof HostUiPermissionSchema>;
export declare const HOST_UI_KIT_COMPONENT_NAMES: readonly ["Button", "IconButton", "Input", "Textarea", "Select", "Switch", "Tabs", "Dialog", "Popover", "Tooltip", "Field", "StatusBadge", "InlineFeedback", "EmptyState", "Spinner", "PageHeader", "MetricStrip", "Metric", "Section", "Stack", "Grid", "DataTable", "PropertyList", "PropertyRow"];
export declare const HostUiKitComponentNameSchema: z.ZodEnum<{
    Button: "Button";
    IconButton: "IconButton";
    Input: "Input";
    Textarea: "Textarea";
    Select: "Select";
    Switch: "Switch";
    Tabs: "Tabs";
    Dialog: "Dialog";
    Popover: "Popover";
    Tooltip: "Tooltip";
    Field: "Field";
    StatusBadge: "StatusBadge";
    InlineFeedback: "InlineFeedback";
    EmptyState: "EmptyState";
    Spinner: "Spinner";
    PageHeader: "PageHeader";
    MetricStrip: "MetricStrip";
    Metric: "Metric";
    Section: "Section";
    Stack: "Stack";
    Grid: "Grid";
    DataTable: "DataTable";
    PropertyList: "PropertyList";
    PropertyRow: "PropertyRow";
}>;
export type HostUiKitComponentName = z.output<typeof HostUiKitComponentNameSchema>;
export declare const HostUiPageGeometryEvidenceSchema: z.ZodObject<{
    entryId: z.ZodString;
    objectPane: z.ZodEnum<{
        hidden: "hidden";
        navigation: "navigation";
    }>;
    viewport: z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strict>;
    insets: z.ZodObject<{
        top: z.ZodNumber;
        right: z.ZodNumber;
        bottom: z.ZodNumber;
        left: z.ZodNumber;
    }, z.core.$strict>;
    contentAxesAligned: z.ZodBoolean;
    horizontalOverflow: z.ZodBoolean;
    titleDistinct: z.ZodBoolean;
}, z.core.$strict>;
export type HostUiPageGeometryEvidence = z.output<typeof HostUiPageGeometryEvidenceSchema>;
export declare const HostIconNameSchema: z.ZodEnum<{
    "app-window": "app-window";
    "bar-chart": "bar-chart";
    "book-open": "book-open";
    boxes: "boxes";
    database: "database";
    "file-text": "file-text";
    folder: "folder";
    globe: "globe";
    "layout-dashboard": "layout-dashboard";
    puzzle: "puzzle";
    terminal: "terminal";
    workflow: "workflow";
    wrench: "wrench";
}>;
export type HostIconName = z.output<typeof HostIconNameSchema>;
export declare const HostPageIconSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"host-icon">;
    name: z.ZodEnum<{
        "app-window": "app-window";
        "bar-chart": "bar-chart";
        "book-open": "book-open";
        boxes: "boxes";
        database: "database";
        "file-text": "file-text";
        folder: "folder";
        globe: "globe";
        "layout-dashboard": "layout-dashboard";
        puzzle: "puzzle";
        terminal: "terminal";
        workflow: "workflow";
        wrench: "wrench";
    }>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"svg">;
    path: z.ZodString;
    sha256: z.ZodString;
}, z.core.$strict>], "kind">;
export type HostPageIcon = z.output<typeof HostPageIconSchema>;
export declare const HostPageContributionSchema: z.ZodObject<{
    kind: z.ZodLiteral<"host-page">;
    entryId: z.ZodString;
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"host-icon">;
        name: z.ZodEnum<{
            "app-window": "app-window";
            "bar-chart": "bar-chart";
            "book-open": "book-open";
            boxes: "boxes";
            database: "database";
            "file-text": "file-text";
            folder: "folder";
            globe: "globe";
            "layout-dashboard": "layout-dashboard";
            puzzle: "puzzle";
            terminal: "terminal";
            workflow: "workflow";
            wrench: "wrench";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"svg">;
        path: z.ZodString;
        sha256: z.ZodString;
    }, z.core.$strict>], "kind">;
    objectPane: z.ZodEnum<{
        hidden: "hidden";
        navigation: "navigation";
    }>;
    startPath: z.ZodString;
}, z.core.$strict>;
export type HostPageContribution = z.output<typeof HostPageContributionSchema>;
export declare const HostUiNavigationItemSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    icon: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"host-icon">;
        name: z.ZodEnum<{
            "app-window": "app-window";
            "bar-chart": "bar-chart";
            "book-open": "book-open";
            boxes: "boxes";
            database: "database";
            "file-text": "file-text";
            folder: "folder";
            globe: "globe";
            "layout-dashboard": "layout-dashboard";
            puzzle: "puzzle";
            terminal: "terminal";
            workflow: "workflow";
            wrench: "wrench";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"svg">;
        path: z.ZodString;
        sha256: z.ZodString;
    }, z.core.$strict>], "kind">>;
    badge: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodEnum<{
        error: "error";
        success: "success";
        warning: "warning";
        info: "info";
        neutral: "neutral";
    }>>;
    disabledReason: z.ZodOptional<z.ZodString>;
    path: z.ZodString;
}, z.core.$strict>;
export declare const HostUiNavigationGroupSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodOptional<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        icon: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"host-icon">;
            name: z.ZodEnum<{
                "app-window": "app-window";
                "bar-chart": "bar-chart";
                "book-open": "book-open";
                boxes: "boxes";
                database: "database";
                "file-text": "file-text";
                folder: "folder";
                globe: "globe";
                "layout-dashboard": "layout-dashboard";
                puzzle: "puzzle";
                terminal: "terminal";
                workflow: "workflow";
                wrench: "wrench";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"svg">;
            path: z.ZodString;
            sha256: z.ZodString;
        }, z.core.$strict>], "kind">>;
        badge: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<{
            error: "error";
            success: "success";
            warning: "warning";
            info: "info";
            neutral: "neutral";
        }>>;
        disabledReason: z.ZodOptional<z.ZodString>;
        path: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const HostUiNavigationModelSchema: z.ZodObject<{
    revision: z.ZodNumber;
    groups: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            icon: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"host-icon">;
                name: z.ZodEnum<{
                    "app-window": "app-window";
                    "bar-chart": "bar-chart";
                    "book-open": "book-open";
                    boxes: "boxes";
                    database: "database";
                    "file-text": "file-text";
                    folder: "folder";
                    globe: "globe";
                    "layout-dashboard": "layout-dashboard";
                    puzzle: "puzzle";
                    terminal: "terminal";
                    workflow: "workflow";
                    wrench: "wrench";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"svg">;
                path: z.ZodString;
                sha256: z.ZodString;
            }, z.core.$strict>], "kind">>;
            badge: z.ZodOptional<z.ZodString>;
            status: z.ZodOptional<z.ZodEnum<{
                error: "error";
                success: "success";
                warning: "warning";
                info: "info";
                neutral: "neutral";
            }>>;
            disabledReason: z.ZodOptional<z.ZodString>;
            path: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type HostUiNavigationModel = z.output<typeof HostUiNavigationModelSchema>;
export declare const HostUiNetworkOriginSchema: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
export declare const HostUiPermissionDeclarationSchema: z.ZodObject<{
    permissions: z.ZodArray<z.ZodEnum<{
        "agents.read": "agents.read";
        "channels.read": "channels.read";
        "connections.read": "connections.read";
        "extensions.read": "extensions.read";
        "dsh-plugins.read": "dsh-plugins.read";
        "runtime.read": "runtime.read";
        "messages.read": "messages.read";
        "assets.read": "assets.read";
        "agents.manage": "agents.manage";
        "channels.manage": "channels.manage";
        "connections.manage": "connections.manage";
        "credentials.write": "credentials.write";
        "messages.send": "messages.send";
        "notifications.publish": "notifications.publish";
        "network.request": "network.request";
    }>>;
    networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
    capabilities: z.ZodOptional<z.ZodObject<{
        network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
            mode: z.ZodLiteral<"domains">;
            domains: z.ZodArray<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            mode: z.ZodLiteral<"config">;
            fields: z.ZodArray<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            mode: z.ZodLiteral<"unrestricted">;
            purpose: z.ZodString;
        }, z.core.$strict>], "mode">>;
        storage: z.ZodOptional<z.ZodObject<{
            scopes: z.ZodArray<z.ZodEnum<{
                agent: "agent";
                channel: "channel";
                member: "member";
                shared: "shared";
            }>>;
            quotaBytes: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        assets: z.ZodOptional<z.ZodObject<{
            write: z.ZodLiteral<true>;
        }, z.core.$strict>>;
        history: z.ZodOptional<z.ZodObject<{
            read: z.ZodLiteral<true>;
        }, z.core.$strict>>;
        inboundHook: z.ZodOptional<z.ZodObject<{
            reads: z.ZodEnum<{
                triggered: "triggered";
                all: "all";
            }>;
            mayHide: z.ZodBoolean;
            mayForceTrigger: z.ZodBoolean;
            timeoutMs: z.ZodNumber;
        }, z.core.$strict>>;
        jobs: z.ZodOptional<z.ZodObject<{
            declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                label: z.ZodString;
                cron: z.ZodString;
                timezone: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            runtime: z.ZodOptional<z.ZodObject<{
                maxActive: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        platform: z.ZodOptional<z.ZodObject<{
            actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                adapter: z.ZodString;
                action: z.ZodString;
            }, z.core.$strict>>>;
            raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        llm: z.ZodOptional<z.ZodObject<{
            maxCallsPerTurn: z.ZodNumber;
            maxOutputTokens: z.ZodNumber;
        }, z.core.$strict>>;
        mcp: z.ZodOptional<z.ZodObject<{
            servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                transport: z.ZodLiteral<"streamable-http">;
                name: z.ZodString;
                url: z.ZodString;
                headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                    secret: z.ZodString;
                }, z.core.$strict>]>>>;
            }, z.core.$strict>, z.ZodObject<{
                transport: z.ZodLiteral<"stdio">;
                name: z.ZodString;
                command: z.ZodString;
                args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                    secret: z.ZodString;
                }, z.core.$strict>]>>>;
            }, z.core.$strict>], "transport">>;
        }, z.core.$strict>>;
        context: z.ZodOptional<z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            kind: z.ZodEnum<{
                static: "static";
                dynamic: "dynamic";
            }>;
            maxChars: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type HostUiPermissionDeclaration = z.output<typeof HostUiPermissionDeclarationSchema>;
export declare const HostUiOwnerSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"extension">;
    extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"dsh-plugin">;
    entryId: z.ZodString;
    artifactDigest: z.ZodString;
}, z.core.$strict>], "kind">;
export type HostUiOwner = z.output<typeof HostUiOwnerSchema>;
export declare const HostUiPageEntrySchema: z.ZodObject<{
    pageInstanceId: z.core.$ZodBranded<z.ZodString, "HostUiPageInstanceId", "out">;
    owner: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"extension">;
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"dsh-plugin">;
        entryId: z.ZodString;
        artifactDigest: z.ZodString;
    }, z.core.$strict>], "kind">;
    entryId: z.ZodString;
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"host-icon">;
        name: z.ZodEnum<{
            "app-window": "app-window";
            "bar-chart": "bar-chart";
            "book-open": "book-open";
            boxes: "boxes";
            database: "database";
            "file-text": "file-text";
            folder: "folder";
            globe: "globe";
            "layout-dashboard": "layout-dashboard";
            puzzle: "puzzle";
            terminal: "terminal";
            workflow: "workflow";
            wrench: "wrench";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"svg">;
        path: z.ZodString;
        sha256: z.ZodString;
    }, z.core.$strict>], "kind">;
    objectPane: z.ZodEnum<{
        hidden: "hidden";
        navigation: "navigation";
    }>;
    startPath: z.ZodString;
    visible: z.ZodBoolean;
    sortOrder: z.ZodNumber;
    routeBase: z.ZodString;
    client: z.ZodObject<{
        moduleUrl: z.ZodString;
        buildKey: z.ZodString;
    }, z.core.$strict>;
    diagnostic: z.ZodOptional<z.ZodObject<{
        status: z.ZodEnum<{
            "restore-failed": "restore-failed";
            ready: "ready";
            "load-failed": "load-failed";
            "navigation-failed": "navigation-failed";
            "rpc-failed": "rpc-failed";
        }>;
        message: z.ZodOptional<z.ZodString>;
        observedAt: z.ZodNumber;
    }, z.core.$strict>>;
    createdAt: z.ZodNumber;
    updatedAt: z.ZodNumber;
}, z.core.$strict>;
export type HostUiPageEntry = z.output<typeof HostUiPageEntrySchema>;
export declare const HostUiPagePreferencesSchema: z.ZodObject<{
    revision: z.ZodNumber;
    entries: z.ZodArray<z.ZodObject<{
        pageInstanceId: z.core.$ZodBranded<z.ZodString, "HostUiPageInstanceId", "out">;
        visible: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type HostUiPagePreferences = z.output<typeof HostUiPagePreferencesSchema>;
export declare const DshNxtHostUiSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    entryKey: z.ZodString;
    client: z.ZodString;
    css: z.ZodOptional<z.ZodString>;
    pages: z.ZodArray<z.ZodObject<{
        kind: z.ZodLiteral<"host-page">;
        entryId: z.ZodString;
        title: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"host-icon">;
            name: z.ZodEnum<{
                "app-window": "app-window";
                "bar-chart": "bar-chart";
                "book-open": "book-open";
                boxes: "boxes";
                database: "database";
                "file-text": "file-text";
                folder: "folder";
                globe: "globe";
                "layout-dashboard": "layout-dashboard";
                puzzle: "puzzle";
                terminal: "terminal";
                workflow: "workflow";
                wrench: "wrench";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"svg">;
            path: z.ZodString;
            sha256: z.ZodString;
        }, z.core.$strict>], "kind">;
        objectPane: z.ZodEnum<{
            hidden: "hidden";
            navigation: "navigation";
        }>;
        startPath: z.ZodString;
    }, z.core.$strict>>;
    permissions: z.ZodDefault<z.ZodObject<{
        permissions: z.ZodArray<z.ZodEnum<{
            "agents.read": "agents.read";
            "channels.read": "channels.read";
            "connections.read": "connections.read";
            "extensions.read": "extensions.read";
            "dsh-plugins.read": "dsh-plugins.read";
            "runtime.read": "runtime.read";
            "messages.read": "messages.read";
            "assets.read": "assets.read";
            "agents.manage": "agents.manage";
            "channels.manage": "channels.manage";
            "connections.manage": "connections.manage";
            "credentials.write": "credentials.write";
            "messages.send": "messages.send";
            "notifications.publish": "notifications.publish";
            "network.request": "network.request";
        }>>;
        networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
        capabilities: z.ZodOptional<z.ZodObject<{
            network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                mode: z.ZodLiteral<"domains">;
                domains: z.ZodArray<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                mode: z.ZodLiteral<"config">;
                fields: z.ZodArray<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                mode: z.ZodLiteral<"unrestricted">;
                purpose: z.ZodString;
            }, z.core.$strict>], "mode">>;
            storage: z.ZodOptional<z.ZodObject<{
                scopes: z.ZodArray<z.ZodEnum<{
                    agent: "agent";
                    channel: "channel";
                    member: "member";
                    shared: "shared";
                }>>;
                quotaBytes: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            assets: z.ZodOptional<z.ZodObject<{
                write: z.ZodLiteral<true>;
            }, z.core.$strict>>;
            history: z.ZodOptional<z.ZodObject<{
                read: z.ZodLiteral<true>;
            }, z.core.$strict>>;
            inboundHook: z.ZodOptional<z.ZodObject<{
                reads: z.ZodEnum<{
                    triggered: "triggered";
                    all: "all";
                }>;
                mayHide: z.ZodBoolean;
                mayForceTrigger: z.ZodBoolean;
                timeoutMs: z.ZodNumber;
            }, z.core.$strict>>;
            jobs: z.ZodOptional<z.ZodObject<{
                declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    label: z.ZodString;
                    cron: z.ZodString;
                    timezone: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                runtime: z.ZodOptional<z.ZodObject<{
                    maxActive: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            platform: z.ZodOptional<z.ZodObject<{
                actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    adapter: z.ZodString;
                    action: z.ZodString;
                }, z.core.$strict>>>;
                raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            llm: z.ZodOptional<z.ZodObject<{
                maxCallsPerTurn: z.ZodNumber;
                maxOutputTokens: z.ZodNumber;
            }, z.core.$strict>>;
            mcp: z.ZodOptional<z.ZodObject<{
                servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    transport: z.ZodLiteral<"streamable-http">;
                    name: z.ZodString;
                    url: z.ZodString;
                    headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                        secret: z.ZodString;
                    }, z.core.$strict>]>>>;
                }, z.core.$strict>, z.ZodObject<{
                    transport: z.ZodLiteral<"stdio">;
                    name: z.ZodString;
                    command: z.ZodString;
                    args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                        secret: z.ZodString;
                    }, z.core.$strict>]>>>;
                }, z.core.$strict>], "transport">>;
            }, z.core.$strict>>;
            context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                kind: z.ZodEnum<{
                    static: "static";
                    dynamic: "dynamic";
                }>;
                maxChars: z.ZodNumber;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DshNxtHostUi = z.output<typeof DshNxtHostUiSchema>;
/** Where the product shell may place an extension panel. The Host decides the concrete page and position. */
export declare const ExtensionPanelAnchorSchema: z.ZodEnum<{
    agent: "agent";
    channel: "channel";
    extension: "extension";
    connection: "connection";
}>;
export type ExtensionPanelAnchor = z.output<typeof ExtensionPanelAnchorSchema>;
export declare const AGENT_PANEL_ANCHORS: readonly ["agent", "channel", "extension"];
export declare const ADAPTER_PANEL_ANCHORS: readonly ["connection", "channel"];
export declare const PanelDensitySchema: z.ZodEnum<{
    compact: "compact";
    full: "full";
}>;
export type PanelDensity = z.output<typeof PanelDensitySchema>;
export declare const ConnectionPanelRoleSchema: z.ZodEnum<{
    diagnostics: "diagnostics";
    status: "status";
    setup: "setup";
}>;
export type ConnectionPanelRole = z.output<typeof ConnectionPanelRoleSchema>;
export declare const ToolViewDensitySchema: z.ZodEnum<{
    chip: "chip";
    card: "card";
}>;
export type ToolViewDensity = z.output<typeof ToolViewDensitySchema>;
/** Client-side registration options for one panel; identical to the Manifest contribution without `kind`. */
export declare const ExtensionPanelDeclarationSchema: z.ZodObject<{
    id: z.ZodString;
    anchor: z.ZodEnum<{
        agent: "agent";
        channel: "channel";
        extension: "extension";
        connection: "connection";
    }>;
    title: z.ZodString;
    icon: z.ZodOptional<z.ZodEnum<{
        "app-window": "app-window";
        "bar-chart": "bar-chart";
        "book-open": "book-open";
        boxes: "boxes";
        database: "database";
        "file-text": "file-text";
        folder: "folder";
        globe: "globe";
        "layout-dashboard": "layout-dashboard";
        puzzle: "puzzle";
        terminal: "terminal";
        workflow: "workflow";
        wrench: "wrench";
    }>>;
    densities: z.ZodArray<z.ZodEnum<{
        compact: "compact";
        full: "full";
    }>>;
    role: z.ZodOptional<z.ZodEnum<{
        diagnostics: "diagnostics";
        status: "status";
        setup: "setup";
    }>>;
    when: z.ZodOptional<z.ZodObject<{
        channelKinds: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            internal: "internal";
            direct: "direct";
            group: "group";
        }>>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ExtensionPanelDeclaration = z.output<typeof ExtensionPanelDeclarationSchema>;
export declare const PanelContributionSchema: z.ZodObject<{
    id: z.ZodString;
    anchor: z.ZodEnum<{
        agent: "agent";
        channel: "channel";
        extension: "extension";
        connection: "connection";
    }>;
    title: z.ZodString;
    icon: z.ZodOptional<z.ZodEnum<{
        "app-window": "app-window";
        "bar-chart": "bar-chart";
        "book-open": "book-open";
        boxes: "boxes";
        database: "database";
        "file-text": "file-text";
        folder: "folder";
        globe: "globe";
        "layout-dashboard": "layout-dashboard";
        puzzle: "puzzle";
        terminal: "terminal";
        workflow: "workflow";
        wrench: "wrench";
    }>>;
    densities: z.ZodArray<z.ZodEnum<{
        compact: "compact";
        full: "full";
    }>>;
    role: z.ZodOptional<z.ZodEnum<{
        diagnostics: "diagnostics";
        status: "status";
        setup: "setup";
    }>>;
    when: z.ZodOptional<z.ZodObject<{
        channelKinds: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            internal: "internal";
            direct: "direct";
            group: "group";
        }>>>;
    }, z.core.$strict>>;
    kind: z.ZodLiteral<"panel">;
}, z.core.$strict>;
export type PanelContribution = z.output<typeof PanelContributionSchema>;
export declare const ToolViewContributionSchema: z.ZodObject<{
    kind: z.ZodLiteral<"tool-view">;
    tool: z.ZodString;
}, z.core.$strict>;
export type ToolViewContribution = z.output<typeof ToolViewContributionSchema>;
export declare const RichKindSchema: z.ZodString;
export declare const MessageRendererContributionSchema: z.ZodObject<{
    kind: z.ZodLiteral<"message-renderer">;
    richKind: z.ZodString;
}, z.core.$strict>;
export type MessageRendererContribution = z.output<typeof MessageRendererContributionSchema>;
/** Optional configuration surface shared by every extension scope. */
export declare const ExtensionConfigDeclarationSchema: z.ZodObject<{
    schema: z.ZodType<import("./config-schema.js").ConfigSchemaNode, unknown, z.core.$ZodTypeInternals<import("./config-schema.js").ConfigSchemaNode, unknown>> & z.ZodType<{
        readonly type: "object";
        readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
        readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
    }, unknown, z.core.$ZodTypeInternals<{
        readonly type: "object";
        readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
        readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
    }, unknown>>;
}, z.core.$strict>;
export type ExtensionConfigDeclaration = z.output<typeof ExtensionConfigDeclarationSchema>;
/** Product projection of what one Revision contributes to the shell. */
export declare const ExtensionUiContributionsSchema: z.ZodObject<{
    panels: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        anchor: z.ZodEnum<{
            agent: "agent";
            channel: "channel";
            extension: "extension";
            connection: "connection";
        }>;
        title: z.ZodString;
        icon: z.ZodOptional<z.ZodEnum<{
            "app-window": "app-window";
            "bar-chart": "bar-chart";
            "book-open": "book-open";
            boxes: "boxes";
            database: "database";
            "file-text": "file-text";
            folder: "folder";
            globe: "globe";
            "layout-dashboard": "layout-dashboard";
            puzzle: "puzzle";
            terminal: "terminal";
            workflow: "workflow";
            wrench: "wrench";
        }>>;
        densities: z.ZodArray<z.ZodEnum<{
            compact: "compact";
            full: "full";
        }>>;
        role: z.ZodOptional<z.ZodEnum<{
            diagnostics: "diagnostics";
            status: "status";
            setup: "setup";
        }>>;
        when: z.ZodOptional<z.ZodObject<{
            channelKinds: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                internal: "internal";
                direct: "direct";
                group: "group";
            }>>>;
        }, z.core.$strict>>;
        kind: z.ZodLiteral<"panel">;
    }, z.core.$strict>>;
    toolViews: z.ZodArray<z.ZodString>;
    messageRenderers: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export type ExtensionUiContributions = z.output<typeof ExtensionUiContributionsSchema>;
export declare const EMPTY_EXTENSION_UI_CONTRIBUTIONS: ExtensionUiContributions;
/** Read permission each Client data hook requires; the host enforces it in every runtime that renders a Client. */
export declare const EXTENSION_DATA_HOOK_PERMISSIONS: {
    readonly useAgent: "agents.read";
    readonly useChannel: "channels.read";
    readonly useConnection: "connections.read";
    readonly useChannelRuntime: "runtime.read";
};
export type ExtensionDataHookName = keyof typeof EXTENSION_DATA_HOOK_PERMISSIONS;
//# sourceMappingURL=extension-ui.d.ts.map