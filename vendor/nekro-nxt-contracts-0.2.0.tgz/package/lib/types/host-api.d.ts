import { z } from 'zod';
export declare const HostApiErrorSchema: z.ZodObject<{
    error: z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const ImageUnderstandingPolicyApiSchema: z.ZodObject<{
    history: z.ZodObject<{
        mode: z.ZodLiteral<"persistent-distinct">;
        detail: z.ZodEnum<{
            high: "high";
            low: "low";
            auto: "auto";
        }>;
        restoreAfterCompaction: z.ZodObject<{
            recentMessages: z.ZodNumber;
            maxImages: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>;
    textModel: z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"disabled">;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"auxiliary">;
        model: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            reasoningEffort: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        maxTokens: z.ZodNumber;
    }, z.core.$strict>], "mode">;
}, z.core.$strict>;
export declare const DynamicClientApprovalPolicySchema: z.ZodEnum<{
    manual: "manual";
    automatic: "automatic";
}>;
export declare const NotificationEventKeySchema: z.ZodEnum<{
    "dynamic-client-approval-requested": "dynamic-client-approval-requested";
}>;
export type NotificationEventKey = z.output<typeof NotificationEventKeySchema>;
export declare const NotificationSettingsViewSchema: z.ZodObject<{
    revision: z.ZodOptional<z.ZodNumber>;
    system: z.ZodObject<{
        enabled: z.ZodBoolean;
    }, z.core.$strict>;
    bark: z.ZodObject<{
        enabled: z.ZodBoolean;
        serverUrl: z.ZodURL;
        deviceKeyConfigured: z.ZodBoolean;
    }, z.core.$strict>;
    events: z.ZodRecord<z.ZodEnum<{
        "dynamic-client-approval-requested": "dynamic-client-approval-requested";
    }>, z.ZodBoolean>;
}, z.core.$strict>;
export declare const UpdateNotificationSettingsRequestSchema: z.ZodObject<{
    expectedRevision: z.ZodOptional<z.ZodNumber>;
    system: z.ZodObject<{
        enabled: z.ZodBoolean;
    }, z.core.$strict>;
    bark: z.ZodObject<{
        enabled: z.ZodBoolean;
        serverUrl: z.ZodURL;
        deviceKey: z.ZodOptional<z.ZodString>;
        clearDeviceKey: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>;
    events: z.ZodRecord<z.ZodEnum<{
        "dynamic-client-approval-requested": "dynamic-client-approval-requested";
    }>, z.ZodBoolean>;
}, z.core.$strict>;
export declare const TestBarkNotificationRequestSchema: z.ZodObject<{
    serverUrl: z.ZodURL;
    deviceKey: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const ClientNotificationFeedResponseSchema: z.ZodObject<{
    cursor: z.ZodNumber;
    notifications: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            "action-required": "action-required";
        }>;
        title: z.ZodString;
        body: z.ZodString;
        occurredAt: z.ZodNumber;
        route: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const WorkTreeOrderSchema: z.ZodObject<{
    agentIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
    channelIdsByAgent: z.ZodRecord<z.core.$ZodBranded<z.ZodString, "AgentId", "out">, z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>>;
    unboundChannelIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
}, z.core.$strict>;
export type WorkTreeOrder = z.output<typeof WorkTreeOrderSchema>;
export declare const HostSnapshotMessageSchema: z.ZodObject<{
    id: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
    channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    role: z.ZodEnum<{
        agent: "agent";
        system: "system";
        member: "member";
    }>;
    parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"text">;
        text: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"mention">;
        memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
        displayName: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"image">;
        assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
        alt: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"file">;
        assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
        name: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"audio">;
        assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"quote">;
        messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"rich">;
        adapterKey: z.ZodString;
        kind: z.ZodString;
        summary: z.ZodString;
        title: z.ZodOptional<z.ZodString>;
        source: z.ZodOptional<z.ZodString>;
        targetUrl: z.ZodOptional<z.ZodURL>;
        previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
        extension: z.ZodOptional<z.ZodJSONSchema>;
    }, z.core.$strict>], "type">>;
    sender: z.ZodOptional<z.ZodObject<{
        memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
        displayName: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    mentionedConnectionAccount: z.ZodOptional<z.ZodBoolean>;
    activityKey: z.ZodOptional<z.ZodString>;
    targetLogicalMessageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">>;
    occurredAt: z.ZodNumber;
    deliveryState: z.ZodOptional<z.ZodEnum<{
        unknown: "unknown";
        failed: "failed";
        planned: "planned";
        sending: "sending";
        sent: "sent";
        "partially-sent": "partially-sent";
    }>>;
    deliveryResolution: z.ZodOptional<z.ZodObject<{
        action: z.ZodEnum<{
            retry: "retry";
            "confirm-delivered": "confirm-delivered";
        }>;
        resolvedAt: z.ZodNumber;
    }, z.core.$strict>>;
    origin: z.ZodOptional<z.ZodEnum<{
        "admin-console": "admin-console";
    }>>;
    inboundHook: z.ZodOptional<z.ZodObject<{
        trigger: z.ZodEnum<{
            default: "default";
            suppress: "suppress";
            force: "force";
        }>;
        hidden: z.ZodBoolean;
        annotation: z.ZodOptional<z.ZodString>;
        extensions: z.ZodArray<z.ZodString>;
        problems: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    scheduledTask: z.ZodOptional<z.ZodObject<{
        label: z.ZodString;
        extensionName: z.ZodOptional<z.ZodString>;
        note: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type HostSnapshotMessage = z.output<typeof HostSnapshotMessageSchema>;
export declare const HostConnectionEventSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "ConnectionEventId", "out">;
    connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    activityKey: z.ZodString;
    summary: z.ZodString;
    actor: z.ZodOptional<z.ZodObject<{
        identityId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
        displayName: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    subject: z.ZodOptional<z.ZodObject<{
        identityId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
        displayName: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    occurredAt: z.ZodNumber;
}, z.core.$strict>;
export type HostConnectionEvent = z.output<typeof HostConnectionEventSchema>;
export declare const PlatformUserListResponseSchema: z.ZodObject<{
    total: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        identityId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
        displayName: z.ZodOptional<z.ZodString>;
        adapter: z.ZodObject<{
            key: z.ZodString;
            displayName: z.ZodString;
        }, z.core.$strict>;
        connection: z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
            displayName: z.ZodString;
        }, z.core.$strict>;
        activeChannelCount: z.ZodNumber;
        channelPreview: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            displayName: z.ZodOptional<z.ZodString>;
            kind: z.ZodEnum<{
                internal: "internal";
                direct: "direct";
                group: "group";
            }>;
        }, z.core.$strict>>;
        historicalOnly: z.ZodBoolean;
    }, z.core.$strict>>;
    facets: z.ZodObject<{
        adapters: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            displayName: z.ZodString;
            userCount: z.ZodNumber;
        }, z.core.$strict>>;
        connections: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
            adapterKey: z.ZodString;
            displayName: z.ZodString;
            userCount: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    nextCursor: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">>;
}, z.core.$strict>;
export type PlatformUserListResponse = z.output<typeof PlatformUserListResponseSchema>;
export declare const ChannelFactSseItemSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        inbound: "inbound";
        outbound: "outbound";
    }>;
    sourceId: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
    message: z.ZodObject<{
        id: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        role: z.ZodEnum<{
            agent: "agent";
            system: "system";
            member: "member";
        }>;
        parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"text">;
            text: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"mention">;
            memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
            displayName: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"image">;
            assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
            alt: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"file">;
            assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
            name: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"audio">;
            assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"quote">;
            messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"rich">;
            adapterKey: z.ZodString;
            kind: z.ZodString;
            summary: z.ZodString;
            title: z.ZodOptional<z.ZodString>;
            source: z.ZodOptional<z.ZodString>;
            targetUrl: z.ZodOptional<z.ZodURL>;
            previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
            extension: z.ZodOptional<z.ZodJSONSchema>;
        }, z.core.$strict>], "type">>;
        sender: z.ZodOptional<z.ZodObject<{
            memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
            displayName: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        mentionedConnectionAccount: z.ZodOptional<z.ZodBoolean>;
        activityKey: z.ZodOptional<z.ZodString>;
        targetLogicalMessageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">>;
        occurredAt: z.ZodNumber;
        deliveryState: z.ZodOptional<z.ZodEnum<{
            unknown: "unknown";
            failed: "failed";
            planned: "planned";
            sending: "sending";
            sent: "sent";
            "partially-sent": "partially-sent";
        }>>;
        deliveryResolution: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                retry: "retry";
                "confirm-delivered": "confirm-delivered";
            }>;
            resolvedAt: z.ZodNumber;
        }, z.core.$strict>>;
        origin: z.ZodOptional<z.ZodEnum<{
            "admin-console": "admin-console";
        }>>;
        inboundHook: z.ZodOptional<z.ZodObject<{
            trigger: z.ZodEnum<{
                default: "default";
                suppress: "suppress";
                force: "force";
            }>;
            hidden: z.ZodBoolean;
            annotation: z.ZodOptional<z.ZodString>;
            extensions: z.ZodArray<z.ZodString>;
            problems: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        scheduledTask: z.ZodOptional<z.ZodObject<{
            label: z.ZodString;
            extensionName: z.ZodOptional<z.ZodString>;
            note: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const ChannelFactSseDataSchema: z.ZodObject<{
    channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    revision: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            inbound: "inbound";
            outbound: "outbound";
        }>;
        sourceId: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
        message: z.ZodObject<{
            id: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            role: z.ZodEnum<{
                agent: "agent";
                system: "system";
                member: "member";
            }>;
            parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"text">;
                text: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"mention">;
                memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"image">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                alt: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"file">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                name: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"audio">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"quote">;
                messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"rich">;
                adapterKey: z.ZodString;
                kind: z.ZodString;
                summary: z.ZodString;
                title: z.ZodOptional<z.ZodString>;
                source: z.ZodOptional<z.ZodString>;
                targetUrl: z.ZodOptional<z.ZodURL>;
                previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
                extension: z.ZodOptional<z.ZodJSONSchema>;
            }, z.core.$strict>], "type">>;
            sender: z.ZodOptional<z.ZodObject<{
                memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            mentionedConnectionAccount: z.ZodOptional<z.ZodBoolean>;
            activityKey: z.ZodOptional<z.ZodString>;
            targetLogicalMessageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">>;
            occurredAt: z.ZodNumber;
            deliveryState: z.ZodOptional<z.ZodEnum<{
                unknown: "unknown";
                failed: "failed";
                planned: "planned";
                sending: "sending";
                sent: "sent";
                "partially-sent": "partially-sent";
            }>>;
            deliveryResolution: z.ZodOptional<z.ZodObject<{
                action: z.ZodEnum<{
                    retry: "retry";
                    "confirm-delivered": "confirm-delivered";
                }>;
                resolvedAt: z.ZodNumber;
            }, z.core.$strict>>;
            origin: z.ZodOptional<z.ZodEnum<{
                "admin-console": "admin-console";
            }>>;
            inboundHook: z.ZodOptional<z.ZodObject<{
                trigger: z.ZodEnum<{
                    default: "default";
                    suppress: "suppress";
                    force: "force";
                }>;
                hidden: z.ZodBoolean;
                annotation: z.ZodOptional<z.ZodString>;
                extensions: z.ZodArray<z.ZodString>;
                problems: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            scheduledTask: z.ZodOptional<z.ZodObject<{
                label: z.ZodString;
                extensionName: z.ZodOptional<z.ZodString>;
                note: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const ChannelRuntimePhaseSchema: z.ZodEnum<{
    idle: "idle";
    thinking: "thinking";
    "using-tool": "using-tool";
    "waiting-input": "waiting-input";
    unavailable: "unavailable";
}>;
export declare const ChannelRuntimeUsageSchema: z.ZodObject<{
    inputTokens: z.ZodNumber;
    outputTokens: z.ZodNumber;
    totalTokens: z.ZodOptional<z.ZodNumber>;
    cacheReadTokens: z.ZodOptional<z.ZodNumber>;
    cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
    reasoningTokens: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const ChannelRuntimeToolSchema: z.ZodObject<{
    callId: z.ZodString;
    name: z.ZodString;
    displayName: z.ZodString;
    state: z.ZodEnum<{
        running: "running";
        failed: "failed";
        succeeded: "succeeded";
    }>;
    inputPreview: z.ZodOptional<z.ZodString>;
    resultPreview: z.ZodOptional<z.ZodString>;
    wroteToChannel: z.ZodOptional<z.ZodBoolean>;
    deliveryState: z.ZodOptional<z.ZodEnum<{
        unknown: "unknown";
        failed: "failed";
        sent: "sent";
        "partially-sent": "partially-sent";
    }>>;
    durationMs: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const ChannelRuntimeStepSchema: z.ZodObject<{
    step: z.ZodNumber;
    tools: z.ZodArray<z.ZodObject<{
        callId: z.ZodString;
        name: z.ZodString;
        displayName: z.ZodString;
        state: z.ZodEnum<{
            running: "running";
            failed: "failed";
            succeeded: "succeeded";
        }>;
        inputPreview: z.ZodOptional<z.ZodString>;
        resultPreview: z.ZodOptional<z.ZodString>;
        wroteToChannel: z.ZodOptional<z.ZodBoolean>;
        deliveryState: z.ZodOptional<z.ZodEnum<{
            unknown: "unknown";
            failed: "failed";
            sent: "sent";
            "partially-sent": "partially-sent";
        }>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    internalOutput: z.ZodOptional<z.ZodObject<{
        kind: z.ZodLiteral<"internal-output">;
        text: z.ZodOptional<z.ZodString>;
        reasoning: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    durationMs: z.ZodOptional<z.ZodNumber>;
    firstTokenMs: z.ZodOptional<z.ZodNumber>;
    usage: z.ZodOptional<z.ZodObject<{
        inputTokens: z.ZodNumber;
        outputTokens: z.ZodNumber;
        totalTokens: z.ZodOptional<z.ZodNumber>;
        cacheReadTokens: z.ZodOptional<z.ZodNumber>;
        cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
        reasoningTokens: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const ChannelRuntimeTurnSchema: z.ZodObject<{
    turn: z.ZodNumber;
    state: z.ZodEnum<{
        error: "error";
        interrupted: "interrupted";
        completed: "completed";
        "in-progress": "in-progress";
        unreplied: "unreplied";
        aborted: "aborted";
        "max-tokens": "max-tokens";
    }>;
    producedReply: z.ZodBoolean;
    responseState: z.ZodEnum<{
        pending: "pending";
        interrupted: "interrupted";
        sent: "sent";
        "not-required": "not-required";
        finished: "finished";
        "protocol-failed": "protocol-failed";
    }>;
    error: z.ZodOptional<z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict>>;
    steps: z.ZodArray<z.ZodObject<{
        step: z.ZodNumber;
        tools: z.ZodArray<z.ZodObject<{
            callId: z.ZodString;
            name: z.ZodString;
            displayName: z.ZodString;
            state: z.ZodEnum<{
                running: "running";
                failed: "failed";
                succeeded: "succeeded";
            }>;
            inputPreview: z.ZodOptional<z.ZodString>;
            resultPreview: z.ZodOptional<z.ZodString>;
            wroteToChannel: z.ZodOptional<z.ZodBoolean>;
            deliveryState: z.ZodOptional<z.ZodEnum<{
                unknown: "unknown";
                failed: "failed";
                sent: "sent";
                "partially-sent": "partially-sent";
            }>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        internalOutput: z.ZodOptional<z.ZodObject<{
            kind: z.ZodLiteral<"internal-output">;
            text: z.ZodOptional<z.ZodString>;
            reasoning: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        firstTokenMs: z.ZodOptional<z.ZodNumber>;
        usage: z.ZodOptional<z.ZodObject<{
            inputTokens: z.ZodNumber;
            outputTokens: z.ZodNumber;
            totalTokens: z.ZodOptional<z.ZodNumber>;
            cacheReadTokens: z.ZodOptional<z.ZodNumber>;
            cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
            reasoningTokens: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    durationMs: z.ZodOptional<z.ZodNumber>;
    startedAt: z.ZodOptional<z.ZodNumber>;
    endedAt: z.ZodOptional<z.ZodNumber>;
    triggerEventId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">>;
}, z.core.$strict>;
export declare const ChannelRuntimeOccupancySchema: z.ZodObject<{
    projectedTokens: z.ZodNumber;
    contextWindow: z.ZodNumber;
    breakdown: z.ZodOptional<z.ZodObject<{
        systemTokens: z.ZodNumber;
        toolsTokens: z.ZodNumber;
        messageTokens: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const ChannelRuntimeCacheSampleSchema: z.ZodObject<{
    turn: z.ZodNumber;
    step: z.ZodNumber;
    at: z.ZodOptional<z.ZodNumber>;
    uncachedInputTokens: z.ZodNumber;
    cacheReadTokens: z.ZodOptional<z.ZodNumber>;
    cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const ChannelRuntimeCacheSchema: z.ZodObject<{
    scope: z.ZodLiteral<"episode">;
    aggregate: z.ZodObject<{
        usageRequestCount: z.ZodNumber;
        observedRequestCount: z.ZodNumber;
        shareRequestCount: z.ZodNumber;
        hitRequestCount: z.ZodNumber;
        uncachedInputTokens: z.ZodNumber;
        cacheReadTokens: z.ZodNumber;
        cacheWriteTokens: z.ZodNumber;
        averageRequestReadShare: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    recent: z.ZodObject<{
        windowSize: z.ZodNumber;
        samples: z.ZodArray<z.ZodObject<{
            turn: z.ZodNumber;
            step: z.ZodNumber;
            at: z.ZodOptional<z.ZodNumber>;
            uncachedInputTokens: z.ZodNumber;
            cacheReadTokens: z.ZodOptional<z.ZodNumber>;
            cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const ChannelRuntimePerformanceSampleSchema: z.ZodObject<{
    turn: z.ZodNumber;
    step: z.ZodNumber;
    at: z.ZodOptional<z.ZodNumber>;
    firstTokenMs: z.ZodOptional<z.ZodNumber>;
    decodeMs: z.ZodOptional<z.ZodNumber>;
    outputTokens: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const ChannelRuntimePerformanceSchema: z.ZodObject<{
    scope: z.ZodLiteral<"episode">;
    aggregate: z.ZodObject<{
        steps: z.ZodNumber;
        llmMs: z.ZodNumber;
        toolMs: z.ZodNumber;
        ttftMs: z.ZodNumber;
        ttftSteps: z.ZodNumber;
        decodeMs: z.ZodNumber;
        decodeTokens: z.ZodNumber;
        decodeSteps: z.ZodNumber;
        retryCount: z.ZodNumber;
        retryDelayMs: z.ZodNumber;
    }, z.core.$strict>;
    recent: z.ZodObject<{
        windowSize: z.ZodNumber;
        samples: z.ZodArray<z.ZodObject<{
            turn: z.ZodNumber;
            step: z.ZodNumber;
            at: z.ZodOptional<z.ZodNumber>;
            firstTokenMs: z.ZodOptional<z.ZodNumber>;
            decodeMs: z.ZodOptional<z.ZodNumber>;
            outputTokens: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const ChannelRuntimeProjectionSchema: z.ZodObject<{
    channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
    episodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
    phase: z.ZodEnum<{
        idle: "idle";
        thinking: "thinking";
        "using-tool": "using-tool";
        "waiting-input": "waiting-input";
        unavailable: "unavailable";
    }>;
    summary: z.ZodString;
    pendingInjectCount: z.ZodNumber;
    occupancy: z.ZodOptional<z.ZodObject<{
        projectedTokens: z.ZodNumber;
        contextWindow: z.ZodNumber;
        breakdown: z.ZodOptional<z.ZodObject<{
            systemTokens: z.ZodNumber;
            toolsTokens: z.ZodNumber;
            messageTokens: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    cache: z.ZodOptional<z.ZodObject<{
        scope: z.ZodLiteral<"episode">;
        aggregate: z.ZodObject<{
            usageRequestCount: z.ZodNumber;
            observedRequestCount: z.ZodNumber;
            shareRequestCount: z.ZodNumber;
            hitRequestCount: z.ZodNumber;
            uncachedInputTokens: z.ZodNumber;
            cacheReadTokens: z.ZodNumber;
            cacheWriteTokens: z.ZodNumber;
            averageRequestReadShare: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        recent: z.ZodObject<{
            windowSize: z.ZodNumber;
            samples: z.ZodArray<z.ZodObject<{
                turn: z.ZodNumber;
                step: z.ZodNumber;
                at: z.ZodOptional<z.ZodNumber>;
                uncachedInputTokens: z.ZodNumber;
                cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    performance: z.ZodOptional<z.ZodObject<{
        scope: z.ZodLiteral<"episode">;
        aggregate: z.ZodObject<{
            steps: z.ZodNumber;
            llmMs: z.ZodNumber;
            toolMs: z.ZodNumber;
            ttftMs: z.ZodNumber;
            ttftSteps: z.ZodNumber;
            decodeMs: z.ZodNumber;
            decodeTokens: z.ZodNumber;
            decodeSteps: z.ZodNumber;
            retryCount: z.ZodNumber;
            retryDelayMs: z.ZodNumber;
        }, z.core.$strict>;
        recent: z.ZodObject<{
            windowSize: z.ZodNumber;
            samples: z.ZodArray<z.ZodObject<{
                turn: z.ZodNumber;
                step: z.ZodNumber;
                at: z.ZodOptional<z.ZodNumber>;
                firstTokenMs: z.ZodOptional<z.ZodNumber>;
                decodeMs: z.ZodOptional<z.ZodNumber>;
                outputTokens: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    turns: z.ZodArray<z.ZodObject<{
        turn: z.ZodNumber;
        state: z.ZodEnum<{
            error: "error";
            interrupted: "interrupted";
            completed: "completed";
            "in-progress": "in-progress";
            unreplied: "unreplied";
            aborted: "aborted";
            "max-tokens": "max-tokens";
        }>;
        producedReply: z.ZodBoolean;
        responseState: z.ZodEnum<{
            pending: "pending";
            interrupted: "interrupted";
            sent: "sent";
            "not-required": "not-required";
            finished: "finished";
            "protocol-failed": "protocol-failed";
        }>;
        error: z.ZodOptional<z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            step: z.ZodNumber;
            tools: z.ZodArray<z.ZodObject<{
                callId: z.ZodString;
                name: z.ZodString;
                displayName: z.ZodString;
                state: z.ZodEnum<{
                    running: "running";
                    failed: "failed";
                    succeeded: "succeeded";
                }>;
                inputPreview: z.ZodOptional<z.ZodString>;
                resultPreview: z.ZodOptional<z.ZodString>;
                wroteToChannel: z.ZodOptional<z.ZodBoolean>;
                deliveryState: z.ZodOptional<z.ZodEnum<{
                    unknown: "unknown";
                    failed: "failed";
                    sent: "sent";
                    "partially-sent": "partially-sent";
                }>>;
                durationMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            internalOutput: z.ZodOptional<z.ZodObject<{
                kind: z.ZodLiteral<"internal-output">;
                text: z.ZodOptional<z.ZodString>;
                reasoning: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
            firstTokenMs: z.ZodOptional<z.ZodNumber>;
            usage: z.ZodOptional<z.ZodObject<{
                inputTokens: z.ZodNumber;
                outputTokens: z.ZodNumber;
                totalTokens: z.ZodOptional<z.ZodNumber>;
                cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
                reasoningTokens: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        startedAt: z.ZodOptional<z.ZodNumber>;
        endedAt: z.ZodOptional<z.ZodNumber>;
        triggerEventId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const ChannelRuntimeSseDataSchema: z.ZodObject<{
    channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
    episodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
    phase: z.ZodEnum<{
        idle: "idle";
        thinking: "thinking";
        "using-tool": "using-tool";
        "waiting-input": "waiting-input";
        unavailable: "unavailable";
    }>;
    summary: z.ZodString;
    pendingInjectCount: z.ZodNumber;
    occupancy: z.ZodOptional<z.ZodObject<{
        projectedTokens: z.ZodNumber;
        contextWindow: z.ZodNumber;
        breakdown: z.ZodOptional<z.ZodObject<{
            systemTokens: z.ZodNumber;
            toolsTokens: z.ZodNumber;
            messageTokens: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    cache: z.ZodOptional<z.ZodObject<{
        scope: z.ZodLiteral<"episode">;
        aggregate: z.ZodObject<{
            usageRequestCount: z.ZodNumber;
            observedRequestCount: z.ZodNumber;
            shareRequestCount: z.ZodNumber;
            hitRequestCount: z.ZodNumber;
            uncachedInputTokens: z.ZodNumber;
            cacheReadTokens: z.ZodNumber;
            cacheWriteTokens: z.ZodNumber;
            averageRequestReadShare: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        recent: z.ZodObject<{
            windowSize: z.ZodNumber;
            samples: z.ZodArray<z.ZodObject<{
                turn: z.ZodNumber;
                step: z.ZodNumber;
                at: z.ZodOptional<z.ZodNumber>;
                uncachedInputTokens: z.ZodNumber;
                cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    performance: z.ZodOptional<z.ZodObject<{
        scope: z.ZodLiteral<"episode">;
        aggregate: z.ZodObject<{
            steps: z.ZodNumber;
            llmMs: z.ZodNumber;
            toolMs: z.ZodNumber;
            ttftMs: z.ZodNumber;
            ttftSteps: z.ZodNumber;
            decodeMs: z.ZodNumber;
            decodeTokens: z.ZodNumber;
            decodeSteps: z.ZodNumber;
            retryCount: z.ZodNumber;
            retryDelayMs: z.ZodNumber;
        }, z.core.$strict>;
        recent: z.ZodObject<{
            windowSize: z.ZodNumber;
            samples: z.ZodArray<z.ZodObject<{
                turn: z.ZodNumber;
                step: z.ZodNumber;
                at: z.ZodOptional<z.ZodNumber>;
                firstTokenMs: z.ZodOptional<z.ZodNumber>;
                decodeMs: z.ZodOptional<z.ZodNumber>;
                outputTokens: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    turns: z.ZodArray<z.ZodObject<{
        turn: z.ZodNumber;
        state: z.ZodEnum<{
            error: "error";
            interrupted: "interrupted";
            completed: "completed";
            "in-progress": "in-progress";
            unreplied: "unreplied";
            aborted: "aborted";
            "max-tokens": "max-tokens";
        }>;
        producedReply: z.ZodBoolean;
        responseState: z.ZodEnum<{
            pending: "pending";
            interrupted: "interrupted";
            sent: "sent";
            "not-required": "not-required";
            finished: "finished";
            "protocol-failed": "protocol-failed";
        }>;
        error: z.ZodOptional<z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>>;
        steps: z.ZodArray<z.ZodObject<{
            step: z.ZodNumber;
            tools: z.ZodArray<z.ZodObject<{
                callId: z.ZodString;
                name: z.ZodString;
                displayName: z.ZodString;
                state: z.ZodEnum<{
                    running: "running";
                    failed: "failed";
                    succeeded: "succeeded";
                }>;
                inputPreview: z.ZodOptional<z.ZodString>;
                resultPreview: z.ZodOptional<z.ZodString>;
                wroteToChannel: z.ZodOptional<z.ZodBoolean>;
                deliveryState: z.ZodOptional<z.ZodEnum<{
                    unknown: "unknown";
                    failed: "failed";
                    sent: "sent";
                    "partially-sent": "partially-sent";
                }>>;
                durationMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            internalOutput: z.ZodOptional<z.ZodObject<{
                kind: z.ZodLiteral<"internal-output">;
                text: z.ZodOptional<z.ZodString>;
                reasoning: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
            firstTokenMs: z.ZodOptional<z.ZodNumber>;
            usage: z.ZodOptional<z.ZodObject<{
                inputTokens: z.ZodNumber;
                outputTokens: z.ZodNumber;
                totalTokens: z.ZodOptional<z.ZodNumber>;
                cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
                reasoningTokens: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        durationMs: z.ZodOptional<z.ZodNumber>;
        startedAt: z.ZodOptional<z.ZodNumber>;
        endedAt: z.ZodOptional<z.ZodNumber>;
        triggerEventId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">>;
    }, z.core.$strict>>;
    revision: z.ZodNumber;
    truncated: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type ChannelRuntimePhase = z.output<typeof ChannelRuntimePhaseSchema>;
export type ChannelRuntimeUsage = z.output<typeof ChannelRuntimeUsageSchema>;
export type ChannelRuntimeOccupancy = z.output<typeof ChannelRuntimeOccupancySchema>;
export type ChannelRuntimeCacheSample = z.output<typeof ChannelRuntimeCacheSampleSchema>;
export type ChannelRuntimeCache = z.output<typeof ChannelRuntimeCacheSchema>;
export type ChannelRuntimePerformanceSample = z.output<typeof ChannelRuntimePerformanceSampleSchema>;
export type ChannelRuntimePerformance = z.output<typeof ChannelRuntimePerformanceSchema>;
export type ChannelRuntimeProjection = z.output<typeof ChannelRuntimeProjectionSchema>;
export type ChannelRuntimeSseData = z.output<typeof ChannelRuntimeSseDataSchema>;
export type ChannelFactSseData = z.output<typeof ChannelFactSseDataSchema>;
export declare const HostSyncCursorSchema: z.ZodObject<{
    epoch: z.ZodString;
    sequence: z.ZodNumber;
}, z.core.$strict>;
export declare const AgentAppearanceSchema: z.ZodObject<{
    hue: z.ZodOptional<z.ZodNumber>;
    avatarAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
}, z.core.$strict>;
export type AgentAppearance = z.output<typeof AgentAppearanceSchema>;
/** Upper bound of a reported unread count; `unreadCapped` marks that more exist. */
export declare const CHANNEL_UNREAD_COUNT_CAP = 99;
export declare const ChannelActivitySummarySchema: z.ZodObject<{
    lastActivityAt: z.ZodOptional<z.ZodNumber>;
    lastMessage: z.ZodOptional<z.ZodObject<{
        role: z.ZodEnum<{
            agent: "agent";
            system: "system";
            member: "member";
            admin: "admin";
        }>;
        author: z.ZodString;
        preview: z.ZodString;
        occurredAt: z.ZodNumber;
    }, z.core.$strict>>;
    unreadCount: z.ZodNumber;
    unreadCapped: z.ZodBoolean;
}, z.core.$strict>;
export type ChannelActivitySummary = z.output<typeof ChannelActivitySummarySchema>;
export declare const AttentionItemSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        "delivery-unconfirmed": "delivery-unconfirmed";
        "delivery-failed": "delivery-failed";
        "turn-failed": "turn-failed";
        "authoring-approval": "authoring-approval";
        "connection-unhealthy": "connection-unhealthy";
        "agent-model-unavailable": "agent-model-unavailable";
        "agent-vision-unavailable": "agent-vision-unavailable";
    }>;
    severity: z.ZodEnum<{
        info: "info";
        warning: "warning";
        critical: "critical";
    }>;
    subject: z.ZodObject<{
        kind: z.ZodEnum<{
            agent: "agent";
            channel: "channel";
            connection: "connection";
            outbound: "outbound";
            "authoring-task": "authoring-task";
        }>;
        id: z.ZodString;
    }, z.core.$strict>;
    related: z.ZodObject<{
        channelId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
        agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        connectionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">>;
        taskId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">>;
        outboundId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">>;
    }, z.core.$strict>;
    title: z.ZodString;
    detail: z.ZodString;
    action: z.ZodObject<{
        kind: z.ZodEnum<{
            "open-channel": "open-channel";
            "resolve-delivery": "resolve-delivery";
            "open-authoring-task": "open-authoring-task";
            "open-connection": "open-connection";
            "open-agent": "open-agent";
        }>;
        label: z.ZodString;
    }, z.core.$strict>;
    occurredAt: z.ZodNumber;
}, z.core.$strict>;
export type AttentionItem = z.output<typeof AttentionItemSchema>;
export declare const AttentionListSchema: z.ZodObject<{
    revision: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        kind: z.ZodEnum<{
            "delivery-unconfirmed": "delivery-unconfirmed";
            "delivery-failed": "delivery-failed";
            "turn-failed": "turn-failed";
            "authoring-approval": "authoring-approval";
            "connection-unhealthy": "connection-unhealthy";
            "agent-model-unavailable": "agent-model-unavailable";
            "agent-vision-unavailable": "agent-vision-unavailable";
        }>;
        severity: z.ZodEnum<{
            info: "info";
            warning: "warning";
            critical: "critical";
        }>;
        subject: z.ZodObject<{
            kind: z.ZodEnum<{
                agent: "agent";
                channel: "channel";
                connection: "connection";
                outbound: "outbound";
                "authoring-task": "authoring-task";
            }>;
            id: z.ZodString;
        }, z.core.$strict>;
        related: z.ZodObject<{
            channelId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
            agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
            connectionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">>;
            taskId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">>;
            outboundId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">>;
        }, z.core.$strict>;
        title: z.ZodString;
        detail: z.ZodString;
        action: z.ZodObject<{
            kind: z.ZodEnum<{
                "open-channel": "open-channel";
                "resolve-delivery": "resolve-delivery";
                "open-authoring-task": "open-authoring-task";
                "open-connection": "open-connection";
                "open-agent": "open-agent";
            }>;
            label: z.ZodString;
        }, z.core.$strict>;
        occurredAt: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const ChannelPendingContextSchema: z.ZodObject<{
    channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    episodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
    items: z.ZodArray<z.ZodObject<{
        admissionId: z.ZodString;
        target: z.ZodEnum<{
            "next-step": "next-step";
            "next-turn": "next-turn";
        }>;
        events: z.ZodArray<z.ZodObject<{
            eventId: z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">;
            author: z.ZodString;
            preview: z.ZodString;
            receivedAt: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ChannelPendingContext = z.output<typeof ChannelPendingContextSchema>;
export declare const ACTIVITY_MAX_WINDOW_MS: number;
export declare const ACTIVITY_MIN_BUCKET_MS: number;
export declare const ACTIVITY_MAX_BUCKETS = 288;
export declare const activityDurationMs: (value: string) => number;
export declare const ActivityQuerySchema: z.ZodObject<{
    window: z.ZodDefault<z.ZodString>;
    bucket: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
export declare const ChannelActivitySeriesSchema: z.ZodObject<{
    from: z.ZodNumber;
    to: z.ZodNumber;
    bucketMs: z.ZodNumber;
    channels: z.ZodArray<z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        counts: z.ZodArray<z.ZodNumber>;
        total: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ChannelActivitySeries = z.output<typeof ChannelActivitySeriesSchema>;
export declare const ScheduledTaskIdSchema: z.ZodString;
/**
 * One scheduled task of an agent in one channel. `chat` tasks come from the agent's scheduling tools; `declared` and
 * `runtime` tasks belong to an extension (Manifest plan or `ctx.nxt.jobs`).
 */
export declare const ScheduledTaskSchema: z.ZodObject<{
    id: z.ZodString;
    agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    source: z.ZodEnum<{
        chat: "chat";
        declared: "declared";
        runtime: "runtime";
    }>;
    extensionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">>;
    extensionName: z.ZodOptional<z.ZodString>;
    label: z.ZodString;
    note: z.ZodOptional<z.ZodString>;
    schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"once">;
        at: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"cron">;
        cron: z.ZodString;
        timezone: z.ZodString;
    }, z.core.$strict>], "kind">;
    state: z.ZodEnum<{
        finished: "finished";
        scheduled: "scheduled";
        paused: "paused";
        inactive: "inactive";
    }>;
    nextRunAt: z.ZodOptional<z.ZodNumber>;
    lastFiredAt: z.ZodOptional<z.ZodNumber>;
    createdAt: z.ZodNumber;
}, z.core.$strict>;
export type ScheduledTask = z.output<typeof ScheduledTaskSchema>;
export declare const HostSnapshotSchema: z.ZodObject<{
    upgrade: z.ZodOptional<z.ZodObject<{
        runtimeVersion: z.ZodString;
        sessionCompatibilityId: z.ZodString;
        backupId: z.ZodOptional<z.ZodString>;
        resetContexts: z.ZodBoolean;
        diagnostics: z.ZodArray<z.ZodObject<{
            objectKind: z.ZodEnum<{
                agent: "agent";
                extension: "extension";
                adapter: "adapter";
                "model-provider": "model-provider";
                "dsh-plugin": "dsh-plugin";
                "client-page": "client-page";
            }>;
            objectId: z.ZodString;
            objectVersion: z.ZodString;
            configurationRevision: z.ZodString;
            runtimeFingerprint: z.ZodString;
            status: z.ZodEnum<{
                checking: "checking";
                compatible: "compatible";
                isolated: "isolated";
            }>;
            phase: z.ZodEnum<{
                restore: "restore";
                configuration: "configuration";
                dependency: "dependency";
                build: "build";
                load: "load";
                render: "render";
                dispose: "dispose";
            }>;
            reason: z.ZodOptional<z.ZodString>;
            retryable: z.ZodBoolean;
            checkedAt: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    cursor: z.ZodObject<{
        epoch: z.ZodString;
        sequence: z.ZodNumber;
    }, z.core.$strict>;
    diagnosticsSampledAt: z.ZodNumber;
    productMetadata: z.ZodOptional<z.ZodObject<{
        displayName: z.ZodString;
        organizationName: z.ZodString;
        version: z.ZodString;
        releaseId: z.ZodString;
        repositoryUrl: z.ZodURL;
        licenseSpdx: z.ZodNullable<z.ZodString>;
        dshVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    models: z.ZodArray<z.ZodObject<{
        provider: z.ZodString;
        providerName: z.ZodString;
        id: z.ZodString;
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        inputModalities: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    capabilityAvailability: z.ZodObject<{
        subagents: z.ZodObject<{
            available: z.ZodBoolean;
        }, z.core.$strict>;
        webSearch: z.ZodObject<{
            provider: z.ZodLiteral<"deepseek-official">;
            available: z.ZodBoolean;
            credentialConfigured: z.ZodBoolean;
            credentialReference: z.ZodString;
            maxUsesPerCall: z.ZodNumber;
            maxResultsPerCall: z.ZodNumber;
            timeoutMs: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>;
    connectionAdapters: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        displayName: z.ZodString;
        description: z.ZodString;
        provisioning: z.ZodEnum<{
            "user-created": "user-created";
            "system-singleton": "system-singleton";
        }>;
        aliasEditable: z.ZodBoolean;
        channelDiscovery: z.ZodEnum<{
            "host-created": "host-created";
            "adapter-observed": "adapter-observed";
        }>;
        channelKinds: z.ZodArray<z.ZodEnum<{
            internal: "internal";
            direct: "direct";
            group: "group";
        }>>;
        activities: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            scope: z.ZodEnum<{
                channel: "channel";
                connection: "connection";
            }>;
            displayName: z.ZodString;
            description: z.ZodString;
            icon: z.ZodOptional<z.ZodEnum<{
                "app-window": "app-window";
                "bar-chart": "bar-chart";
                "book-open": "book-open";
                boxes: "boxes";
                database: "database";
                "file-text": "file-text";
                folder: "folder";
                globe: "globe";
                "layout-dashboard": "layout-dashboard";
                puzzle: "puzzle";
                terminal: "terminal";
                workflow: "workflow";
                wrench: "wrench";
            }>>;
            triggerable: z.ZodBoolean;
            channelKinds: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                internal: "internal";
                direct: "direct";
                group: "group";
            }>>>;
        }, z.core.$strict>>;
        features: z.ZodObject<{
            processingFeedback: z.ZodOptional<z.ZodObject<{
                channelKinds: z.ZodArray<z.ZodEnum<{
                    direct: "direct";
                    group: "group";
                }>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        diagnostics: z.ZodObject<{
            receive: z.ZodBoolean;
            send: z.ZodBoolean;
        }, z.core.$strict>;
        creation: z.ZodOptional<z.ZodObject<{
            mode: z.ZodEnum<{
                "schema-form": "schema-form";
                "qr-login": "qr-login";
            }>;
            actionLabel: z.ZodOptional<z.ZodString>;
            pendingLabel: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        platformActions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            title: z.ZodString;
            description: z.ZodString;
            risk: z.ZodEnum<{
                low: "low";
                admin: "admin";
            }>;
            channelKinds: z.ZodArray<z.ZodEnum<{
                direct: "direct";
                group: "group";
            }>>;
            parameters: z.ZodObject<{
                type: z.ZodLiteral<"object">;
                properties: z.ZodRecord<z.ZodString, z.ZodJSONSchema>;
                required: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>;
        }, z.core.$strict>>>;
        rawApi: z.ZodOptional<z.ZodObject<{
            description: z.ZodString;
        }, z.core.$strict>>;
        configSchema: z.ZodType<import("./config-schema.js").ConfigSchemaNode, unknown, z.core.$ZodTypeInternals<import("./config-schema.js").ConfigSchemaNode, unknown>> & z.ZodType<{
            readonly type: "object";
            readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
            readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
        }, unknown, z.core.$ZodTypeInternals<{
            readonly type: "object";
            readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
            readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
        }, unknown>>;
    }, z.core.$strict>>;
    notificationSettings: z.ZodObject<{
        revision: z.ZodOptional<z.ZodNumber>;
        system: z.ZodObject<{
            enabled: z.ZodBoolean;
        }, z.core.$strict>;
        bark: z.ZodObject<{
            enabled: z.ZodBoolean;
            serverUrl: z.ZodURL;
            deviceKeyConfigured: z.ZodBoolean;
        }, z.core.$strict>;
        events: z.ZodRecord<z.ZodEnum<{
            "dynamic-client-approval-requested": "dynamic-client-approval-requested";
        }>, z.ZodBoolean>;
    }, z.core.$strict>;
    agents: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        displayName: z.ZodString;
        persona: z.ZodString;
        personaDocument: z.ZodObject<{
            version: z.ZodLiteral<1>;
            segments: z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                type: z.ZodLiteral<"text">;
                text: z.ZodString;
            }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"platform-user">;
                targetId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"channel">;
                targetId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"extension">;
                targetId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>], "kind">]>>;
        }, z.core.$strict>;
        model: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            reasoningEffort: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        capabilities: z.ZodObject<{
            subagents: z.ZodBoolean;
            fileTools: z.ZodBoolean;
            webSearch: z.ZodBoolean;
            dynamicCreation: z.ZodBoolean;
            developmentShell: z.ZodBoolean;
            unrestrictedFileAccess: z.ZodBoolean;
            scheduledTasks: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>;
        imagePolicy: z.ZodObject<{
            history: z.ZodObject<{
                mode: z.ZodLiteral<"persistent-distinct">;
                detail: z.ZodEnum<{
                    high: "high";
                    low: "low";
                    auto: "auto";
                }>;
                restoreAfterCompaction: z.ZodObject<{
                    recentMessages: z.ZodNumber;
                    maxImages: z.ZodNumber;
                }, z.core.$strict>;
            }, z.core.$strict>;
            textModel: z.ZodDiscriminatedUnion<[z.ZodObject<{
                mode: z.ZodLiteral<"disabled">;
            }, z.core.$strict>, z.ZodObject<{
                mode: z.ZodLiteral<"auxiliary">;
                model: z.ZodObject<{
                    provider: z.ZodString;
                    model: z.ZodString;
                    reasoningEffort: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                maxTokens: z.ZodNumber;
            }, z.core.$strict>], "mode">;
        }, z.core.$strict>;
        dynamicClientApprovalPolicy: z.ZodEnum<{
            manual: "manual";
            automatic: "automatic";
        }>;
        imageDiagnostics: z.ZodObject<{
            route: z.ZodObject<{
                mode: z.ZodEnum<{
                    direct: "direct";
                    unavailable: "unavailable";
                    delegated: "delegated";
                }>;
                provider: z.ZodOptional<z.ZodString>;
                model: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            activeSessions: z.ZodNumber;
            residentImages: z.ZodNumber;
            duplicateImagesSkipped: z.ZodNumber;
            lastInspection: z.ZodOptional<z.ZodObject<{
                mode: z.ZodEnum<{
                    direct: "direct";
                    delegated: "delegated";
                }>;
                imageCount: z.ZodNumber;
                provider: z.ZodOptional<z.ZodString>;
                model: z.ZodOptional<z.ZodString>;
                cacheHit: z.ZodBoolean;
                usage: z.ZodOptional<z.ZodObject<{
                    inputTokens: z.ZodNumber;
                    outputTokens: z.ZodNumber;
                    totalTokens: z.ZodOptional<z.ZodNumber>;
                    cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                    cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
                    reasoningTokens: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                errorCode: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            lastRestoration: z.ZodOptional<z.ZodObject<{
                compactionId: z.ZodString;
                candidateCount: z.ZodNumber;
                restoredCount: z.ZodNumber;
                skippedCount: z.ZodNumber;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            blockers: z.ZodArray<z.ZodString>;
        }, z.core.$strict>;
        currentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
        runtimeStatus: z.ZodEnum<{
            running: "running";
            idle: "idle";
        }>;
        runtimePhase: z.ZodDefault<z.ZodEnum<{
            idle: "idle";
            thinking: "thinking";
            "using-tool": "using-tool";
            "waiting-input": "waiting-input";
            unavailable: "unavailable";
        }>>;
        createdAt: z.ZodNumber;
        channels: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
        appearance: z.ZodDefault<z.ZodObject<{
            hue: z.ZodOptional<z.ZodNumber>;
            avatarAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    channels: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        platformChannelId: z.ZodString;
        kind: z.ZodEnum<{
            internal: "internal";
            direct: "direct";
            group: "group";
        }>;
        displayName: z.ZodOptional<z.ZodString>;
        boundAgentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        runtimePhase: z.ZodDefault<z.ZodEnum<{
            idle: "idle";
            thinking: "thinking";
            "using-tool": "using-tool";
            "waiting-input": "waiting-input";
            unavailable: "unavailable";
        }>>;
        activity: z.ZodDefault<z.ZodObject<{
            lastActivityAt: z.ZodOptional<z.ZodNumber>;
            lastMessage: z.ZodOptional<z.ZodObject<{
                role: z.ZodEnum<{
                    agent: "agent";
                    system: "system";
                    member: "member";
                    admin: "admin";
                }>;
                author: z.ZodString;
                preview: z.ZodString;
                occurredAt: z.ZodNumber;
            }, z.core.$strict>>;
            unreadCount: z.ZodNumber;
            unreadCapped: z.ZodBoolean;
        }, z.core.$strict>>;
        bindings: z.ZodArray<z.ZodObject<{
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            triggerPolicy: z.ZodEnum<{
                always: "always";
                "mentioned-or-replied": "mentioned-or-replied";
                command: "command";
                "observe-only": "observe-only";
            }>;
            processingFeedback: z.ZodDefault<z.ZodEnum<{
                auto: "auto";
                off: "off";
            }>>;
            activityTriggerOverrides: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodBoolean>>;
            boundAt: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    workTreeOrder: z.ZodDefault<z.ZodObject<{
        agentIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        channelIdsByAgent: z.ZodRecord<z.core.$ZodBranded<z.ZodString, "AgentId", "out">, z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>>;
        unboundChannelIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
    }, z.core.$strict>>;
    messages: z.ZodArray<z.ZodObject<{
        id: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        role: z.ZodEnum<{
            agent: "agent";
            system: "system";
            member: "member";
        }>;
        parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"text">;
            text: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"mention">;
            memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
            displayName: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"image">;
            assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
            alt: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"file">;
            assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
            name: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"audio">;
            assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"quote">;
            messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"rich">;
            adapterKey: z.ZodString;
            kind: z.ZodString;
            summary: z.ZodString;
            title: z.ZodOptional<z.ZodString>;
            source: z.ZodOptional<z.ZodString>;
            targetUrl: z.ZodOptional<z.ZodURL>;
            previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
            extension: z.ZodOptional<z.ZodJSONSchema>;
        }, z.core.$strict>], "type">>;
        sender: z.ZodOptional<z.ZodObject<{
            memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
            displayName: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        mentionedConnectionAccount: z.ZodOptional<z.ZodBoolean>;
        activityKey: z.ZodOptional<z.ZodString>;
        targetLogicalMessageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">>;
        occurredAt: z.ZodNumber;
        deliveryState: z.ZodOptional<z.ZodEnum<{
            unknown: "unknown";
            failed: "failed";
            planned: "planned";
            sending: "sending";
            sent: "sent";
            "partially-sent": "partially-sent";
        }>>;
        deliveryResolution: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                retry: "retry";
                "confirm-delivered": "confirm-delivered";
            }>;
            resolvedAt: z.ZodNumber;
        }, z.core.$strict>>;
        origin: z.ZodOptional<z.ZodEnum<{
            "admin-console": "admin-console";
        }>>;
        inboundHook: z.ZodOptional<z.ZodObject<{
            trigger: z.ZodEnum<{
                default: "default";
                suppress: "suppress";
                force: "force";
            }>;
            hidden: z.ZodBoolean;
            annotation: z.ZodOptional<z.ZodString>;
            extensions: z.ZodArray<z.ZodString>;
            problems: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        scheduledTask: z.ZodOptional<z.ZodObject<{
            label: z.ZodString;
            extensionName: z.ZodOptional<z.ZodString>;
            note: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    connections: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        adapterKey: z.ZodString;
        alias: z.ZodOptional<z.ZodString>;
        activityTriggerDefaults: z.ZodDefault<z.ZodArray<z.ZodString>>;
        status: z.ZodDefault<z.ZodObject<{
            state: z.ZodEnum<{
                failed: "failed";
                stopped: "stopped";
                connecting: "connecting";
                connected: "connected";
                reconnecting: "reconnecting";
            }>;
            message: z.ZodOptional<z.ZodString>;
            credentialConfigured: z.ZodBoolean;
            proactiveSend: z.ZodBoolean;
            accountReference: z.ZodOptional<z.ZodString>;
            implementation: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                version: z.ZodOptional<z.ZodString>;
                protocolVersion: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            optionalCapabilities: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodEnum<{
                unknown: "unknown";
                available: "available";
                unsupported: "unsupported";
                degraded: "degraded";
            }>>>;
            activities: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
                state: z.ZodEnum<{
                    unknown: "unknown";
                    disabled: "disabled";
                    available: "available";
                    unsupported: "unsupported";
                    degraded: "degraded";
                }>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            processingFeedback: z.ZodOptional<z.ZodObject<{
                state: z.ZodEnum<{
                    unknown: "unknown";
                    disabled: "disabled";
                    available: "available";
                    unsupported: "unsupported";
                    degraded: "degraded";
                }>;
                reason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        channelCount: z.ZodNumber;
        knownChannels: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            name: z.ZodString;
            kind: z.ZodEnum<{
                internal: "internal";
                direct: "direct";
                group: "group";
            }>;
        }, z.core.$strict>>;
        lastInbound: z.ZodOptional<z.ZodObject<{
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            platformMessageId: z.ZodString;
            receivedAt: z.ZodNumber;
        }, z.core.$strict>>;
        receiveTest: z.ZodOptional<z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
            status: z.ZodLiteral<"received">;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            platformMessageId: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodLiteral<"sent">;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            platformMessageId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodEnum<{
                "waiting-for-message": "waiting-for-message";
                "needs-channel": "needs-channel";
                "needs-target": "needs-target";
                "not-connected": "not-connected";
            }>;
            message: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodLiteral<"failed">;
            kind: z.ZodString;
            message: z.ZodString;
            retryAfterMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>], "status">>>;
        sendTest: z.ZodOptional<z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
            status: z.ZodLiteral<"received">;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            platformMessageId: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodLiteral<"sent">;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            platformMessageId: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodEnum<{
                "waiting-for-message": "waiting-for-message";
                "needs-channel": "needs-channel";
                "needs-target": "needs-target";
                "not-connected": "not-connected";
            }>;
            message: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            status: z.ZodLiteral<"failed">;
            kind: z.ZodString;
            message: z.ZodString;
            retryAfterMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>], "status">>>;
        configuration: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>>;
    }, z.core.$strict>>;
    archivedConnections: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        adapterKey: z.ZodString;
        alias: z.ZodOptional<z.ZodString>;
        channelCount: z.ZodNumber;
        archivedAt: z.ZodNumber;
    }, z.core.$strict>>>;
    extensions: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        scope: z.ZodEnum<{
            agent: "agent";
            "host-adapter": "host-adapter";
            "host-ui": "host-ui";
        }>;
        slug: z.ZodString;
        displayName: z.ZodString;
        description: z.ZodString;
        createdByAgentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        revisions: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
            revisionNumber: z.ZodNumber;
            format: z.ZodOptional<z.ZodEnum<{
                unavailable: "unavailable";
                current: "current";
            }>>;
            ui: z.ZodDefault<z.ZodObject<{
                panels: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    anchor: z.ZodEnum<{
                        agent: "agent";
                        channel: "channel";
                        extension: "extension";
                        connection: "connection";
                    }>;
                    title: z.ZodString;
                    icon: z.ZodOptional<z.ZodEnum<{
                        "app-window": "app-window";
                        "bar-chart": "bar-chart";
                        "book-open": "book-open";
                        boxes: "boxes";
                        database: "database";
                        "file-text": "file-text";
                        folder: "folder";
                        globe: "globe";
                        "layout-dashboard": "layout-dashboard";
                        puzzle: "puzzle";
                        terminal: "terminal";
                        workflow: "workflow";
                        wrench: "wrench";
                    }>>;
                    densities: z.ZodArray<z.ZodEnum<{
                        compact: "compact";
                        full: "full";
                    }>>;
                    role: z.ZodOptional<z.ZodEnum<{
                        status: "status";
                        diagnostics: "diagnostics";
                        setup: "setup";
                    }>>;
                    when: z.ZodOptional<z.ZodObject<{
                        channelKinds: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                            internal: "internal";
                            direct: "direct";
                            group: "group";
                        }>>>;
                    }, z.core.$strict>>;
                    kind: z.ZodLiteral<"panel">;
                }, z.core.$strict>>;
                toolViews: z.ZodArray<z.ZodString>;
                messageRenderers: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>;
            configSchema: z.ZodOptional<z.ZodType<import("./config-schema.js").ConfigSchemaNode, unknown, z.core.$ZodTypeInternals<import("./config-schema.js").ConfigSchemaNode, unknown>> & z.ZodType<{
                readonly type: "object";
                readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
                readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
            }, unknown, z.core.$ZodTypeInternals<{
                readonly type: "object";
                readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
                readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
            }, unknown>>>;
            createdAt: z.ZodNumber;
            source: z.ZodOptional<z.ZodObject<{
                kind: z.ZodLiteral<"community">;
                communityUrl: z.ZodString;
                releaseId: z.ZodString;
                publisherHandle: z.ZodString;
                installedAt: z.ZodNumber;
            }, z.core.$strict>>;
            scope: z.ZodEnum<{
                agent: "agent";
                "host-adapter": "host-adapter";
                "host-ui": "host-ui";
            }>;
            contributions: z.ZodArray<z.ZodString>;
            verification: z.ZodOptional<z.ZodObject<{
                verifiedAt: z.ZodNumber;
                dshVersion: z.ZodString;
                contractVersion: z.ZodString;
                hostBuilt: z.ZodBoolean;
                clientBuilt: z.ZodBoolean;
                buildKey: z.ZodString;
                toolInvocationCount: z.ZodNumber;
                rpcMethods: z.ZodArray<z.ZodString>;
                renderedPanels: z.ZodDefault<z.ZodArray<z.ZodString>>;
                renderedToolViews: z.ZodDefault<z.ZodArray<z.ZodString>>;
                renderedMessageRenderers: z.ZodDefault<z.ZodArray<z.ZodString>>;
                renderedPages: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodLiteral<"host-page">;
                    entryId: z.ZodString;
                    title: z.ZodString;
                    description: z.ZodOptional<z.ZodString>;
                    icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        kind: z.ZodLiteral<"host-icon">;
                        name: z.ZodEnum<{
                            "app-window": "app-window";
                            "bar-chart": "bar-chart";
                            "book-open": "book-open";
                            boxes: "boxes";
                            database: "database";
                            "file-text": "file-text";
                            folder: "folder";
                            globe: "globe";
                            "layout-dashboard": "layout-dashboard";
                            puzzle: "puzzle";
                            terminal: "terminal";
                            workflow: "workflow";
                            wrench: "wrench";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        kind: z.ZodLiteral<"svg">;
                        path: z.ZodString;
                        sha256: z.ZodString;
                    }, z.core.$strict>], "kind">;
                    objectPane: z.ZodEnum<{
                        hidden: "hidden";
                        navigation: "navigation";
                    }>;
                    startPath: z.ZodString;
                }, z.core.$strict>>>;
                usedUiComponents: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    Button: "Button";
                    IconButton: "IconButton";
                    Input: "Input";
                    Textarea: "Textarea";
                    Select: "Select";
                    Switch: "Switch";
                    Tabs: "Tabs";
                    Dialog: "Dialog";
                    Popover: "Popover";
                    Tooltip: "Tooltip";
                    Field: "Field";
                    StatusBadge: "StatusBadge";
                    InlineFeedback: "InlineFeedback";
                    EmptyState: "EmptyState";
                    Spinner: "Spinner";
                    PageHeader: "PageHeader";
                    MetricStrip: "MetricStrip";
                    Metric: "Metric";
                    Section: "Section";
                    Stack: "Stack";
                    Grid: "Grid";
                    DataTable: "DataTable";
                    PropertyList: "PropertyList";
                    PropertyRow: "PropertyRow";
                }>>>;
                pageGeometry: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    entryId: z.ZodString;
                    objectPane: z.ZodEnum<{
                        hidden: "hidden";
                        navigation: "navigation";
                    }>;
                    viewport: z.ZodObject<{
                        width: z.ZodNumber;
                        height: z.ZodNumber;
                    }, z.core.$strict>;
                    insets: z.ZodObject<{
                        top: z.ZodNumber;
                        right: z.ZodNumber;
                        bottom: z.ZodNumber;
                        left: z.ZodNumber;
                    }, z.core.$strict>;
                    contentAxesAligned: z.ZodBoolean;
                    horizontalOverflow: z.ZodBoolean;
                    titleDistinct: z.ZodBoolean;
                }, z.core.$strict>>>;
                permissions: z.ZodOptional<z.ZodObject<{
                    permissions: z.ZodArray<z.ZodEnum<{
                        "agents.read": "agents.read";
                        "channels.read": "channels.read";
                        "connections.read": "connections.read";
                        "extensions.read": "extensions.read";
                        "dsh-plugins.read": "dsh-plugins.read";
                        "runtime.read": "runtime.read";
                        "messages.read": "messages.read";
                        "assets.read": "assets.read";
                        "agents.manage": "agents.manage";
                        "channels.manage": "channels.manage";
                        "connections.manage": "connections.manage";
                        "credentials.write": "credentials.write";
                        "messages.send": "messages.send";
                        "notifications.publish": "notifications.publish";
                        "network.request": "network.request";
                    }>>;
                    networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
                    capabilities: z.ZodOptional<z.ZodObject<{
                        network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                            mode: z.ZodLiteral<"domains">;
                            domains: z.ZodArray<z.ZodString>;
                        }, z.core.$strict>, z.ZodObject<{
                            mode: z.ZodLiteral<"config">;
                            fields: z.ZodArray<z.ZodString>;
                        }, z.core.$strict>, z.ZodObject<{
                            mode: z.ZodLiteral<"unrestricted">;
                            purpose: z.ZodString;
                        }, z.core.$strict>], "mode">>;
                        storage: z.ZodOptional<z.ZodObject<{
                            scopes: z.ZodArray<z.ZodEnum<{
                                agent: "agent";
                                channel: "channel";
                                member: "member";
                                shared: "shared";
                            }>>;
                            quotaBytes: z.ZodOptional<z.ZodNumber>;
                        }, z.core.$strict>>;
                        assets: z.ZodOptional<z.ZodObject<{
                            write: z.ZodLiteral<true>;
                        }, z.core.$strict>>;
                        history: z.ZodOptional<z.ZodObject<{
                            read: z.ZodLiteral<true>;
                        }, z.core.$strict>>;
                        inboundHook: z.ZodOptional<z.ZodObject<{
                            reads: z.ZodEnum<{
                                triggered: "triggered";
                                all: "all";
                            }>;
                            mayHide: z.ZodBoolean;
                            mayForceTrigger: z.ZodBoolean;
                            timeoutMs: z.ZodNumber;
                        }, z.core.$strict>>;
                        jobs: z.ZodOptional<z.ZodObject<{
                            declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                                id: z.ZodString;
                                label: z.ZodString;
                                cron: z.ZodString;
                                timezone: z.ZodOptional<z.ZodString>;
                            }, z.core.$strict>>>;
                            runtime: z.ZodOptional<z.ZodObject<{
                                maxActive: z.ZodNumber;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>;
                        platform: z.ZodOptional<z.ZodObject<{
                            actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                                adapter: z.ZodString;
                                action: z.ZodString;
                            }, z.core.$strict>>>;
                            raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>>;
                        llm: z.ZodOptional<z.ZodObject<{
                            maxCallsPerTurn: z.ZodNumber;
                            maxOutputTokens: z.ZodNumber;
                        }, z.core.$strict>>;
                        mcp: z.ZodOptional<z.ZodObject<{
                            servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                                transport: z.ZodLiteral<"streamable-http">;
                                name: z.ZodString;
                                url: z.ZodString;
                                headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                    secret: z.ZodString;
                                }, z.core.$strict>]>>>;
                            }, z.core.$strict>, z.ZodObject<{
                                transport: z.ZodLiteral<"stdio">;
                                name: z.ZodString;
                                command: z.ZodString;
                                args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                                env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                    secret: z.ZodString;
                                }, z.core.$strict>]>>>;
                            }, z.core.$strict>], "transport">>;
                        }, z.core.$strict>>;
                        context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            name: z.ZodString;
                            kind: z.ZodEnum<{
                                static: "static";
                                dynamic: "dynamic";
                            }>;
                            maxChars: z.ZodNumber;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                permissionDigest: z.ZodOptional<z.ZodString>;
                permissionApprovalRequired: z.ZodOptional<z.ZodBoolean>;
                adapter: z.ZodOptional<z.ZodObject<{
                    apiVersion: z.ZodLiteral<2>;
                    key: z.ZodString;
                    descriptorDigest: z.ZodString;
                    registered: z.ZodBoolean;
                    started: z.ZodBoolean;
                    stopped: z.ZodBoolean;
                    inboundCommitted: z.ZodBoolean;
                    outboundReceipt: z.ZodEnum<{
                        unknown: "unknown";
                        failed: "failed";
                        sent: "sent";
                    }>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        activations: z.ZodArray<z.ZodObject<{
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            extensionRevisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
            config: z.ZodJSONSchema;
            configuredSecrets: z.ZodOptional<z.ZodArray<z.ZodString>>;
            activatedAt: z.ZodNumber;
            runtime: z.ZodOptional<z.ZodObject<{
                status: z.ZodEnum<{
                    active: "active";
                    "restore-failed": "restore-failed";
                    "dispose-failed": "dispose-failed";
                }>;
                message: z.ZodOptional<z.ZodString>;
                observedAt: z.ZodNumber;
            }, z.core.$strip>>;
            mcpServers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                state: z.ZodEnum<{
                    unavailable: "unavailable";
                    connecting: "connecting";
                    connected: "connected";
                    "missing-credentials": "missing-credentials";
                }>;
                toolCount: z.ZodOptional<z.ZodNumber>;
                missing: z.ZodOptional<z.ZodArray<z.ZodString>>;
                message: z.ZodOptional<z.ZodString>;
                observedAt: z.ZodNumber;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        installation: z.ZodOptional<z.ZodObject<{
            extensionRevisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
            installedAt: z.ZodNumber;
            config: z.ZodDefault<z.ZodJSONSchema>;
            runtime: z.ZodOptional<z.ZodObject<{
                status: z.ZodEnum<{
                    active: "active";
                    "restore-failed": "restore-failed";
                    "dispose-failed": "dispose-failed";
                }>;
                message: z.ZodOptional<z.ZodString>;
                observedAt: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
        hostUiPermission: z.ZodOptional<z.ZodObject<{
            declaration: z.ZodObject<{
                permissions: z.ZodArray<z.ZodEnum<{
                    "agents.read": "agents.read";
                    "channels.read": "channels.read";
                    "connections.read": "connections.read";
                    "extensions.read": "extensions.read";
                    "dsh-plugins.read": "dsh-plugins.read";
                    "runtime.read": "runtime.read";
                    "messages.read": "messages.read";
                    "assets.read": "assets.read";
                    "agents.manage": "agents.manage";
                    "channels.manage": "channels.manage";
                    "connections.manage": "connections.manage";
                    "credentials.write": "credentials.write";
                    "messages.send": "messages.send";
                    "notifications.publish": "notifications.publish";
                    "network.request": "network.request";
                }>>;
                networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
                capabilities: z.ZodOptional<z.ZodObject<{
                    network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        mode: z.ZodLiteral<"domains">;
                        domains: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>, z.ZodObject<{
                        mode: z.ZodLiteral<"config">;
                        fields: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>, z.ZodObject<{
                        mode: z.ZodLiteral<"unrestricted">;
                        purpose: z.ZodString;
                    }, z.core.$strict>], "mode">>;
                    storage: z.ZodOptional<z.ZodObject<{
                        scopes: z.ZodArray<z.ZodEnum<{
                            agent: "agent";
                            channel: "channel";
                            member: "member";
                            shared: "shared";
                        }>>;
                        quotaBytes: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strict>>;
                    assets: z.ZodOptional<z.ZodObject<{
                        write: z.ZodLiteral<true>;
                    }, z.core.$strict>>;
                    history: z.ZodOptional<z.ZodObject<{
                        read: z.ZodLiteral<true>;
                    }, z.core.$strict>>;
                    inboundHook: z.ZodOptional<z.ZodObject<{
                        reads: z.ZodEnum<{
                            triggered: "triggered";
                            all: "all";
                        }>;
                        mayHide: z.ZodBoolean;
                        mayForceTrigger: z.ZodBoolean;
                        timeoutMs: z.ZodNumber;
                    }, z.core.$strict>>;
                    jobs: z.ZodOptional<z.ZodObject<{
                        declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            label: z.ZodString;
                            cron: z.ZodString;
                            timezone: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>>;
                        runtime: z.ZodOptional<z.ZodObject<{
                            maxActive: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    platform: z.ZodOptional<z.ZodObject<{
                        actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                            adapter: z.ZodString;
                            action: z.ZodString;
                        }, z.core.$strict>>>;
                        raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    llm: z.ZodOptional<z.ZodObject<{
                        maxCallsPerTurn: z.ZodNumber;
                        maxOutputTokens: z.ZodNumber;
                    }, z.core.$strict>>;
                    mcp: z.ZodOptional<z.ZodObject<{
                        servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                            transport: z.ZodLiteral<"streamable-http">;
                            name: z.ZodString;
                            url: z.ZodString;
                            headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                secret: z.ZodString;
                            }, z.core.$strict>]>>>;
                        }, z.core.$strict>, z.ZodObject<{
                            transport: z.ZodLiteral<"stdio">;
                            name: z.ZodString;
                            command: z.ZodString;
                            args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                            env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                secret: z.ZodString;
                            }, z.core.$strict>]>>>;
                        }, z.core.$strict>], "transport">>;
                    }, z.core.$strict>>;
                    context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        kind: z.ZodEnum<{
                            static: "static";
                            dynamic: "dynamic";
                        }>;
                        maxChars: z.ZodNumber;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            permissionDigest: z.ZodString;
            approvalRequired: z.ZodBoolean;
        }, z.core.$strict>>;
        hostClientDiagnostic: z.ZodOptional<z.ZodObject<{
            revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
            status: z.ZodEnum<{
                failed: "failed";
                loaded: "loaded";
            }>;
            message: z.ZodOptional<z.ZodString>;
            observedAt: z.ZodNumber;
        }, z.core.$strict>>;
        clientDiagnostics: z.ZodArray<z.ZodObject<{
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
            status: z.ZodEnum<{
                failed: "failed";
                loaded: "loaded";
            }>;
            message: z.ZodOptional<z.ZodString>;
            observedAt: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    hostUi: z.ZodDefault<z.ZodObject<{
        preferencesRevision: z.ZodNumber;
        pages: z.ZodArray<z.ZodObject<{
            pageInstanceId: z.core.$ZodBranded<z.ZodString, "HostUiPageInstanceId", "out">;
            owner: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"extension">;
                extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
                revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"dsh-plugin">;
                entryId: z.ZodString;
                artifactDigest: z.ZodString;
            }, z.core.$strict>], "kind">;
            entryId: z.ZodString;
            title: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"host-icon">;
                name: z.ZodEnum<{
                    "app-window": "app-window";
                    "bar-chart": "bar-chart";
                    "book-open": "book-open";
                    boxes: "boxes";
                    database: "database";
                    "file-text": "file-text";
                    folder: "folder";
                    globe: "globe";
                    "layout-dashboard": "layout-dashboard";
                    puzzle: "puzzle";
                    terminal: "terminal";
                    workflow: "workflow";
                    wrench: "wrench";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"svg">;
                path: z.ZodString;
                sha256: z.ZodString;
            }, z.core.$strict>], "kind">;
            objectPane: z.ZodEnum<{
                hidden: "hidden";
                navigation: "navigation";
            }>;
            startPath: z.ZodString;
            visible: z.ZodBoolean;
            sortOrder: z.ZodNumber;
            routeBase: z.ZodString;
            client: z.ZodObject<{
                moduleUrl: z.ZodString;
                buildKey: z.ZodString;
            }, z.core.$strict>;
            diagnostic: z.ZodOptional<z.ZodObject<{
                status: z.ZodEnum<{
                    ready: "ready";
                    "restore-failed": "restore-failed";
                    "load-failed": "load-failed";
                    "navigation-failed": "navigation-failed";
                    "rpc-failed": "rpc-failed";
                }>;
                message: z.ZodOptional<z.ZodString>;
                observedAt: z.ZodNumber;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            updatedAt: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    dynamic: z.ZodArray<z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        packageId: z.ZodOptional<z.ZodString>;
        currentPackageId: z.ZodOptional<z.ZodString>;
        nextPackageId: z.ZodOptional<z.ZodString>;
        approvalRequestId: z.ZodOptional<z.ZodString>;
        status: z.ZodEnum<{
            rejected: "rejected";
            "awaiting-approval": "awaiting-approval";
            "starting-host": "starting-host";
            "client-pending": "client-pending";
            running: "running";
            waiting: "waiting";
            failed: "failed";
            cancelled: "cancelled";
            stopped: "stopped";
        }>;
        activeRun: z.ZodOptional<z.ZodObject<{
            pluginRunId: z.ZodString;
            packageId: z.ZodString;
        }, z.core.$strict>>;
        latestRun: z.ZodOptional<z.ZodObject<{
            pluginRunId: z.ZodString;
            packageId: z.ZodString;
            mode: z.ZodEnum<{
                run: "run";
                update: "update";
            }>;
            status: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                "client-pending": "client-pending";
                running: "running";
                waiting: "waiting";
                failed: "failed";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            approvalRequestId: z.ZodOptional<z.ZodString>;
            requiresApproval: z.ZodOptional<z.ZodBoolean>;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                }>;
                message: z.ZodString;
                stack: z.ZodOptional<z.ZodString>;
                pluginId: z.ZodString;
                packageId: z.ZodString;
                pluginRunId: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        packages: z.ZodArray<z.ZodObject<{
            packageId: z.ZodString;
            name: z.ZodString;
            purpose: z.ZodString;
            hasHostHalf: z.ZodBoolean;
            hasClientHalf: z.ZodBoolean;
        }, z.core.$strict>>;
        policy: z.ZodObject<{
            turn: z.ZodNumber;
            primaryPluginId: z.ZodOptional<z.ZodString>;
            consecutiveFailures: z.ZodNumber;
            repeatedFingerprintCount: z.ZodNumber;
            lastErrorFingerprint: z.ZodOptional<z.ZodString>;
            blockedReason: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    authoringTasks: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        title: z.ZodString;
        requirementSummary: z.ZodString;
        status: z.ZodEnum<{
            "awaiting-approval": "awaiting-approval";
            running: "running";
            failed: "failed";
            stopped: "stopped";
            working: "working";
            ready: "ready";
            repairing: "repairing";
            interrupted: "interrupted";
            completed: "completed";
        }>;
        approvalPolicy: z.ZodEnum<{
            "risk-stable": "risk-stable";
            "fully-automatic": "fully-automatic";
        }>;
        approvedRiskDigest: z.ZodOptional<z.ZodString>;
        revision: z.ZodNumber;
        activeAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        candidateAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        verifiedAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        createdAt: z.ZodNumber;
        updatedAt: z.ZodNumber;
    }, z.core.$strict>>>;
    scheduledTasks: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        source: z.ZodEnum<{
            chat: "chat";
            declared: "declared";
            runtime: "runtime";
        }>;
        extensionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">>;
        extensionName: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        note: z.ZodOptional<z.ZodString>;
        schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"once">;
            at: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cron">;
            cron: z.ZodString;
            timezone: z.ZodString;
        }, z.core.$strict>], "kind">;
        state: z.ZodEnum<{
            finished: "finished";
            scheduled: "scheduled";
            paused: "paused";
            inactive: "inactive";
        }>;
        nextRunAt: z.ZodOptional<z.ZodNumber>;
        lastFiredAt: z.ZodOptional<z.ZodNumber>;
        createdAt: z.ZodNumber;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const DshPluginCatalogEntrySchema: z.ZodObject<{
    packageName: z.ZodString;
    packageVersion: z.ZodString;
    origin: z.ZodEnum<{
        dynamic: "dynamic";
        builtin: "builtin";
        profile: "profile";
        installed: "installed";
    }>;
    settingsNamespaces: z.ZodArray<z.ZodString>;
    loadError: z.ZodOptional<z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict>>;
    packageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "DshPluginPackageId", "out">>;
    installSource: z.ZodOptional<z.ZodEnum<{
        registry: "registry";
        tarball: "tarball";
        imported: "imported";
    }>>;
    installedAt: z.ZodOptional<z.ZodNumber>;
    clientUiDetected: z.ZodOptional<z.ZodBoolean>;
    hostUi: z.ZodOptional<z.ZodObject<{
        schemaVersion: z.ZodLiteral<1>;
        entryKey: z.ZodString;
        client: z.ZodString;
        css: z.ZodOptional<z.ZodString>;
        pages: z.ZodArray<z.ZodObject<{
            kind: z.ZodLiteral<"host-page">;
            entryId: z.ZodString;
            title: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"host-icon">;
                name: z.ZodEnum<{
                    "app-window": "app-window";
                    "bar-chart": "bar-chart";
                    "book-open": "book-open";
                    boxes: "boxes";
                    database: "database";
                    "file-text": "file-text";
                    folder: "folder";
                    globe: "globe";
                    "layout-dashboard": "layout-dashboard";
                    puzzle: "puzzle";
                    terminal: "terminal";
                    workflow: "workflow";
                    wrench: "wrench";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"svg">;
                path: z.ZodString;
                sha256: z.ZodString;
            }, z.core.$strict>], "kind">;
            objectPane: z.ZodEnum<{
                hidden: "hidden";
                navigation: "navigation";
            }>;
            startPath: z.ZodString;
        }, z.core.$strict>>;
        permissions: z.ZodDefault<z.ZodObject<{
            permissions: z.ZodArray<z.ZodEnum<{
                "agents.read": "agents.read";
                "channels.read": "channels.read";
                "connections.read": "connections.read";
                "extensions.read": "extensions.read";
                "dsh-plugins.read": "dsh-plugins.read";
                "runtime.read": "runtime.read";
                "messages.read": "messages.read";
                "assets.read": "assets.read";
                "agents.manage": "agents.manage";
                "channels.manage": "channels.manage";
                "connections.manage": "connections.manage";
                "credentials.write": "credentials.write";
                "messages.send": "messages.send";
                "notifications.publish": "notifications.publish";
                "network.request": "network.request";
            }>>;
            networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
            capabilities: z.ZodOptional<z.ZodObject<{
                network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    mode: z.ZodLiteral<"domains">;
                    domains: z.ZodArray<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"config">;
                    fields: z.ZodArray<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"unrestricted">;
                    purpose: z.ZodString;
                }, z.core.$strict>], "mode">>;
                storage: z.ZodOptional<z.ZodObject<{
                    scopes: z.ZodArray<z.ZodEnum<{
                        agent: "agent";
                        channel: "channel";
                        member: "member";
                        shared: "shared";
                    }>>;
                    quotaBytes: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                assets: z.ZodOptional<z.ZodObject<{
                    write: z.ZodLiteral<true>;
                }, z.core.$strict>>;
                history: z.ZodOptional<z.ZodObject<{
                    read: z.ZodLiteral<true>;
                }, z.core.$strict>>;
                inboundHook: z.ZodOptional<z.ZodObject<{
                    reads: z.ZodEnum<{
                        triggered: "triggered";
                        all: "all";
                    }>;
                    mayHide: z.ZodBoolean;
                    mayForceTrigger: z.ZodBoolean;
                    timeoutMs: z.ZodNumber;
                }, z.core.$strict>>;
                jobs: z.ZodOptional<z.ZodObject<{
                    declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        cron: z.ZodString;
                        timezone: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>>;
                    runtime: z.ZodOptional<z.ZodObject<{
                        maxActive: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                platform: z.ZodOptional<z.ZodObject<{
                    actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                        adapter: z.ZodString;
                        action: z.ZodString;
                    }, z.core.$strict>>>;
                    raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                llm: z.ZodOptional<z.ZodObject<{
                    maxCallsPerTurn: z.ZodNumber;
                    maxOutputTokens: z.ZodNumber;
                }, z.core.$strict>>;
                mcp: z.ZodOptional<z.ZodObject<{
                    servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        transport: z.ZodLiteral<"streamable-http">;
                        name: z.ZodString;
                        url: z.ZodString;
                        headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                            secret: z.ZodString;
                        }, z.core.$strict>]>>>;
                    }, z.core.$strict>, z.ZodObject<{
                        transport: z.ZodLiteral<"stdio">;
                        name: z.ZodString;
                        command: z.ZodString;
                        args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                        env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                            secret: z.ZodString;
                        }, z.core.$strict>]>>>;
                    }, z.core.$strict>], "transport">>;
                }, z.core.$strict>>;
                context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    kind: z.ZodEnum<{
                        static: "static";
                        dynamic: "dynamic";
                    }>;
                    maxChars: z.ZodNumber;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    approvedBuilds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    entries: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "DshPluginEntryId", "out">;
        entryKey: z.ZodString;
        moduleName: z.ZodString;
        suggestedScope: z.ZodEnum<{
            agent: "agent";
            host: "host";
        }>;
        selectedScope: z.ZodOptional<z.ZodEnum<{
            agent: "agent";
            host: "host";
        }>>;
        config: z.ZodJSONSchema;
        activations: z.ZodArray<z.ZodObject<{
            targetKey: z.ZodString;
            target: z.ZodEnum<{
                agent: "agent";
                host: "host";
            }>;
            agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
            activatedAt: z.ZodNumber;
            diagnostic: z.ZodOptional<z.ZodObject<{
                status: z.ZodEnum<{
                    active: "active";
                    "restore-failed": "restore-failed";
                    "dispose-failed": "dispose-failed";
                    "load-failed": "load-failed";
                }>;
                phase: z.ZodEnum<{
                    update: "update";
                    restore: "restore";
                    dispose: "dispose";
                    import: "import";
                    apply: "apply";
                }>;
                message: z.ZodOptional<z.ZodString>;
                observedAt: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const DshSettingsNamespaceSchema: z.ZodObject<{
    ns: z.ZodString;
    schema: z.ZodJSONSchema;
    resolved: z.ZodJSONSchema;
    base: z.ZodOptional<z.ZodJSONSchema>;
    user: z.ZodOptional<z.ZodJSONSchema>;
    applies: z.ZodEnum<{
        live: "live";
        restart: "restart";
    }>;
    secrets: z.ZodArray<z.ZodObject<{
        path: z.ZodArray<z.ZodString>;
        set: z.ZodBoolean;
    }, z.core.$strict>>;
    revision: z.ZodNumber;
    writable: z.ZodBoolean;
    owner: z.ZodOptional<z.ZodObject<{
        packageName: z.ZodString;
        packageVersion: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DshSettingsPathSchema: z.ZodArray<z.ZodString>;
export declare const DshSettingsPathOperationSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    op: z.ZodLiteral<"set">;
    path: z.ZodArray<z.ZodString>;
    value: z.ZodJSONSchema;
}, z.core.$strict>, z.ZodObject<{
    op: z.ZodLiteral<"unset">;
    path: z.ZodArray<z.ZodString>;
}, z.core.$strict>], "op">;
export declare const DshSettingsMutationRequestSchema: z.ZodObject<{
    expectedRevision: z.ZodNumber;
    ops: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        op: z.ZodLiteral<"set">;
        path: z.ZodArray<z.ZodString>;
        value: z.ZodJSONSchema;
    }, z.core.$strict>, z.ZodObject<{
        op: z.ZodLiteral<"unset">;
        path: z.ZodArray<z.ZodString>;
    }, z.core.$strict>], "op">>;
}, z.core.$strict>;
export declare const DshCredentialRefSchema: z.ZodString;
export declare const DshCredentialViewSchema: z.ZodObject<{
    configured: z.ZodBoolean;
    source: z.ZodOptional<z.ZodString>;
    writable: z.ZodBoolean;
}, z.core.$strict>;
export declare const DshSettingsChangedSseDataSchema: z.ZodObject<{
    namespace: z.ZodString;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare const DshCredentialsChangedSseDataSchema: z.ZodObject<{
    ref: z.ZodString;
}, z.core.$strict>;
export declare const DynamicChangedSseDataSchema: z.ZodObject<{
    agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
}, z.core.$strict>;
export declare const HostSseStatusDataSchema: z.ZodObject<{
    ok: z.ZodBoolean;
    message: z.ZodString;
    replay: z.ZodOptional<z.ZodEnum<{
        none: "none";
        complete: "complete";
        expired: "expired";
    }>>;
}, z.core.$strict>;
export declare const DshPluginOperationSseDataSchema: z.ZodObject<{
    operationId: z.ZodString;
    kind: z.ZodEnum<{
        inspect: "inspect";
        install: "install";
    }>;
    phase: z.ZodEnum<{
        download: "download";
        dependencies: "dependencies";
        "build-scripts": "build-scripts";
        validation: "validation";
        publish: "publish";
    }>;
    status: z.ZodEnum<{
        running: "running";
        failed: "failed";
        done: "done";
    }>;
    message: z.ZodString;
}, z.core.$strict>;
export declare const HostSseEventSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    event: z.ZodLiteral<"snapshot-changed">;
    data: z.ZodObject<{
        changed: z.ZodLiteral<true>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"channel-fact">;
    data: z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        revision: z.ZodNumber;
        items: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                inbound: "inbound";
                outbound: "outbound";
            }>;
            sourceId: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
            message: z.ZodObject<{
                id: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
                channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                role: z.ZodEnum<{
                    agent: "agent";
                    system: "system";
                    member: "member";
                }>;
                parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"text">;
                    text: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"mention">;
                    memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
                    displayName: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"image">;
                    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                    alt: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"file">;
                    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                    name: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"audio">;
                    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"quote">;
                    messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"rich">;
                    adapterKey: z.ZodString;
                    kind: z.ZodString;
                    summary: z.ZodString;
                    title: z.ZodOptional<z.ZodString>;
                    source: z.ZodOptional<z.ZodString>;
                    targetUrl: z.ZodOptional<z.ZodURL>;
                    previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
                    extension: z.ZodOptional<z.ZodJSONSchema>;
                }, z.core.$strict>], "type">>;
                sender: z.ZodOptional<z.ZodObject<{
                    memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
                    displayName: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                mentionedConnectionAccount: z.ZodOptional<z.ZodBoolean>;
                activityKey: z.ZodOptional<z.ZodString>;
                targetLogicalMessageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">>;
                occurredAt: z.ZodNumber;
                deliveryState: z.ZodOptional<z.ZodEnum<{
                    unknown: "unknown";
                    failed: "failed";
                    planned: "planned";
                    sending: "sending";
                    sent: "sent";
                    "partially-sent": "partially-sent";
                }>>;
                deliveryResolution: z.ZodOptional<z.ZodObject<{
                    action: z.ZodEnum<{
                        retry: "retry";
                        "confirm-delivered": "confirm-delivered";
                    }>;
                    resolvedAt: z.ZodNumber;
                }, z.core.$strict>>;
                origin: z.ZodOptional<z.ZodEnum<{
                    "admin-console": "admin-console";
                }>>;
                inboundHook: z.ZodOptional<z.ZodObject<{
                    trigger: z.ZodEnum<{
                        default: "default";
                        suppress: "suppress";
                        force: "force";
                    }>;
                    hidden: z.ZodBoolean;
                    annotation: z.ZodOptional<z.ZodString>;
                    extensions: z.ZodArray<z.ZodString>;
                    problems: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                scheduledTask: z.ZodOptional<z.ZodObject<{
                    label: z.ZodString;
                    extensionName: z.ZodOptional<z.ZodString>;
                    note: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"connection-fact">;
    data: z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "ConnectionEventId", "out">;
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        activityKey: z.ZodString;
        summary: z.ZodString;
        actor: z.ZodOptional<z.ZodObject<{
            identityId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
            displayName: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        subject: z.ZodOptional<z.ZodObject<{
            identityId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
            displayName: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        occurredAt: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"runtime">;
    data: z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        episodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
        phase: z.ZodEnum<{
            idle: "idle";
            thinking: "thinking";
            "using-tool": "using-tool";
            "waiting-input": "waiting-input";
            unavailable: "unavailable";
        }>;
        summary: z.ZodString;
        pendingInjectCount: z.ZodNumber;
        occupancy: z.ZodOptional<z.ZodObject<{
            projectedTokens: z.ZodNumber;
            contextWindow: z.ZodNumber;
            breakdown: z.ZodOptional<z.ZodObject<{
                systemTokens: z.ZodNumber;
                toolsTokens: z.ZodNumber;
                messageTokens: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        cache: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"episode">;
            aggregate: z.ZodObject<{
                usageRequestCount: z.ZodNumber;
                observedRequestCount: z.ZodNumber;
                shareRequestCount: z.ZodNumber;
                hitRequestCount: z.ZodNumber;
                uncachedInputTokens: z.ZodNumber;
                cacheReadTokens: z.ZodNumber;
                cacheWriteTokens: z.ZodNumber;
                averageRequestReadShare: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            recent: z.ZodObject<{
                windowSize: z.ZodNumber;
                samples: z.ZodArray<z.ZodObject<{
                    turn: z.ZodNumber;
                    step: z.ZodNumber;
                    at: z.ZodOptional<z.ZodNumber>;
                    uncachedInputTokens: z.ZodNumber;
                    cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                    cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        performance: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"episode">;
            aggregate: z.ZodObject<{
                steps: z.ZodNumber;
                llmMs: z.ZodNumber;
                toolMs: z.ZodNumber;
                ttftMs: z.ZodNumber;
                ttftSteps: z.ZodNumber;
                decodeMs: z.ZodNumber;
                decodeTokens: z.ZodNumber;
                decodeSteps: z.ZodNumber;
                retryCount: z.ZodNumber;
                retryDelayMs: z.ZodNumber;
            }, z.core.$strict>;
            recent: z.ZodObject<{
                windowSize: z.ZodNumber;
                samples: z.ZodArray<z.ZodObject<{
                    turn: z.ZodNumber;
                    step: z.ZodNumber;
                    at: z.ZodOptional<z.ZodNumber>;
                    firstTokenMs: z.ZodOptional<z.ZodNumber>;
                    decodeMs: z.ZodOptional<z.ZodNumber>;
                    outputTokens: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        turns: z.ZodArray<z.ZodObject<{
            turn: z.ZodNumber;
            state: z.ZodEnum<{
                error: "error";
                interrupted: "interrupted";
                completed: "completed";
                "in-progress": "in-progress";
                unreplied: "unreplied";
                aborted: "aborted";
                "max-tokens": "max-tokens";
            }>;
            producedReply: z.ZodBoolean;
            responseState: z.ZodEnum<{
                pending: "pending";
                interrupted: "interrupted";
                sent: "sent";
                "not-required": "not-required";
                finished: "finished";
                "protocol-failed": "protocol-failed";
            }>;
            error: z.ZodOptional<z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                step: z.ZodNumber;
                tools: z.ZodArray<z.ZodObject<{
                    callId: z.ZodString;
                    name: z.ZodString;
                    displayName: z.ZodString;
                    state: z.ZodEnum<{
                        running: "running";
                        failed: "failed";
                        succeeded: "succeeded";
                    }>;
                    inputPreview: z.ZodOptional<z.ZodString>;
                    resultPreview: z.ZodOptional<z.ZodString>;
                    wroteToChannel: z.ZodOptional<z.ZodBoolean>;
                    deliveryState: z.ZodOptional<z.ZodEnum<{
                        unknown: "unknown";
                        failed: "failed";
                        sent: "sent";
                        "partially-sent": "partially-sent";
                    }>>;
                    durationMs: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                internalOutput: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodLiteral<"internal-output">;
                    text: z.ZodOptional<z.ZodString>;
                    reasoning: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                durationMs: z.ZodOptional<z.ZodNumber>;
                firstTokenMs: z.ZodOptional<z.ZodNumber>;
                usage: z.ZodOptional<z.ZodObject<{
                    inputTokens: z.ZodNumber;
                    outputTokens: z.ZodNumber;
                    totalTokens: z.ZodOptional<z.ZodNumber>;
                    cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                    cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
                    reasoningTokens: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
            startedAt: z.ZodOptional<z.ZodNumber>;
            endedAt: z.ZodOptional<z.ZodNumber>;
            triggerEventId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">>;
        }, z.core.$strict>>;
        revision: z.ZodNumber;
        truncated: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"extensions-changed">;
    data: z.ZodObject<{
        changed: z.ZodLiteral<true>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"dsh-plugins-changed">;
    data: z.ZodObject<{
        changed: z.ZodLiteral<true>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"dsh-plugin-operation">;
    data: z.ZodObject<{
        operationId: z.ZodString;
        kind: z.ZodEnum<{
            inspect: "inspect";
            install: "install";
        }>;
        phase: z.ZodEnum<{
            download: "download";
            dependencies: "dependencies";
            "build-scripts": "build-scripts";
            validation: "validation";
            publish: "publish";
        }>;
        status: z.ZodEnum<{
            running: "running";
            failed: "failed";
            done: "done";
        }>;
        message: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"dynamic-changed">;
    data: z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"dsh-settings-changed">;
    data: z.ZodObject<{
        namespace: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"dsh-credentials-changed">;
    data: z.ZodObject<{
        ref: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"status">;
    data: z.ZodObject<{
        ok: z.ZodBoolean;
        message: z.ZodString;
        replay: z.ZodOptional<z.ZodEnum<{
            none: "none";
            complete: "complete";
            expired: "expired";
        }>>;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"attention-changed">;
    data: z.ZodObject<{
        revision: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    event: z.ZodLiteral<"binding-change">;
    data: z.ZodObject<{
        operationId: z.ZodString;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        kind: z.ZodEnum<{
            bind: "bind";
            replace: "replace";
            clear: "clear";
        }>;
        step: z.ZodString;
        status: z.ZodEnum<{
            running: "running";
            failed: "failed";
            done: "done";
            skipped: "skipped";
        }>;
        message: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>], "event">;
export type HostSseEvent = z.output<typeof HostSseEventSchema>;
/** Request content a model accepts; `image` enables native vision for agents using the model. */
export declare const LlmModelInputModalitiesSchema: z.ZodArray<z.ZodEnum<{
    text: "text";
    image: "image";
}>>;
export declare const LlmProviderModelSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    contextWindow: z.ZodOptional<z.ZodNumber>;
    maxTokens: z.ZodOptional<z.ZodNumber>;
    inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        text: "text";
        image: "image";
    }>>>;
}, z.core.$strict>;
export declare const LlmDiscoveredModelSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodOptional<z.ZodString>;
    contextWindow: z.ZodOptional<z.ZodNumber>;
    maxTokens: z.ZodOptional<z.ZodNumber>;
    inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        text: "text";
        image: "image";
    }>>>;
}, z.core.$strict>;
export declare const LlmProviderCredentialSchema: z.ZodObject<{
    configured: z.ZodBoolean;
    source: z.ZodOptional<z.ZodString>;
    writable: z.ZodBoolean;
}, z.core.$strict>;
export declare const LlmProviderViewSchema: z.ZodObject<{
    provider: z.ZodString;
    displayName: z.ZodString;
    settingsNs: z.ZodString;
    settingsPath: z.ZodArray<z.ZodString>;
    settingsRevision: z.ZodNumber;
    declared: z.ZodBoolean;
    active: z.ZodBoolean;
    configured: z.ZodBoolean;
    baseURL: z.ZodOptional<z.ZodString>;
    api: z.ZodOptional<z.ZodString>;
    credential: z.ZodOptional<z.ZodObject<{
        configured: z.ZodBoolean;
        source: z.ZodOptional<z.ZodString>;
        writable: z.ZodBoolean;
    }, z.core.$strict>>;
    models: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        contextWindow: z.ZodOptional<z.ZodNumber>;
        maxTokens: z.ZodOptional<z.ZodNumber>;
        inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            text: "text";
            image: "image";
        }>>>;
    }, z.core.$strict>>;
    modelsCustomized: z.ZodBoolean;
    discoverable: z.ZodBoolean;
}, z.core.$strict>;
export declare const LlmProviderSettingsSchema: z.ZodObject<{
    writable: z.ZodBoolean;
    protocols: z.ZodArray<z.ZodString>;
    providers: z.ZodArray<z.ZodObject<{
        provider: z.ZodString;
        displayName: z.ZodString;
        settingsNs: z.ZodString;
        settingsPath: z.ZodArray<z.ZodString>;
        settingsRevision: z.ZodNumber;
        declared: z.ZodBoolean;
        active: z.ZodBoolean;
        configured: z.ZodBoolean;
        baseURL: z.ZodOptional<z.ZodString>;
        api: z.ZodOptional<z.ZodString>;
        credential: z.ZodOptional<z.ZodObject<{
            configured: z.ZodBoolean;
            source: z.ZodOptional<z.ZodString>;
            writable: z.ZodBoolean;
        }, z.core.$strict>>;
        models: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodString;
            contextWindow: z.ZodOptional<z.ZodNumber>;
            maxTokens: z.ZodOptional<z.ZodNumber>;
            inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                text: "text";
                image: "image";
            }>>>;
        }, z.core.$strict>>;
        modelsCustomized: z.ZodBoolean;
        discoverable: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const ConnectionTestResultSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    status: z.ZodLiteral<"received">;
    channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    platformMessageId: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"sent">;
    channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    platformMessageId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodEnum<{
        "waiting-for-message": "waiting-for-message";
        "needs-channel": "needs-channel";
        "needs-target": "needs-target";
        "not-connected": "not-connected";
    }>;
    message: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"failed">;
    kind: z.ZodString;
    message: z.ZodString;
    retryAfterMs: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>], "status">;
type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
type AnySchema = z.ZodType;
export interface HostApiContract<Method extends HttpMethod = HttpMethod, Params extends AnySchema = AnySchema, Request extends AnySchema = AnySchema, Response extends AnySchema = AnySchema, ErrorSchema extends AnySchema = AnySchema> {
    readonly method: Method;
    readonly timeoutMs?: number;
    readonly responseFormat?: 'json' | 'bytes';
    readonly invalidatesSnapshot?: boolean;
    encodeRequest?(input: z.output<Request>): {
        readonly body: string | Uint8Array;
        readonly headers: Readonly<Record<string, string>>;
    };
    readonly path: string;
    readonly params: Params;
    readonly request: Request;
    readonly response: Response;
    readonly error: ErrorSchema;
    readonly parseParams: (input: unknown) => z.output<Params>;
    readonly parseRequest: (input: unknown) => z.output<Request>;
    readonly parseResponse: (input: unknown) => z.output<Response>;
    readonly parseError: (input: unknown) => z.output<ErrorSchema>;
}
/** 扩展包导入检查的结果：本地文件与社区下载共用同一确认步骤。 */
export declare const ExtensionImportInspectionSchema: z.ZodObject<{
    token: z.ZodString;
    extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
    slug: z.ZodString;
    displayName: z.ZodString;
    scope: z.ZodEnum<{
        agent: "agent";
        "host-adapter": "host-adapter";
        "host-ui": "host-ui";
    }>;
    idempotent: z.ZodBoolean;
    slugConflict: z.ZodBoolean;
}, z.core.$strict>;
export declare const AgentRevisionChangedFieldSchema: z.ZodEnum<{
    model: "model";
    name: "name";
    approvalPolicy: "approvalPolicy";
    persona: "persona";
    imagePolicy: "imagePolicy";
    capabilities: "capabilities";
}>;
export declare const AgentRevisionHistorySchema: z.ZodObject<{
    agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    currentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
    revisions: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
        revision: z.ZodNumber;
        createdAt: z.ZodNumber;
        displayName: z.ZodString;
        model: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
        }, z.core.$strict>;
        changedFields: z.ZodArray<z.ZodEnum<{
            model: "model";
            name: "name";
            approvalPolicy: "approvalPolicy";
            persona: "persona";
            imagePolicy: "imagePolicy";
            capabilities: "capabilities";
        }>>;
        current: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type AgentRevisionHistory = z.output<typeof AgentRevisionHistorySchema>;
export declare const HostApiContracts: {
    readonly retryRuntimeCompatibility: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        objectKind: z.ZodEnum<{
            agent: "agent";
            extension: "extension";
            adapter: "adapter";
            "model-provider": "model-provider";
            "dsh-plugin": "dsh-plugin";
            "client-page": "client-page";
        }>;
        objectId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        diagnostics: z.ZodArray<z.ZodObject<{
            objectKind: z.ZodEnum<{
                agent: "agent";
                extension: "extension";
                adapter: "adapter";
                "model-provider": "model-provider";
                "dsh-plugin": "dsh-plugin";
                "client-page": "client-page";
            }>;
            objectId: z.ZodString;
            objectVersion: z.ZodString;
            configurationRevision: z.ZodString;
            runtimeFingerprint: z.ZodString;
            status: z.ZodEnum<{
                checking: "checking";
                compatible: "compatible";
                isolated: "isolated";
            }>;
            phase: z.ZodEnum<{
                restore: "restore";
                configuration: "configuration";
                dependency: "dependency";
                build: "build";
                load: "load";
                render: "render";
                dispose: "dispose";
            }>;
            reason: z.ZodOptional<z.ZodString>;
            retryable: z.ZodBoolean;
            checkedAt: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly snapshot: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        upgrade: z.ZodOptional<z.ZodObject<{
            runtimeVersion: z.ZodString;
            sessionCompatibilityId: z.ZodString;
            backupId: z.ZodOptional<z.ZodString>;
            resetContexts: z.ZodBoolean;
            diagnostics: z.ZodArray<z.ZodObject<{
                objectKind: z.ZodEnum<{
                    agent: "agent";
                    extension: "extension";
                    adapter: "adapter";
                    "model-provider": "model-provider";
                    "dsh-plugin": "dsh-plugin";
                    "client-page": "client-page";
                }>;
                objectId: z.ZodString;
                objectVersion: z.ZodString;
                configurationRevision: z.ZodString;
                runtimeFingerprint: z.ZodString;
                status: z.ZodEnum<{
                    checking: "checking";
                    compatible: "compatible";
                    isolated: "isolated";
                }>;
                phase: z.ZodEnum<{
                    restore: "restore";
                    configuration: "configuration";
                    dependency: "dependency";
                    build: "build";
                    load: "load";
                    render: "render";
                    dispose: "dispose";
                }>;
                reason: z.ZodOptional<z.ZodString>;
                retryable: z.ZodBoolean;
                checkedAt: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        cursor: z.ZodObject<{
            epoch: z.ZodString;
            sequence: z.ZodNumber;
        }, z.core.$strict>;
        diagnosticsSampledAt: z.ZodNumber;
        productMetadata: z.ZodOptional<z.ZodObject<{
            displayName: z.ZodString;
            organizationName: z.ZodString;
            version: z.ZodString;
            releaseId: z.ZodString;
            repositoryUrl: z.ZodURL;
            licenseSpdx: z.ZodNullable<z.ZodString>;
            dshVersion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        models: z.ZodArray<z.ZodObject<{
            provider: z.ZodString;
            providerName: z.ZodString;
            id: z.ZodString;
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            inputModalities: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        capabilityAvailability: z.ZodObject<{
            subagents: z.ZodObject<{
                available: z.ZodBoolean;
            }, z.core.$strict>;
            webSearch: z.ZodObject<{
                provider: z.ZodLiteral<"deepseek-official">;
                available: z.ZodBoolean;
                credentialConfigured: z.ZodBoolean;
                credentialReference: z.ZodString;
                maxUsesPerCall: z.ZodNumber;
                maxResultsPerCall: z.ZodNumber;
                timeoutMs: z.ZodNumber;
            }, z.core.$strict>;
        }, z.core.$strict>;
        connectionAdapters: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            displayName: z.ZodString;
            description: z.ZodString;
            provisioning: z.ZodEnum<{
                "user-created": "user-created";
                "system-singleton": "system-singleton";
            }>;
            aliasEditable: z.ZodBoolean;
            channelDiscovery: z.ZodEnum<{
                "host-created": "host-created";
                "adapter-observed": "adapter-observed";
            }>;
            channelKinds: z.ZodArray<z.ZodEnum<{
                internal: "internal";
                direct: "direct";
                group: "group";
            }>>;
            activities: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                scope: z.ZodEnum<{
                    channel: "channel";
                    connection: "connection";
                }>;
                displayName: z.ZodString;
                description: z.ZodString;
                icon: z.ZodOptional<z.ZodEnum<{
                    "app-window": "app-window";
                    "bar-chart": "bar-chart";
                    "book-open": "book-open";
                    boxes: "boxes";
                    database: "database";
                    "file-text": "file-text";
                    folder: "folder";
                    globe: "globe";
                    "layout-dashboard": "layout-dashboard";
                    puzzle: "puzzle";
                    terminal: "terminal";
                    workflow: "workflow";
                    wrench: "wrench";
                }>>;
                triggerable: z.ZodBoolean;
                channelKinds: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    internal: "internal";
                    direct: "direct";
                    group: "group";
                }>>>;
            }, z.core.$strict>>;
            features: z.ZodObject<{
                processingFeedback: z.ZodOptional<z.ZodObject<{
                    channelKinds: z.ZodArray<z.ZodEnum<{
                        direct: "direct";
                        group: "group";
                    }>>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            diagnostics: z.ZodObject<{
                receive: z.ZodBoolean;
                send: z.ZodBoolean;
            }, z.core.$strict>;
            creation: z.ZodOptional<z.ZodObject<{
                mode: z.ZodEnum<{
                    "schema-form": "schema-form";
                    "qr-login": "qr-login";
                }>;
                actionLabel: z.ZodOptional<z.ZodString>;
                pendingLabel: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            platformActions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                title: z.ZodString;
                description: z.ZodString;
                risk: z.ZodEnum<{
                    low: "low";
                    admin: "admin";
                }>;
                channelKinds: z.ZodArray<z.ZodEnum<{
                    direct: "direct";
                    group: "group";
                }>>;
                parameters: z.ZodObject<{
                    type: z.ZodLiteral<"object">;
                    properties: z.ZodRecord<z.ZodString, z.ZodJSONSchema>;
                    required: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
            }, z.core.$strict>>>;
            rawApi: z.ZodOptional<z.ZodObject<{
                description: z.ZodString;
            }, z.core.$strict>>;
            configSchema: z.ZodType<import("./config-schema.js").ConfigSchemaNode, unknown, z.core.$ZodTypeInternals<import("./config-schema.js").ConfigSchemaNode, unknown>> & z.ZodType<{
                readonly type: "object";
                readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
                readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
            }, unknown, z.core.$ZodTypeInternals<{
                readonly type: "object";
                readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
                readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
            }, unknown>>;
        }, z.core.$strict>>;
        notificationSettings: z.ZodObject<{
            revision: z.ZodOptional<z.ZodNumber>;
            system: z.ZodObject<{
                enabled: z.ZodBoolean;
            }, z.core.$strict>;
            bark: z.ZodObject<{
                enabled: z.ZodBoolean;
                serverUrl: z.ZodURL;
                deviceKeyConfigured: z.ZodBoolean;
            }, z.core.$strict>;
            events: z.ZodRecord<z.ZodEnum<{
                "dynamic-client-approval-requested": "dynamic-client-approval-requested";
            }>, z.ZodBoolean>;
        }, z.core.$strict>;
        agents: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            displayName: z.ZodString;
            persona: z.ZodString;
            personaDocument: z.ZodObject<{
                version: z.ZodLiteral<1>;
                segments: z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                    type: z.ZodLiteral<"text">;
                    text: z.ZodString;
                }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                    type: z.ZodLiteral<"reference">;
                    kind: z.ZodLiteral<"platform-user">;
                    targetId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
                    labelSnapshot: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"reference">;
                    kind: z.ZodLiteral<"channel">;
                    targetId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                    labelSnapshot: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"reference">;
                    kind: z.ZodLiteral<"extension">;
                    targetId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
                    labelSnapshot: z.ZodString;
                }, z.core.$strict>], "kind">]>>;
            }, z.core.$strict>;
            model: z.ZodObject<{
                provider: z.ZodString;
                model: z.ZodString;
                reasoningEffort: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            capabilities: z.ZodObject<{
                subagents: z.ZodBoolean;
                fileTools: z.ZodBoolean;
                webSearch: z.ZodBoolean;
                dynamicCreation: z.ZodBoolean;
                developmentShell: z.ZodBoolean;
                unrestrictedFileAccess: z.ZodBoolean;
                scheduledTasks: z.ZodDefault<z.ZodBoolean>;
            }, z.core.$strict>;
            imagePolicy: z.ZodObject<{
                history: z.ZodObject<{
                    mode: z.ZodLiteral<"persistent-distinct">;
                    detail: z.ZodEnum<{
                        high: "high";
                        low: "low";
                        auto: "auto";
                    }>;
                    restoreAfterCompaction: z.ZodObject<{
                        recentMessages: z.ZodNumber;
                        maxImages: z.ZodNumber;
                    }, z.core.$strict>;
                }, z.core.$strict>;
                textModel: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    mode: z.ZodLiteral<"disabled">;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"auxiliary">;
                    model: z.ZodObject<{
                        provider: z.ZodString;
                        model: z.ZodString;
                        reasoningEffort: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>;
                    maxTokens: z.ZodNumber;
                }, z.core.$strict>], "mode">;
            }, z.core.$strict>;
            dynamicClientApprovalPolicy: z.ZodEnum<{
                manual: "manual";
                automatic: "automatic";
            }>;
            imageDiagnostics: z.ZodObject<{
                route: z.ZodObject<{
                    mode: z.ZodEnum<{
                        direct: "direct";
                        unavailable: "unavailable";
                        delegated: "delegated";
                    }>;
                    provider: z.ZodOptional<z.ZodString>;
                    model: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                activeSessions: z.ZodNumber;
                residentImages: z.ZodNumber;
                duplicateImagesSkipped: z.ZodNumber;
                lastInspection: z.ZodOptional<z.ZodObject<{
                    mode: z.ZodEnum<{
                        direct: "direct";
                        delegated: "delegated";
                    }>;
                    imageCount: z.ZodNumber;
                    provider: z.ZodOptional<z.ZodString>;
                    model: z.ZodOptional<z.ZodString>;
                    cacheHit: z.ZodBoolean;
                    usage: z.ZodOptional<z.ZodObject<{
                        inputTokens: z.ZodNumber;
                        outputTokens: z.ZodNumber;
                        totalTokens: z.ZodOptional<z.ZodNumber>;
                        cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                        cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
                        reasoningTokens: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strict>>;
                    errorCode: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                lastRestoration: z.ZodOptional<z.ZodObject<{
                    compactionId: z.ZodString;
                    candidateCount: z.ZodNumber;
                    restoredCount: z.ZodNumber;
                    skippedCount: z.ZodNumber;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                blockers: z.ZodArray<z.ZodString>;
            }, z.core.$strict>;
            currentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
            runtimeStatus: z.ZodEnum<{
                running: "running";
                idle: "idle";
            }>;
            runtimePhase: z.ZodDefault<z.ZodEnum<{
                idle: "idle";
                thinking: "thinking";
                "using-tool": "using-tool";
                "waiting-input": "waiting-input";
                unavailable: "unavailable";
            }>>;
            createdAt: z.ZodNumber;
            channels: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
            appearance: z.ZodDefault<z.ZodObject<{
                hue: z.ZodOptional<z.ZodNumber>;
                avatarAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        channels: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
            platformChannelId: z.ZodString;
            kind: z.ZodEnum<{
                internal: "internal";
                direct: "direct";
                group: "group";
            }>;
            displayName: z.ZodOptional<z.ZodString>;
            boundAgentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
            runtimePhase: z.ZodDefault<z.ZodEnum<{
                idle: "idle";
                thinking: "thinking";
                "using-tool": "using-tool";
                "waiting-input": "waiting-input";
                unavailable: "unavailable";
            }>>;
            activity: z.ZodDefault<z.ZodObject<{
                lastActivityAt: z.ZodOptional<z.ZodNumber>;
                lastMessage: z.ZodOptional<z.ZodObject<{
                    role: z.ZodEnum<{
                        agent: "agent";
                        system: "system";
                        member: "member";
                        admin: "admin";
                    }>;
                    author: z.ZodString;
                    preview: z.ZodString;
                    occurredAt: z.ZodNumber;
                }, z.core.$strict>>;
                unreadCount: z.ZodNumber;
                unreadCapped: z.ZodBoolean;
            }, z.core.$strict>>;
            bindings: z.ZodArray<z.ZodObject<{
                channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
                triggerPolicy: z.ZodEnum<{
                    always: "always";
                    "mentioned-or-replied": "mentioned-or-replied";
                    command: "command";
                    "observe-only": "observe-only";
                }>;
                processingFeedback: z.ZodDefault<z.ZodEnum<{
                    auto: "auto";
                    off: "off";
                }>>;
                activityTriggerOverrides: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodBoolean>>;
                boundAt: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workTreeOrder: z.ZodDefault<z.ZodObject<{
            agentIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
            channelIdsByAgent: z.ZodRecord<z.core.$ZodBranded<z.ZodString, "AgentId", "out">, z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>>;
            unboundChannelIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
        }, z.core.$strict>>;
        messages: z.ZodArray<z.ZodObject<{
            id: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            role: z.ZodEnum<{
                agent: "agent";
                system: "system";
                member: "member";
            }>;
            parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"text">;
                text: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"mention">;
                memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"image">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                alt: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"file">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                name: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"audio">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"quote">;
                messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"rich">;
                adapterKey: z.ZodString;
                kind: z.ZodString;
                summary: z.ZodString;
                title: z.ZodOptional<z.ZodString>;
                source: z.ZodOptional<z.ZodString>;
                targetUrl: z.ZodOptional<z.ZodURL>;
                previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
                extension: z.ZodOptional<z.ZodJSONSchema>;
            }, z.core.$strict>], "type">>;
            sender: z.ZodOptional<z.ZodObject<{
                memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            mentionedConnectionAccount: z.ZodOptional<z.ZodBoolean>;
            activityKey: z.ZodOptional<z.ZodString>;
            targetLogicalMessageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">>;
            occurredAt: z.ZodNumber;
            deliveryState: z.ZodOptional<z.ZodEnum<{
                unknown: "unknown";
                failed: "failed";
                planned: "planned";
                sending: "sending";
                sent: "sent";
                "partially-sent": "partially-sent";
            }>>;
            deliveryResolution: z.ZodOptional<z.ZodObject<{
                action: z.ZodEnum<{
                    retry: "retry";
                    "confirm-delivered": "confirm-delivered";
                }>;
                resolvedAt: z.ZodNumber;
            }, z.core.$strict>>;
            origin: z.ZodOptional<z.ZodEnum<{
                "admin-console": "admin-console";
            }>>;
            inboundHook: z.ZodOptional<z.ZodObject<{
                trigger: z.ZodEnum<{
                    default: "default";
                    suppress: "suppress";
                    force: "force";
                }>;
                hidden: z.ZodBoolean;
                annotation: z.ZodOptional<z.ZodString>;
                extensions: z.ZodArray<z.ZodString>;
                problems: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            scheduledTask: z.ZodOptional<z.ZodObject<{
                label: z.ZodString;
                extensionName: z.ZodOptional<z.ZodString>;
                note: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        connections: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
            adapterKey: z.ZodString;
            alias: z.ZodOptional<z.ZodString>;
            activityTriggerDefaults: z.ZodDefault<z.ZodArray<z.ZodString>>;
            status: z.ZodDefault<z.ZodObject<{
                state: z.ZodEnum<{
                    failed: "failed";
                    stopped: "stopped";
                    connecting: "connecting";
                    connected: "connected";
                    reconnecting: "reconnecting";
                }>;
                message: z.ZodOptional<z.ZodString>;
                credentialConfigured: z.ZodBoolean;
                proactiveSend: z.ZodBoolean;
                accountReference: z.ZodOptional<z.ZodString>;
                implementation: z.ZodOptional<z.ZodObject<{
                    name: z.ZodOptional<z.ZodString>;
                    version: z.ZodOptional<z.ZodString>;
                    protocolVersion: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                optionalCapabilities: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodEnum<{
                    unknown: "unknown";
                    available: "available";
                    unsupported: "unsupported";
                    degraded: "degraded";
                }>>>;
                activities: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
                    state: z.ZodEnum<{
                        unknown: "unknown";
                        disabled: "disabled";
                        available: "available";
                        unsupported: "unsupported";
                        degraded: "degraded";
                    }>;
                    reason: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>>;
                processingFeedback: z.ZodOptional<z.ZodObject<{
                    state: z.ZodEnum<{
                        unknown: "unknown";
                        disabled: "disabled";
                        available: "available";
                        unsupported: "unsupported";
                        degraded: "degraded";
                    }>;
                    reason: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            channelCount: z.ZodNumber;
            knownChannels: z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                name: z.ZodString;
                kind: z.ZodEnum<{
                    internal: "internal";
                    direct: "direct";
                    group: "group";
                }>;
            }, z.core.$strict>>;
            lastInbound: z.ZodOptional<z.ZodObject<{
                channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                platformMessageId: z.ZodString;
                receivedAt: z.ZodNumber;
            }, z.core.$strict>>;
            receiveTest: z.ZodOptional<z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
                status: z.ZodLiteral<"received">;
                channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                platformMessageId: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                status: z.ZodLiteral<"sent">;
                channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                platformMessageId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                status: z.ZodEnum<{
                    "waiting-for-message": "waiting-for-message";
                    "needs-channel": "needs-channel";
                    "needs-target": "needs-target";
                    "not-connected": "not-connected";
                }>;
                message: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                status: z.ZodLiteral<"failed">;
                kind: z.ZodString;
                message: z.ZodString;
                retryAfterMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>], "status">>>;
            sendTest: z.ZodOptional<z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
                status: z.ZodLiteral<"received">;
                channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                platformMessageId: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                status: z.ZodLiteral<"sent">;
                channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                platformMessageId: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                status: z.ZodEnum<{
                    "waiting-for-message": "waiting-for-message";
                    "needs-channel": "needs-channel";
                    "needs-target": "needs-target";
                    "not-connected": "not-connected";
                }>;
                message: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                status: z.ZodLiteral<"failed">;
                kind: z.ZodString;
                message: z.ZodString;
                retryAfterMs: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>], "status">>>;
            configuration: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>>;
        }, z.core.$strict>>;
        archivedConnections: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
            adapterKey: z.ZodString;
            alias: z.ZodOptional<z.ZodString>;
            channelCount: z.ZodNumber;
            archivedAt: z.ZodNumber;
        }, z.core.$strict>>>;
        extensions: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
            scope: z.ZodEnum<{
                agent: "agent";
                "host-adapter": "host-adapter";
                "host-ui": "host-ui";
            }>;
            slug: z.ZodString;
            displayName: z.ZodString;
            description: z.ZodString;
            createdByAgentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
            revisions: z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
                revisionNumber: z.ZodNumber;
                format: z.ZodOptional<z.ZodEnum<{
                    unavailable: "unavailable";
                    current: "current";
                }>>;
                ui: z.ZodDefault<z.ZodObject<{
                    panels: z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        anchor: z.ZodEnum<{
                            agent: "agent";
                            channel: "channel";
                            extension: "extension";
                            connection: "connection";
                        }>;
                        title: z.ZodString;
                        icon: z.ZodOptional<z.ZodEnum<{
                            "app-window": "app-window";
                            "bar-chart": "bar-chart";
                            "book-open": "book-open";
                            boxes: "boxes";
                            database: "database";
                            "file-text": "file-text";
                            folder: "folder";
                            globe: "globe";
                            "layout-dashboard": "layout-dashboard";
                            puzzle: "puzzle";
                            terminal: "terminal";
                            workflow: "workflow";
                            wrench: "wrench";
                        }>>;
                        densities: z.ZodArray<z.ZodEnum<{
                            compact: "compact";
                            full: "full";
                        }>>;
                        role: z.ZodOptional<z.ZodEnum<{
                            status: "status";
                            diagnostics: "diagnostics";
                            setup: "setup";
                        }>>;
                        when: z.ZodOptional<z.ZodObject<{
                            channelKinds: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                                internal: "internal";
                                direct: "direct";
                                group: "group";
                            }>>>;
                        }, z.core.$strict>>;
                        kind: z.ZodLiteral<"panel">;
                    }, z.core.$strict>>;
                    toolViews: z.ZodArray<z.ZodString>;
                    messageRenderers: z.ZodArray<z.ZodString>;
                }, z.core.$strict>>;
                configSchema: z.ZodOptional<z.ZodType<import("./config-schema.js").ConfigSchemaNode, unknown, z.core.$ZodTypeInternals<import("./config-schema.js").ConfigSchemaNode, unknown>> & z.ZodType<{
                    readonly type: "object";
                    readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
                    readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
                }, unknown, z.core.$ZodTypeInternals<{
                    readonly type: "object";
                    readonly dict: Readonly<Record<string, import("./config-schema.js").ConfigSchemaNode>>;
                    readonly meta?: import("./config-schema.js").ConfigSchemaMeta | undefined;
                }, unknown>>>;
                createdAt: z.ZodNumber;
                source: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodLiteral<"community">;
                    communityUrl: z.ZodString;
                    releaseId: z.ZodString;
                    publisherHandle: z.ZodString;
                    installedAt: z.ZodNumber;
                }, z.core.$strict>>;
                scope: z.ZodEnum<{
                    agent: "agent";
                    "host-adapter": "host-adapter";
                    "host-ui": "host-ui";
                }>;
                contributions: z.ZodArray<z.ZodString>;
                verification: z.ZodOptional<z.ZodObject<{
                    verifiedAt: z.ZodNumber;
                    dshVersion: z.ZodString;
                    contractVersion: z.ZodString;
                    hostBuilt: z.ZodBoolean;
                    clientBuilt: z.ZodBoolean;
                    buildKey: z.ZodString;
                    toolInvocationCount: z.ZodNumber;
                    rpcMethods: z.ZodArray<z.ZodString>;
                    renderedPanels: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    renderedToolViews: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    renderedMessageRenderers: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    renderedPages: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        kind: z.ZodLiteral<"host-page">;
                        entryId: z.ZodString;
                        title: z.ZodString;
                        description: z.ZodOptional<z.ZodString>;
                        icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                            kind: z.ZodLiteral<"host-icon">;
                            name: z.ZodEnum<{
                                "app-window": "app-window";
                                "bar-chart": "bar-chart";
                                "book-open": "book-open";
                                boxes: "boxes";
                                database: "database";
                                "file-text": "file-text";
                                folder: "folder";
                                globe: "globe";
                                "layout-dashboard": "layout-dashboard";
                                puzzle: "puzzle";
                                terminal: "terminal";
                                workflow: "workflow";
                                wrench: "wrench";
                            }>;
                        }, z.core.$strict>, z.ZodObject<{
                            kind: z.ZodLiteral<"svg">;
                            path: z.ZodString;
                            sha256: z.ZodString;
                        }, z.core.$strict>], "kind">;
                        objectPane: z.ZodEnum<{
                            hidden: "hidden";
                            navigation: "navigation";
                        }>;
                        startPath: z.ZodString;
                    }, z.core.$strict>>>;
                    usedUiComponents: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                        Button: "Button";
                        IconButton: "IconButton";
                        Input: "Input";
                        Textarea: "Textarea";
                        Select: "Select";
                        Switch: "Switch";
                        Tabs: "Tabs";
                        Dialog: "Dialog";
                        Popover: "Popover";
                        Tooltip: "Tooltip";
                        Field: "Field";
                        StatusBadge: "StatusBadge";
                        InlineFeedback: "InlineFeedback";
                        EmptyState: "EmptyState";
                        Spinner: "Spinner";
                        PageHeader: "PageHeader";
                        MetricStrip: "MetricStrip";
                        Metric: "Metric";
                        Section: "Section";
                        Stack: "Stack";
                        Grid: "Grid";
                        DataTable: "DataTable";
                        PropertyList: "PropertyList";
                        PropertyRow: "PropertyRow";
                    }>>>;
                    pageGeometry: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        entryId: z.ZodString;
                        objectPane: z.ZodEnum<{
                            hidden: "hidden";
                            navigation: "navigation";
                        }>;
                        viewport: z.ZodObject<{
                            width: z.ZodNumber;
                            height: z.ZodNumber;
                        }, z.core.$strict>;
                        insets: z.ZodObject<{
                            top: z.ZodNumber;
                            right: z.ZodNumber;
                            bottom: z.ZodNumber;
                            left: z.ZodNumber;
                        }, z.core.$strict>;
                        contentAxesAligned: z.ZodBoolean;
                        horizontalOverflow: z.ZodBoolean;
                        titleDistinct: z.ZodBoolean;
                    }, z.core.$strict>>>;
                    permissions: z.ZodOptional<z.ZodObject<{
                        permissions: z.ZodArray<z.ZodEnum<{
                            "agents.read": "agents.read";
                            "channels.read": "channels.read";
                            "connections.read": "connections.read";
                            "extensions.read": "extensions.read";
                            "dsh-plugins.read": "dsh-plugins.read";
                            "runtime.read": "runtime.read";
                            "messages.read": "messages.read";
                            "assets.read": "assets.read";
                            "agents.manage": "agents.manage";
                            "channels.manage": "channels.manage";
                            "connections.manage": "connections.manage";
                            "credentials.write": "credentials.write";
                            "messages.send": "messages.send";
                            "notifications.publish": "notifications.publish";
                            "network.request": "network.request";
                        }>>;
                        networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
                        capabilities: z.ZodOptional<z.ZodObject<{
                            network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                                mode: z.ZodLiteral<"domains">;
                                domains: z.ZodArray<z.ZodString>;
                            }, z.core.$strict>, z.ZodObject<{
                                mode: z.ZodLiteral<"config">;
                                fields: z.ZodArray<z.ZodString>;
                            }, z.core.$strict>, z.ZodObject<{
                                mode: z.ZodLiteral<"unrestricted">;
                                purpose: z.ZodString;
                            }, z.core.$strict>], "mode">>;
                            storage: z.ZodOptional<z.ZodObject<{
                                scopes: z.ZodArray<z.ZodEnum<{
                                    agent: "agent";
                                    channel: "channel";
                                    member: "member";
                                    shared: "shared";
                                }>>;
                                quotaBytes: z.ZodOptional<z.ZodNumber>;
                            }, z.core.$strict>>;
                            assets: z.ZodOptional<z.ZodObject<{
                                write: z.ZodLiteral<true>;
                            }, z.core.$strict>>;
                            history: z.ZodOptional<z.ZodObject<{
                                read: z.ZodLiteral<true>;
                            }, z.core.$strict>>;
                            inboundHook: z.ZodOptional<z.ZodObject<{
                                reads: z.ZodEnum<{
                                    triggered: "triggered";
                                    all: "all";
                                }>;
                                mayHide: z.ZodBoolean;
                                mayForceTrigger: z.ZodBoolean;
                                timeoutMs: z.ZodNumber;
                            }, z.core.$strict>>;
                            jobs: z.ZodOptional<z.ZodObject<{
                                declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                                    id: z.ZodString;
                                    label: z.ZodString;
                                    cron: z.ZodString;
                                    timezone: z.ZodOptional<z.ZodString>;
                                }, z.core.$strict>>>;
                                runtime: z.ZodOptional<z.ZodObject<{
                                    maxActive: z.ZodNumber;
                                }, z.core.$strict>>;
                            }, z.core.$strict>>;
                            platform: z.ZodOptional<z.ZodObject<{
                                actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                                    adapter: z.ZodString;
                                    action: z.ZodString;
                                }, z.core.$strict>>>;
                                raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                            }, z.core.$strict>>;
                            llm: z.ZodOptional<z.ZodObject<{
                                maxCallsPerTurn: z.ZodNumber;
                                maxOutputTokens: z.ZodNumber;
                            }, z.core.$strict>>;
                            mcp: z.ZodOptional<z.ZodObject<{
                                servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                                    transport: z.ZodLiteral<"streamable-http">;
                                    name: z.ZodString;
                                    url: z.ZodString;
                                    headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                        secret: z.ZodString;
                                    }, z.core.$strict>]>>>;
                                }, z.core.$strict>, z.ZodObject<{
                                    transport: z.ZodLiteral<"stdio">;
                                    name: z.ZodString;
                                    command: z.ZodString;
                                    args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                                    env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                        secret: z.ZodString;
                                    }, z.core.$strict>]>>>;
                                }, z.core.$strict>], "transport">>;
                            }, z.core.$strict>>;
                            context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                                name: z.ZodString;
                                kind: z.ZodEnum<{
                                    static: "static";
                                    dynamic: "dynamic";
                                }>;
                                maxChars: z.ZodNumber;
                            }, z.core.$strict>>>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    permissionDigest: z.ZodOptional<z.ZodString>;
                    permissionApprovalRequired: z.ZodOptional<z.ZodBoolean>;
                    adapter: z.ZodOptional<z.ZodObject<{
                        apiVersion: z.ZodLiteral<2>;
                        key: z.ZodString;
                        descriptorDigest: z.ZodString;
                        registered: z.ZodBoolean;
                        started: z.ZodBoolean;
                        stopped: z.ZodBoolean;
                        inboundCommitted: z.ZodBoolean;
                        outboundReceipt: z.ZodEnum<{
                            unknown: "unknown";
                            failed: "failed";
                            sent: "sent";
                        }>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            activations: z.ZodArray<z.ZodObject<{
                agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
                extensionRevisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
                config: z.ZodJSONSchema;
                configuredSecrets: z.ZodOptional<z.ZodArray<z.ZodString>>;
                activatedAt: z.ZodNumber;
                runtime: z.ZodOptional<z.ZodObject<{
                    status: z.ZodEnum<{
                        active: "active";
                        "restore-failed": "restore-failed";
                        "dispose-failed": "dispose-failed";
                    }>;
                    message: z.ZodOptional<z.ZodString>;
                    observedAt: z.ZodNumber;
                }, z.core.$strip>>;
                mcpServers: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    state: z.ZodEnum<{
                        unavailable: "unavailable";
                        connecting: "connecting";
                        connected: "connected";
                        "missing-credentials": "missing-credentials";
                    }>;
                    toolCount: z.ZodOptional<z.ZodNumber>;
                    missing: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    message: z.ZodOptional<z.ZodString>;
                    observedAt: z.ZodNumber;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
            installation: z.ZodOptional<z.ZodObject<{
                extensionRevisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
                installedAt: z.ZodNumber;
                config: z.ZodDefault<z.ZodJSONSchema>;
                runtime: z.ZodOptional<z.ZodObject<{
                    status: z.ZodEnum<{
                        active: "active";
                        "restore-failed": "restore-failed";
                        "dispose-failed": "dispose-failed";
                    }>;
                    message: z.ZodOptional<z.ZodString>;
                    observedAt: z.ZodNumber;
                }, z.core.$strip>>;
            }, z.core.$strict>>;
            hostUiPermission: z.ZodOptional<z.ZodObject<{
                declaration: z.ZodObject<{
                    permissions: z.ZodArray<z.ZodEnum<{
                        "agents.read": "agents.read";
                        "channels.read": "channels.read";
                        "connections.read": "connections.read";
                        "extensions.read": "extensions.read";
                        "dsh-plugins.read": "dsh-plugins.read";
                        "runtime.read": "runtime.read";
                        "messages.read": "messages.read";
                        "assets.read": "assets.read";
                        "agents.manage": "agents.manage";
                        "channels.manage": "channels.manage";
                        "connections.manage": "connections.manage";
                        "credentials.write": "credentials.write";
                        "messages.send": "messages.send";
                        "notifications.publish": "notifications.publish";
                        "network.request": "network.request";
                    }>>;
                    networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
                    capabilities: z.ZodOptional<z.ZodObject<{
                        network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                            mode: z.ZodLiteral<"domains">;
                            domains: z.ZodArray<z.ZodString>;
                        }, z.core.$strict>, z.ZodObject<{
                            mode: z.ZodLiteral<"config">;
                            fields: z.ZodArray<z.ZodString>;
                        }, z.core.$strict>, z.ZodObject<{
                            mode: z.ZodLiteral<"unrestricted">;
                            purpose: z.ZodString;
                        }, z.core.$strict>], "mode">>;
                        storage: z.ZodOptional<z.ZodObject<{
                            scopes: z.ZodArray<z.ZodEnum<{
                                agent: "agent";
                                channel: "channel";
                                member: "member";
                                shared: "shared";
                            }>>;
                            quotaBytes: z.ZodOptional<z.ZodNumber>;
                        }, z.core.$strict>>;
                        assets: z.ZodOptional<z.ZodObject<{
                            write: z.ZodLiteral<true>;
                        }, z.core.$strict>>;
                        history: z.ZodOptional<z.ZodObject<{
                            read: z.ZodLiteral<true>;
                        }, z.core.$strict>>;
                        inboundHook: z.ZodOptional<z.ZodObject<{
                            reads: z.ZodEnum<{
                                triggered: "triggered";
                                all: "all";
                            }>;
                            mayHide: z.ZodBoolean;
                            mayForceTrigger: z.ZodBoolean;
                            timeoutMs: z.ZodNumber;
                        }, z.core.$strict>>;
                        jobs: z.ZodOptional<z.ZodObject<{
                            declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                                id: z.ZodString;
                                label: z.ZodString;
                                cron: z.ZodString;
                                timezone: z.ZodOptional<z.ZodString>;
                            }, z.core.$strict>>>;
                            runtime: z.ZodOptional<z.ZodObject<{
                                maxActive: z.ZodNumber;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>;
                        platform: z.ZodOptional<z.ZodObject<{
                            actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                                adapter: z.ZodString;
                                action: z.ZodString;
                            }, z.core.$strict>>>;
                            raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>>;
                        llm: z.ZodOptional<z.ZodObject<{
                            maxCallsPerTurn: z.ZodNumber;
                            maxOutputTokens: z.ZodNumber;
                        }, z.core.$strict>>;
                        mcp: z.ZodOptional<z.ZodObject<{
                            servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                                transport: z.ZodLiteral<"streamable-http">;
                                name: z.ZodString;
                                url: z.ZodString;
                                headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                    secret: z.ZodString;
                                }, z.core.$strict>]>>>;
                            }, z.core.$strict>, z.ZodObject<{
                                transport: z.ZodLiteral<"stdio">;
                                name: z.ZodString;
                                command: z.ZodString;
                                args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                                env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                    secret: z.ZodString;
                                }, z.core.$strict>]>>>;
                            }, z.core.$strict>], "transport">>;
                        }, z.core.$strict>>;
                        context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            name: z.ZodString;
                            kind: z.ZodEnum<{
                                static: "static";
                                dynamic: "dynamic";
                            }>;
                            maxChars: z.ZodNumber;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>;
                permissionDigest: z.ZodString;
                approvalRequired: z.ZodBoolean;
            }, z.core.$strict>>;
            hostClientDiagnostic: z.ZodOptional<z.ZodObject<{
                revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
                status: z.ZodEnum<{
                    failed: "failed";
                    loaded: "loaded";
                }>;
                message: z.ZodOptional<z.ZodString>;
                observedAt: z.ZodNumber;
            }, z.core.$strict>>;
            clientDiagnostics: z.ZodArray<z.ZodObject<{
                agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
                revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
                status: z.ZodEnum<{
                    failed: "failed";
                    loaded: "loaded";
                }>;
                message: z.ZodOptional<z.ZodString>;
                observedAt: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        hostUi: z.ZodDefault<z.ZodObject<{
            preferencesRevision: z.ZodNumber;
            pages: z.ZodArray<z.ZodObject<{
                pageInstanceId: z.core.$ZodBranded<z.ZodString, "HostUiPageInstanceId", "out">;
                owner: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"extension">;
                    extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
                    revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"dsh-plugin">;
                    entryId: z.ZodString;
                    artifactDigest: z.ZodString;
                }, z.core.$strict>], "kind">;
                entryId: z.ZodString;
                title: z.ZodString;
                description: z.ZodOptional<z.ZodString>;
                icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"host-icon">;
                    name: z.ZodEnum<{
                        "app-window": "app-window";
                        "bar-chart": "bar-chart";
                        "book-open": "book-open";
                        boxes: "boxes";
                        database: "database";
                        "file-text": "file-text";
                        folder: "folder";
                        globe: "globe";
                        "layout-dashboard": "layout-dashboard";
                        puzzle: "puzzle";
                        terminal: "terminal";
                        workflow: "workflow";
                        wrench: "wrench";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"svg">;
                    path: z.ZodString;
                    sha256: z.ZodString;
                }, z.core.$strict>], "kind">;
                objectPane: z.ZodEnum<{
                    hidden: "hidden";
                    navigation: "navigation";
                }>;
                startPath: z.ZodString;
                visible: z.ZodBoolean;
                sortOrder: z.ZodNumber;
                routeBase: z.ZodString;
                client: z.ZodObject<{
                    moduleUrl: z.ZodString;
                    buildKey: z.ZodString;
                }, z.core.$strict>;
                diagnostic: z.ZodOptional<z.ZodObject<{
                    status: z.ZodEnum<{
                        ready: "ready";
                        "restore-failed": "restore-failed";
                        "load-failed": "load-failed";
                        "navigation-failed": "navigation-failed";
                        "rpc-failed": "rpc-failed";
                    }>;
                    message: z.ZodOptional<z.ZodString>;
                    observedAt: z.ZodNumber;
                }, z.core.$strict>>;
                createdAt: z.ZodNumber;
                updatedAt: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        dynamic: z.ZodArray<z.ZodObject<{
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
            pluginId: z.ZodString;
            packageId: z.ZodOptional<z.ZodString>;
            currentPackageId: z.ZodOptional<z.ZodString>;
            nextPackageId: z.ZodOptional<z.ZodString>;
            approvalRequestId: z.ZodOptional<z.ZodString>;
            status: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                "client-pending": "client-pending";
                running: "running";
                waiting: "waiting";
                failed: "failed";
                cancelled: "cancelled";
                stopped: "stopped";
            }>;
            activeRun: z.ZodOptional<z.ZodObject<{
                pluginRunId: z.ZodString;
                packageId: z.ZodString;
            }, z.core.$strict>>;
            latestRun: z.ZodOptional<z.ZodObject<{
                pluginRunId: z.ZodString;
                packageId: z.ZodString;
                mode: z.ZodEnum<{
                    run: "run";
                    update: "update";
                }>;
                status: z.ZodEnum<{
                    rejected: "rejected";
                    "awaiting-approval": "awaiting-approval";
                    "starting-host": "starting-host";
                    "client-pending": "client-pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    cancelled: "cancelled";
                    stopped: "stopped";
                }>;
                approvalRequestId: z.ZodOptional<z.ZodString>;
                requiresApproval: z.ZodOptional<z.ZodBoolean>;
                host: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                client: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                error: z.ZodOptional<z.ZodObject<{
                    phase: z.ZodEnum<{
                        approval: "approval";
                        "host-load": "host-load";
                        "host-apply": "host-apply";
                        "client-load": "client-load";
                        "client-apply": "client-apply";
                        "client-render": "client-render";
                    }>;
                    message: z.ZodString;
                    stack: z.ZodOptional<z.ZodString>;
                    pluginId: z.ZodString;
                    packageId: z.ZodString;
                    pluginRunId: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            packages: z.ZodArray<z.ZodObject<{
                packageId: z.ZodString;
                name: z.ZodString;
                purpose: z.ZodString;
                hasHostHalf: z.ZodBoolean;
                hasClientHalf: z.ZodBoolean;
            }, z.core.$strict>>;
            policy: z.ZodObject<{
                turn: z.ZodNumber;
                primaryPluginId: z.ZodOptional<z.ZodString>;
                consecutiveFailures: z.ZodNumber;
                repeatedFingerprintCount: z.ZodNumber;
                lastErrorFingerprint: z.ZodOptional<z.ZodString>;
                blockedReason: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        authoringTasks: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
            title: z.ZodString;
            requirementSummary: z.ZodString;
            status: z.ZodEnum<{
                "awaiting-approval": "awaiting-approval";
                running: "running";
                failed: "failed";
                stopped: "stopped";
                working: "working";
                ready: "ready";
                repairing: "repairing";
                interrupted: "interrupted";
                completed: "completed";
            }>;
            approvalPolicy: z.ZodEnum<{
                "risk-stable": "risk-stable";
                "fully-automatic": "fully-automatic";
            }>;
            approvedRiskDigest: z.ZodOptional<z.ZodString>;
            revision: z.ZodNumber;
            activeAttempt: z.ZodOptional<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
                ordinal: z.ZodNumber;
                name: z.ZodString;
                purpose: z.ZodString;
                state: z.ZodEnum<{
                    rejected: "rejected";
                    "awaiting-approval": "awaiting-approval";
                    "starting-host": "starting-host";
                    failed: "failed";
                    stopped: "stopped";
                    drafting: "drafting";
                    "preflight-failed": "preflight-failed";
                    "loading-client": "loading-client";
                    verifying: "verifying";
                    active: "active";
                }>;
                riskDigest: z.ZodString;
                host: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                client: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                error: z.ZodOptional<z.ZodObject<{
                    phase: z.ZodEnum<{
                        approval: "approval";
                        "host-load": "host-load";
                        "host-apply": "host-apply";
                        "client-load": "client-load";
                        "client-apply": "client-apply";
                        "client-render": "client-render";
                        preflight: "preflight";
                        verification: "verification";
                        settlement: "settlement";
                        restore: "restore";
                    }>;
                    message: z.ZodString;
                    repairable: z.ZodBoolean;
                }, z.core.$strict>>;
                createdAt: z.ZodNumber;
                settledAt: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            candidateAttempt: z.ZodOptional<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
                ordinal: z.ZodNumber;
                name: z.ZodString;
                purpose: z.ZodString;
                state: z.ZodEnum<{
                    rejected: "rejected";
                    "awaiting-approval": "awaiting-approval";
                    "starting-host": "starting-host";
                    failed: "failed";
                    stopped: "stopped";
                    drafting: "drafting";
                    "preflight-failed": "preflight-failed";
                    "loading-client": "loading-client";
                    verifying: "verifying";
                    active: "active";
                }>;
                riskDigest: z.ZodString;
                host: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                client: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                error: z.ZodOptional<z.ZodObject<{
                    phase: z.ZodEnum<{
                        approval: "approval";
                        "host-load": "host-load";
                        "host-apply": "host-apply";
                        "client-load": "client-load";
                        "client-apply": "client-apply";
                        "client-render": "client-render";
                        preflight: "preflight";
                        verification: "verification";
                        settlement: "settlement";
                        restore: "restore";
                    }>;
                    message: z.ZodString;
                    repairable: z.ZodBoolean;
                }, z.core.$strict>>;
                createdAt: z.ZodNumber;
                settledAt: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            verifiedAttempt: z.ZodOptional<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
                ordinal: z.ZodNumber;
                name: z.ZodString;
                purpose: z.ZodString;
                state: z.ZodEnum<{
                    rejected: "rejected";
                    "awaiting-approval": "awaiting-approval";
                    "starting-host": "starting-host";
                    failed: "failed";
                    stopped: "stopped";
                    drafting: "drafting";
                    "preflight-failed": "preflight-failed";
                    "loading-client": "loading-client";
                    verifying: "verifying";
                    active: "active";
                }>;
                riskDigest: z.ZodString;
                host: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                client: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                error: z.ZodOptional<z.ZodObject<{
                    phase: z.ZodEnum<{
                        approval: "approval";
                        "host-load": "host-load";
                        "host-apply": "host-apply";
                        "client-load": "client-load";
                        "client-apply": "client-apply";
                        "client-render": "client-render";
                        preflight: "preflight";
                        verification: "verification";
                        settlement: "settlement";
                        restore: "restore";
                    }>;
                    message: z.ZodString;
                    repairable: z.ZodBoolean;
                }, z.core.$strict>>;
                createdAt: z.ZodNumber;
                settledAt: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            updatedAt: z.ZodNumber;
        }, z.core.$strict>>>;
        scheduledTasks: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            source: z.ZodEnum<{
                chat: "chat";
                declared: "declared";
                runtime: "runtime";
            }>;
            extensionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">>;
            extensionName: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            note: z.ZodOptional<z.ZodString>;
            schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"once">;
                at: z.ZodNumber;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"cron">;
                cron: z.ZodString;
                timezone: z.ZodString;
            }, z.core.$strict>], "kind">;
            state: z.ZodEnum<{
                finished: "finished";
                scheduled: "scheduled";
                paused: "paused";
                inactive: "inactive";
            }>;
            nextRunAt: z.ZodOptional<z.ZodNumber>;
            lastFiredAt: z.ZodOptional<z.ZodNumber>;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getAuthoringTask: HostApiContract<"GET", z.ZodObject<{
        taskId: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        task: z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
            title: z.ZodString;
            requirementSummary: z.ZodString;
            status: z.ZodEnum<{
                "awaiting-approval": "awaiting-approval";
                running: "running";
                failed: "failed";
                stopped: "stopped";
                working: "working";
                ready: "ready";
                repairing: "repairing";
                interrupted: "interrupted";
                completed: "completed";
            }>;
            approvalPolicy: z.ZodEnum<{
                "risk-stable": "risk-stable";
                "fully-automatic": "fully-automatic";
            }>;
            approvedRiskDigest: z.ZodOptional<z.ZodString>;
            revision: z.ZodNumber;
            activeAttempt: z.ZodOptional<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
                ordinal: z.ZodNumber;
                name: z.ZodString;
                purpose: z.ZodString;
                state: z.ZodEnum<{
                    rejected: "rejected";
                    "awaiting-approval": "awaiting-approval";
                    "starting-host": "starting-host";
                    failed: "failed";
                    stopped: "stopped";
                    drafting: "drafting";
                    "preflight-failed": "preflight-failed";
                    "loading-client": "loading-client";
                    verifying: "verifying";
                    active: "active";
                }>;
                riskDigest: z.ZodString;
                host: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                client: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                error: z.ZodOptional<z.ZodObject<{
                    phase: z.ZodEnum<{
                        approval: "approval";
                        "host-load": "host-load";
                        "host-apply": "host-apply";
                        "client-load": "client-load";
                        "client-apply": "client-apply";
                        "client-render": "client-render";
                        preflight: "preflight";
                        verification: "verification";
                        settlement: "settlement";
                        restore: "restore";
                    }>;
                    message: z.ZodString;
                    repairable: z.ZodBoolean;
                }, z.core.$strict>>;
                createdAt: z.ZodNumber;
                settledAt: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            candidateAttempt: z.ZodOptional<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
                ordinal: z.ZodNumber;
                name: z.ZodString;
                purpose: z.ZodString;
                state: z.ZodEnum<{
                    rejected: "rejected";
                    "awaiting-approval": "awaiting-approval";
                    "starting-host": "starting-host";
                    failed: "failed";
                    stopped: "stopped";
                    drafting: "drafting";
                    "preflight-failed": "preflight-failed";
                    "loading-client": "loading-client";
                    verifying: "verifying";
                    active: "active";
                }>;
                riskDigest: z.ZodString;
                host: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                client: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                error: z.ZodOptional<z.ZodObject<{
                    phase: z.ZodEnum<{
                        approval: "approval";
                        "host-load": "host-load";
                        "host-apply": "host-apply";
                        "client-load": "client-load";
                        "client-apply": "client-apply";
                        "client-render": "client-render";
                        preflight: "preflight";
                        verification: "verification";
                        settlement: "settlement";
                        restore: "restore";
                    }>;
                    message: z.ZodString;
                    repairable: z.ZodBoolean;
                }, z.core.$strict>>;
                createdAt: z.ZodNumber;
                settledAt: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            verifiedAttempt: z.ZodOptional<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
                ordinal: z.ZodNumber;
                name: z.ZodString;
                purpose: z.ZodString;
                state: z.ZodEnum<{
                    rejected: "rejected";
                    "awaiting-approval": "awaiting-approval";
                    "starting-host": "starting-host";
                    failed: "failed";
                    stopped: "stopped";
                    drafting: "drafting";
                    "preflight-failed": "preflight-failed";
                    "loading-client": "loading-client";
                    verifying: "verifying";
                    active: "active";
                }>;
                riskDigest: z.ZodString;
                host: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                client: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                error: z.ZodOptional<z.ZodObject<{
                    phase: z.ZodEnum<{
                        approval: "approval";
                        "host-load": "host-load";
                        "host-apply": "host-apply";
                        "client-load": "client-load";
                        "client-apply": "client-apply";
                        "client-render": "client-render";
                        preflight: "preflight";
                        verification: "verification";
                        settlement: "settlement";
                        restore: "restore";
                    }>;
                    message: z.ZodString;
                    repairable: z.ZodBoolean;
                }, z.core.$strict>>;
                createdAt: z.ZodNumber;
                settledAt: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            updatedAt: z.ZodNumber;
        }, z.core.$strict>;
        attempts: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        testSecrets: z.ZodOptional<z.ZodObject<{
            fields: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>>;
            configured: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        events: z.ZodArray<z.ZodObject<{
            sequence: z.ZodNumber;
            kind: z.ZodString;
            attemptId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">>;
            payload: z.ZodJSONSchema;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly decideAuthoringAttempt: HostApiContract<"POST", z.ZodObject<{
        taskId: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
        attemptId: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodNumber;
        approved: z.ZodBoolean;
        approveRiskStable: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        accepted: z.ZodBoolean;
        taskRevision: z.ZodNumber;
        executionRequired: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly restoreAuthoringAttempt: HostApiContract<"POST", z.ZodObject<{
        taskId: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
        attemptId: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        title: z.ZodString;
        requirementSummary: z.ZodString;
        status: z.ZodEnum<{
            "awaiting-approval": "awaiting-approval";
            running: "running";
            failed: "failed";
            stopped: "stopped";
            working: "working";
            ready: "ready";
            repairing: "repairing";
            interrupted: "interrupted";
            completed: "completed";
        }>;
        approvalPolicy: z.ZodEnum<{
            "risk-stable": "risk-stable";
            "fully-automatic": "fully-automatic";
        }>;
        approvedRiskDigest: z.ZodOptional<z.ZodString>;
        revision: z.ZodNumber;
        activeAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        candidateAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        verifiedAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        createdAt: z.ZodNumber;
        updatedAt: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly stopAuthoringTask: HostApiContract<"POST", z.ZodObject<{
        taskId: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        title: z.ZodString;
        requirementSummary: z.ZodString;
        status: z.ZodEnum<{
            "awaiting-approval": "awaiting-approval";
            running: "running";
            failed: "failed";
            stopped: "stopped";
            working: "working";
            ready: "ready";
            repairing: "repairing";
            interrupted: "interrupted";
            completed: "completed";
        }>;
        approvalPolicy: z.ZodEnum<{
            "risk-stable": "risk-stable";
            "fully-automatic": "fully-automatic";
        }>;
        approvedRiskDigest: z.ZodOptional<z.ZodString>;
        revision: z.ZodNumber;
        activeAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        candidateAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        verifiedAttempt: z.ZodOptional<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
            ordinal: z.ZodNumber;
            name: z.ZodString;
            purpose: z.ZodString;
            state: z.ZodEnum<{
                rejected: "rejected";
                "awaiting-approval": "awaiting-approval";
                "starting-host": "starting-host";
                failed: "failed";
                stopped: "stopped";
                drafting: "drafting";
                "preflight-failed": "preflight-failed";
                "loading-client": "loading-client";
                verifying: "verifying";
                active: "active";
            }>;
            riskDigest: z.ZodString;
            host: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            client: z.ZodObject<{
                status: z.ZodEnum<{
                    pending: "pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    stopped: "stopped";
                    absent: "absent";
                }>;
                waitingFor: z.ZodArray<z.ZodString>;
                error: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            error: z.ZodOptional<z.ZodObject<{
                phase: z.ZodEnum<{
                    approval: "approval";
                    "host-load": "host-load";
                    "host-apply": "host-apply";
                    "client-load": "client-load";
                    "client-apply": "client-apply";
                    "client-render": "client-render";
                    preflight: "preflight";
                    verification: "verification";
                    settlement: "settlement";
                    restore: "restore";
                }>;
                message: z.ZodString;
                repairable: z.ZodBoolean;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            settledAt: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        createdAt: z.ZodNumber;
        updatedAt: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly setAuthoringTestSecrets: HostApiContract<"PUT", z.ZodObject<{
        taskId: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        secrets: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        configured: z.ZodArray<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly deleteAuthoringTask: HostApiContract<"DELETE", z.ZodObject<{
        taskId: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        deleted: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly pauseScheduledTask: HostApiContract<"POST", z.ZodObject<{
        taskId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        id: z.ZodString;
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        source: z.ZodEnum<{
            chat: "chat";
            declared: "declared";
            runtime: "runtime";
        }>;
        extensionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">>;
        extensionName: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        note: z.ZodOptional<z.ZodString>;
        schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"once">;
            at: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cron">;
            cron: z.ZodString;
            timezone: z.ZodString;
        }, z.core.$strict>], "kind">;
        state: z.ZodEnum<{
            finished: "finished";
            scheduled: "scheduled";
            paused: "paused";
            inactive: "inactive";
        }>;
        nextRunAt: z.ZodOptional<z.ZodNumber>;
        lastFiredAt: z.ZodOptional<z.ZodNumber>;
        createdAt: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly resumeScheduledTask: HostApiContract<"POST", z.ZodObject<{
        taskId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        id: z.ZodString;
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        source: z.ZodEnum<{
            chat: "chat";
            declared: "declared";
            runtime: "runtime";
        }>;
        extensionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">>;
        extensionName: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        note: z.ZodOptional<z.ZodString>;
        schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"once">;
            at: z.ZodNumber;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"cron">;
            cron: z.ZodString;
            timezone: z.ZodString;
        }, z.core.$strict>], "kind">;
        state: z.ZodEnum<{
            finished: "finished";
            scheduled: "scheduled";
            paused: "paused";
            inactive: "inactive";
        }>;
        nextRunAt: z.ZodOptional<z.ZodNumber>;
        lastFiredAt: z.ZodOptional<z.ZodNumber>;
        createdAt: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly runScheduledTask: HostApiContract<"POST", z.ZodObject<{
        taskId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        task: z.ZodObject<{
            id: z.ZodString;
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            source: z.ZodEnum<{
                chat: "chat";
                declared: "declared";
                runtime: "runtime";
            }>;
            extensionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">>;
            extensionName: z.ZodOptional<z.ZodString>;
            label: z.ZodString;
            note: z.ZodOptional<z.ZodString>;
            schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"once">;
                at: z.ZodNumber;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"cron">;
                cron: z.ZodString;
                timezone: z.ZodString;
            }, z.core.$strict>], "kind">;
            state: z.ZodEnum<{
                finished: "finished";
                scheduled: "scheduled";
                paused: "paused";
                inactive: "inactive";
            }>;
            nextRunAt: z.ZodOptional<z.ZodNumber>;
            lastFiredAt: z.ZodOptional<z.ZodNumber>;
            createdAt: z.ZodNumber;
        }, z.core.$strict>;
        woke: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly deleteScheduledTask: HostApiContract<"DELETE", z.ZodObject<{
        taskId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        deleted: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listClientNotifications: HostApiContract<"GET", z.ZodObject<{
        cursor: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        cursor: z.ZodNumber;
        notifications: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                "action-required": "action-required";
            }>;
            title: z.ZodString;
            body: z.ZodString;
            occurredAt: z.ZodNumber;
            route: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateNotificationSettings: HostApiContract<"PUT", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodOptional<z.ZodNumber>;
        system: z.ZodObject<{
            enabled: z.ZodBoolean;
        }, z.core.$strict>;
        bark: z.ZodObject<{
            enabled: z.ZodBoolean;
            serverUrl: z.ZodURL;
            deviceKey: z.ZodOptional<z.ZodString>;
            clearDeviceKey: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>;
        events: z.ZodRecord<z.ZodEnum<{
            "dynamic-client-approval-requested": "dynamic-client-approval-requested";
        }>, z.ZodBoolean>;
    }, z.core.$strict>, z.ZodObject<{
        revision: z.ZodOptional<z.ZodNumber>;
        system: z.ZodObject<{
            enabled: z.ZodBoolean;
        }, z.core.$strict>;
        bark: z.ZodObject<{
            enabled: z.ZodBoolean;
            serverUrl: z.ZodURL;
            deviceKeyConfigured: z.ZodBoolean;
        }, z.core.$strict>;
        events: z.ZodRecord<z.ZodEnum<{
            "dynamic-client-approval-requested": "dynamic-client-approval-requested";
        }>, z.ZodBoolean>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly testBarkNotification: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        serverUrl: z.ZodURL;
        deviceKey: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        sent: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly testSystemNotification: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        published: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listPlatformUsers: HostApiContract<"GET", z.ZodObject<{
        query: z.ZodOptional<z.ZodString>;
        adapterKey: z.ZodOptional<z.ZodString>;
        connectionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">>;
        cursor: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">>;
        limit: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        total: z.ZodNumber;
        items: z.ZodArray<z.ZodObject<{
            identityId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
            displayName: z.ZodOptional<z.ZodString>;
            adapter: z.ZodObject<{
                key: z.ZodString;
                displayName: z.ZodString;
            }, z.core.$strict>;
            connection: z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
                displayName: z.ZodString;
            }, z.core.$strict>;
            activeChannelCount: z.ZodNumber;
            channelPreview: z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
                kind: z.ZodEnum<{
                    internal: "internal";
                    direct: "direct";
                    group: "group";
                }>;
            }, z.core.$strict>>;
            historicalOnly: z.ZodBoolean;
        }, z.core.$strict>>;
        facets: z.ZodObject<{
            adapters: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                displayName: z.ZodString;
                userCount: z.ZodNumber;
            }, z.core.$strict>>;
            connections: z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
                adapterKey: z.ZodString;
                displayName: z.ZodString;
                userCount: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        nextCursor: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listConnectionEvents: HostApiContract<"GET", z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        beforeReceivedAt: z.ZodOptional<z.ZodNumber>;
        beforeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ConnectionEventId", "out">>;
        limit: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        events: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ConnectionEventId", "out">;
            connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
            activityKey: z.ZodString;
            summary: z.ZodString;
            actor: z.ZodOptional<z.ZodObject<{
                identityId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            subject: z.ZodOptional<z.ZodObject<{
                identityId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            occurredAt: z.ZodNumber;
        }, z.core.$strict>>;
        hasMore: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly createAgent: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        displayName: z.ZodString;
        persona: z.ZodDefault<z.ZodString>;
        personaDocument: z.ZodOptional<z.ZodObject<{
            version: z.ZodLiteral<1>;
            segments: z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                type: z.ZodLiteral<"text">;
                text: z.ZodString;
            }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"platform-user">;
                targetId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"channel">;
                targetId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"extension">;
                targetId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>], "kind">]>>;
        }, z.core.$strict>>;
        model: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            reasoningEffort: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        imagePolicy: z.ZodOptional<z.ZodObject<{
            history: z.ZodObject<{
                mode: z.ZodLiteral<"persistent-distinct">;
                detail: z.ZodEnum<{
                    high: "high";
                    low: "low";
                    auto: "auto";
                }>;
                restoreAfterCompaction: z.ZodObject<{
                    recentMessages: z.ZodNumber;
                    maxImages: z.ZodNumber;
                }, z.core.$strict>;
            }, z.core.$strict>;
            textModel: z.ZodDiscriminatedUnion<[z.ZodObject<{
                mode: z.ZodLiteral<"disabled">;
            }, z.core.$strict>, z.ZodObject<{
                mode: z.ZodLiteral<"auxiliary">;
                model: z.ZodObject<{
                    provider: z.ZodString;
                    model: z.ZodString;
                    reasoningEffort: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                maxTokens: z.ZodNumber;
            }, z.core.$strict>], "mode">;
        }, z.core.$strict>>;
        dynamicClientApprovalPolicy: z.ZodOptional<z.ZodEnum<{
            manual: "manual";
            automatic: "automatic";
        }>>;
        capabilities: z.ZodOptional<z.ZodObject<{
            subagents: z.ZodBoolean;
            fileTools: z.ZodBoolean;
            webSearch: z.ZodBoolean;
            dynamicCreation: z.ZodBoolean;
            developmentShell: z.ZodBoolean;
            unrestrictedFileAccess: z.ZodBoolean;
            scheduledTasks: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly reviseAgent: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        displayName: z.ZodString;
        persona: z.ZodDefault<z.ZodString>;
        personaDocument: z.ZodOptional<z.ZodObject<{
            version: z.ZodLiteral<1>;
            segments: z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                type: z.ZodLiteral<"text">;
                text: z.ZodString;
            }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"platform-user">;
                targetId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"channel">;
                targetId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reference">;
                kind: z.ZodLiteral<"extension">;
                targetId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
                labelSnapshot: z.ZodString;
            }, z.core.$strict>], "kind">]>>;
        }, z.core.$strict>>;
        model: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
            reasoningEffort: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>;
        imagePolicy: z.ZodOptional<z.ZodObject<{
            history: z.ZodObject<{
                mode: z.ZodLiteral<"persistent-distinct">;
                detail: z.ZodEnum<{
                    high: "high";
                    low: "low";
                    auto: "auto";
                }>;
                restoreAfterCompaction: z.ZodObject<{
                    recentMessages: z.ZodNumber;
                    maxImages: z.ZodNumber;
                }, z.core.$strict>;
            }, z.core.$strict>;
            textModel: z.ZodDiscriminatedUnion<[z.ZodObject<{
                mode: z.ZodLiteral<"disabled">;
            }, z.core.$strict>, z.ZodObject<{
                mode: z.ZodLiteral<"auxiliary">;
                model: z.ZodObject<{
                    provider: z.ZodString;
                    model: z.ZodString;
                    reasoningEffort: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                maxTokens: z.ZodNumber;
            }, z.core.$strict>], "mode">;
        }, z.core.$strict>>;
        dynamicClientApprovalPolicy: z.ZodOptional<z.ZodEnum<{
            manual: "manual";
            automatic: "automatic";
        }>>;
        expectedCurrentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        currentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateAgentCapabilities: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        subagents: z.ZodOptional<z.ZodBoolean>;
        fileTools: z.ZodOptional<z.ZodBoolean>;
        webSearch: z.ZodOptional<z.ZodBoolean>;
        dynamicCreation: z.ZodOptional<z.ZodBoolean>;
        developmentShell: z.ZodOptional<z.ZodBoolean>;
        unrestrictedFileAccess: z.ZodOptional<z.ZodBoolean>;
        scheduledTasks: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>, z.ZodObject<{
        currentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
        capabilities: z.ZodObject<{
            subagents: z.ZodBoolean;
            fileTools: z.ZodBoolean;
            webSearch: z.ZodBoolean;
            dynamicCreation: z.ZodBoolean;
            developmentShell: z.ZodBoolean;
            unrestrictedFileAccess: z.ZodBoolean;
            scheduledTasks: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly deleteAgent: HostApiContract<"DELETE", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        expectedCurrentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
        confirmationName: z.ZodString;
        deleteAutoCreatedBuiltInChannels: z.ZodDefault<z.ZodBoolean>;
        deleteWorkspace: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        deleted: z.ZodLiteral<true>;
        unboundChannelIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
        deletedChannelIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly createInternalChannel: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        displayName: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly deleteChannel: HostApiContract<"DELETE", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        expectedBoundAgentId: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        deleted: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly createBinding: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        triggerPolicy: z.ZodEnum<{
            always: "always";
            "mentioned-or-replied": "mentioned-or-replied";
            command: "command";
            "observe-only": "observe-only";
        }>;
        processingFeedback: z.ZodOptional<z.ZodEnum<{
            auto: "auto";
            off: "off";
        }>>;
        activityTriggerOverrides: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodBoolean>>;
    }, z.core.$strict>, z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        triggerPolicy: z.ZodEnum<{
            always: "always";
            "mentioned-or-replied": "mentioned-or-replied";
            command: "command";
            "observe-only": "observe-only";
        }>;
        processingFeedback: z.ZodDefault<z.ZodEnum<{
            auto: "auto";
            off: "off";
        }>>;
        activityTriggerOverrides: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodBoolean>>;
        boundAt: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly clearBinding: HostApiContract<"DELETE", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        cleared: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly putWorkTreeOrder: HostApiContract<"PUT", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        agentIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        channelIdsByAgent: z.ZodRecord<z.core.$ZodBranded<z.ZodString, "AgentId", "out">, z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>>;
        unboundChannelIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        agentIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        channelIdsByAgent: z.ZodRecord<z.core.$ZodBranded<z.ZodString, "AgentId", "out">, z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>>;
        unboundChannelIds: z.ZodArray<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listChannelMessages: HostApiContract<"GET", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        limit: z.ZodNumber;
        beforeOccurredAt: z.ZodOptional<z.ZodNumber>;
        beforeSourceId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        messages: z.ZodArray<z.ZodObject<{
            id: z.ZodUnion<readonly [z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">, z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">]>;
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            role: z.ZodEnum<{
                agent: "agent";
                system: "system";
                member: "member";
            }>;
            parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                type: z.ZodLiteral<"text">;
                text: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"mention">;
                memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"image">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                alt: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"file">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
                name: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"audio">;
                assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"quote">;
                messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"rich">;
                adapterKey: z.ZodString;
                kind: z.ZodString;
                summary: z.ZodString;
                title: z.ZodOptional<z.ZodString>;
                source: z.ZodOptional<z.ZodString>;
                targetUrl: z.ZodOptional<z.ZodURL>;
                previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
                extension: z.ZodOptional<z.ZodJSONSchema>;
            }, z.core.$strict>], "type">>;
            sender: z.ZodOptional<z.ZodObject<{
                memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
                displayName: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            mentionedConnectionAccount: z.ZodOptional<z.ZodBoolean>;
            activityKey: z.ZodOptional<z.ZodString>;
            targetLogicalMessageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">>;
            occurredAt: z.ZodNumber;
            deliveryState: z.ZodOptional<z.ZodEnum<{
                unknown: "unknown";
                failed: "failed";
                planned: "planned";
                sending: "sending";
                sent: "sent";
                "partially-sent": "partially-sent";
            }>>;
            deliveryResolution: z.ZodOptional<z.ZodObject<{
                action: z.ZodEnum<{
                    retry: "retry";
                    "confirm-delivered": "confirm-delivered";
                }>;
                resolvedAt: z.ZodNumber;
            }, z.core.$strict>>;
            origin: z.ZodOptional<z.ZodEnum<{
                "admin-console": "admin-console";
            }>>;
            inboundHook: z.ZodOptional<z.ZodObject<{
                trigger: z.ZodEnum<{
                    default: "default";
                    suppress: "suppress";
                    force: "force";
                }>;
                hidden: z.ZodBoolean;
                annotation: z.ZodOptional<z.ZodString>;
                extensions: z.ZodArray<z.ZodString>;
                problems: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            scheduledTask: z.ZodOptional<z.ZodObject<{
                label: z.ZodString;
                extensionName: z.ZodOptional<z.ZodString>;
                note: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        hasMore: z.ZodBoolean;
        cursor: z.ZodObject<{
            epoch: z.ZodString;
            sequence: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly sendChannelMessage: HostApiContract<"POST", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        parts: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            type: z.ZodLiteral<"text">;
            text: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"mention">;
            memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
        }, z.core.$strict>], "type">>;
        clientEventId: z.ZodOptional<z.ZodString>;
        senderMemberId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        inserted: z.ZodBoolean;
        channelEventId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">>;
        outboundIntentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly renameChannel: HostApiContract<"POST", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        displayName: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        displayName: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getChannelRuntime: HostApiContract<"GET", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        episodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
        phase: z.ZodEnum<{
            idle: "idle";
            thinking: "thinking";
            "using-tool": "using-tool";
            "waiting-input": "waiting-input";
            unavailable: "unavailable";
        }>;
        summary: z.ZodString;
        pendingInjectCount: z.ZodNumber;
        occupancy: z.ZodOptional<z.ZodObject<{
            projectedTokens: z.ZodNumber;
            contextWindow: z.ZodNumber;
            breakdown: z.ZodOptional<z.ZodObject<{
                systemTokens: z.ZodNumber;
                toolsTokens: z.ZodNumber;
                messageTokens: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        cache: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"episode">;
            aggregate: z.ZodObject<{
                usageRequestCount: z.ZodNumber;
                observedRequestCount: z.ZodNumber;
                shareRequestCount: z.ZodNumber;
                hitRequestCount: z.ZodNumber;
                uncachedInputTokens: z.ZodNumber;
                cacheReadTokens: z.ZodNumber;
                cacheWriteTokens: z.ZodNumber;
                averageRequestReadShare: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
            recent: z.ZodObject<{
                windowSize: z.ZodNumber;
                samples: z.ZodArray<z.ZodObject<{
                    turn: z.ZodNumber;
                    step: z.ZodNumber;
                    at: z.ZodOptional<z.ZodNumber>;
                    uncachedInputTokens: z.ZodNumber;
                    cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                    cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        performance: z.ZodOptional<z.ZodObject<{
            scope: z.ZodLiteral<"episode">;
            aggregate: z.ZodObject<{
                steps: z.ZodNumber;
                llmMs: z.ZodNumber;
                toolMs: z.ZodNumber;
                ttftMs: z.ZodNumber;
                ttftSteps: z.ZodNumber;
                decodeMs: z.ZodNumber;
                decodeTokens: z.ZodNumber;
                decodeSteps: z.ZodNumber;
                retryCount: z.ZodNumber;
                retryDelayMs: z.ZodNumber;
            }, z.core.$strict>;
            recent: z.ZodObject<{
                windowSize: z.ZodNumber;
                samples: z.ZodArray<z.ZodObject<{
                    turn: z.ZodNumber;
                    step: z.ZodNumber;
                    at: z.ZodOptional<z.ZodNumber>;
                    firstTokenMs: z.ZodOptional<z.ZodNumber>;
                    decodeMs: z.ZodOptional<z.ZodNumber>;
                    outputTokens: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        turns: z.ZodArray<z.ZodObject<{
            turn: z.ZodNumber;
            state: z.ZodEnum<{
                error: "error";
                interrupted: "interrupted";
                completed: "completed";
                "in-progress": "in-progress";
                unreplied: "unreplied";
                aborted: "aborted";
                "max-tokens": "max-tokens";
            }>;
            producedReply: z.ZodBoolean;
            responseState: z.ZodEnum<{
                pending: "pending";
                interrupted: "interrupted";
                sent: "sent";
                "not-required": "not-required";
                finished: "finished";
                "protocol-failed": "protocol-failed";
            }>;
            error: z.ZodOptional<z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict>>;
            steps: z.ZodArray<z.ZodObject<{
                step: z.ZodNumber;
                tools: z.ZodArray<z.ZodObject<{
                    callId: z.ZodString;
                    name: z.ZodString;
                    displayName: z.ZodString;
                    state: z.ZodEnum<{
                        running: "running";
                        failed: "failed";
                        succeeded: "succeeded";
                    }>;
                    inputPreview: z.ZodOptional<z.ZodString>;
                    resultPreview: z.ZodOptional<z.ZodString>;
                    wroteToChannel: z.ZodOptional<z.ZodBoolean>;
                    deliveryState: z.ZodOptional<z.ZodEnum<{
                        unknown: "unknown";
                        failed: "failed";
                        sent: "sent";
                        "partially-sent": "partially-sent";
                    }>>;
                    durationMs: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                internalOutput: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodLiteral<"internal-output">;
                    text: z.ZodOptional<z.ZodString>;
                    reasoning: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                durationMs: z.ZodOptional<z.ZodNumber>;
                firstTokenMs: z.ZodOptional<z.ZodNumber>;
                usage: z.ZodOptional<z.ZodObject<{
                    inputTokens: z.ZodNumber;
                    outputTokens: z.ZodNumber;
                    totalTokens: z.ZodOptional<z.ZodNumber>;
                    cacheReadTokens: z.ZodOptional<z.ZodNumber>;
                    cacheWriteTokens: z.ZodOptional<z.ZodNumber>;
                    reasoningTokens: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            durationMs: z.ZodOptional<z.ZodNumber>;
            startedAt: z.ZodOptional<z.ZodNumber>;
            endedAt: z.ZodOptional<z.ZodNumber>;
            triggerEventId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">>;
        }, z.core.$strict>>;
        cursor: z.ZodObject<{
            epoch: z.ZodString;
            sequence: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getChannelToolCall: HostApiContract<"GET", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        callId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        callId: z.ZodString;
        available: z.ZodBoolean;
        name: z.ZodOptional<z.ZodString>;
        input: z.ZodOptional<z.ZodString>;
        result: z.ZodOptional<z.ZodString>;
        inputTruncated: z.ZodBoolean;
        resultTruncated: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly resetChannelContext: HostApiContract<"POST", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodEnum<{
            compact: "compact";
            clear: "clear";
        }>;
        expectedEpisodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodEnum<{
            compact: "compact";
            clear: "clear";
        }>;
        closedEpisodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        nextEpisodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly createConnection: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        adapterKey: z.ZodString;
        alias: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string | undefined, string>>>;
        configuration: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodJSONSchema>>;
        credentials: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        adapterKey: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly startConnectionLogin: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        adapterKey: z.ZodString;
        alias: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string | undefined, string>>>;
        connectionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        loginId: z.ZodString;
        adapterKey: z.ZodString;
        status: z.ZodEnum<{
            pending: "pending";
            failed: "failed";
            cancelled: "cancelled";
            expired: "expired";
            scanned: "scanned";
            confirmed: "confirmed";
        }>;
        qrCodeUrl: z.ZodString;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getConnectionLogin: HostApiContract<"GET", z.ZodObject<{
        loginId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        loginId: z.ZodString;
        status: z.ZodEnum<{
            pending: "pending";
            failed: "failed";
            cancelled: "cancelled";
            expired: "expired";
            scanned: "scanned";
            confirmed: "confirmed";
        }>;
        qrCodeUrl: z.ZodOptional<z.ZodString>;
        connectionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">>;
        adapterKey: z.ZodString;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly cancelConnectionLogin: HostApiContract<"DELETE", z.ZodObject<{
        loginId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        loginId: z.ZodString;
        status: z.ZodLiteral<"cancelled">;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateConnectionAlias: HostApiContract<"POST", z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        alias: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        alias: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateConnectionActivityTriggerDefaults: HostApiContract<"POST", z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        activityKeys: z.ZodArray<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        activityKeys: z.ZodArray<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateConnectionConfiguration: HostApiContract<"POST", z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        configuration: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>;
    }, z.core.$strict>, z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        configuration: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean]>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly deleteConnection: HostApiContract<"DELETE", z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        deleteChannelData: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        archived: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly restoreConnection: HostApiContract<"POST", z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
        restored: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dshPlugins: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        plugins: z.ZodArray<z.ZodObject<{
            packageName: z.ZodString;
            packageVersion: z.ZodString;
            origin: z.ZodEnum<{
                dynamic: "dynamic";
                builtin: "builtin";
                profile: "profile";
                installed: "installed";
            }>;
            settingsNamespaces: z.ZodArray<z.ZodString>;
            loadError: z.ZodOptional<z.ZodObject<{
                code: z.ZodString;
                message: z.ZodString;
            }, z.core.$strict>>;
            packageId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "DshPluginPackageId", "out">>;
            installSource: z.ZodOptional<z.ZodEnum<{
                registry: "registry";
                tarball: "tarball";
                imported: "imported";
            }>>;
            installedAt: z.ZodOptional<z.ZodNumber>;
            clientUiDetected: z.ZodOptional<z.ZodBoolean>;
            hostUi: z.ZodOptional<z.ZodObject<{
                schemaVersion: z.ZodLiteral<1>;
                entryKey: z.ZodString;
                client: z.ZodString;
                css: z.ZodOptional<z.ZodString>;
                pages: z.ZodArray<z.ZodObject<{
                    kind: z.ZodLiteral<"host-page">;
                    entryId: z.ZodString;
                    title: z.ZodString;
                    description: z.ZodOptional<z.ZodString>;
                    icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        kind: z.ZodLiteral<"host-icon">;
                        name: z.ZodEnum<{
                            "app-window": "app-window";
                            "bar-chart": "bar-chart";
                            "book-open": "book-open";
                            boxes: "boxes";
                            database: "database";
                            "file-text": "file-text";
                            folder: "folder";
                            globe: "globe";
                            "layout-dashboard": "layout-dashboard";
                            puzzle: "puzzle";
                            terminal: "terminal";
                            workflow: "workflow";
                            wrench: "wrench";
                        }>;
                    }, z.core.$strict>, z.ZodObject<{
                        kind: z.ZodLiteral<"svg">;
                        path: z.ZodString;
                        sha256: z.ZodString;
                    }, z.core.$strict>], "kind">;
                    objectPane: z.ZodEnum<{
                        hidden: "hidden";
                        navigation: "navigation";
                    }>;
                    startPath: z.ZodString;
                }, z.core.$strict>>;
                permissions: z.ZodDefault<z.ZodObject<{
                    permissions: z.ZodArray<z.ZodEnum<{
                        "agents.read": "agents.read";
                        "channels.read": "channels.read";
                        "connections.read": "connections.read";
                        "extensions.read": "extensions.read";
                        "dsh-plugins.read": "dsh-plugins.read";
                        "runtime.read": "runtime.read";
                        "messages.read": "messages.read";
                        "assets.read": "assets.read";
                        "agents.manage": "agents.manage";
                        "channels.manage": "channels.manage";
                        "connections.manage": "connections.manage";
                        "credentials.write": "credentials.write";
                        "messages.send": "messages.send";
                        "notifications.publish": "notifications.publish";
                        "network.request": "network.request";
                    }>>;
                    networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
                    capabilities: z.ZodOptional<z.ZodObject<{
                        network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                            mode: z.ZodLiteral<"domains">;
                            domains: z.ZodArray<z.ZodString>;
                        }, z.core.$strict>, z.ZodObject<{
                            mode: z.ZodLiteral<"config">;
                            fields: z.ZodArray<z.ZodString>;
                        }, z.core.$strict>, z.ZodObject<{
                            mode: z.ZodLiteral<"unrestricted">;
                            purpose: z.ZodString;
                        }, z.core.$strict>], "mode">>;
                        storage: z.ZodOptional<z.ZodObject<{
                            scopes: z.ZodArray<z.ZodEnum<{
                                agent: "agent";
                                channel: "channel";
                                member: "member";
                                shared: "shared";
                            }>>;
                            quotaBytes: z.ZodOptional<z.ZodNumber>;
                        }, z.core.$strict>>;
                        assets: z.ZodOptional<z.ZodObject<{
                            write: z.ZodLiteral<true>;
                        }, z.core.$strict>>;
                        history: z.ZodOptional<z.ZodObject<{
                            read: z.ZodLiteral<true>;
                        }, z.core.$strict>>;
                        inboundHook: z.ZodOptional<z.ZodObject<{
                            reads: z.ZodEnum<{
                                triggered: "triggered";
                                all: "all";
                            }>;
                            mayHide: z.ZodBoolean;
                            mayForceTrigger: z.ZodBoolean;
                            timeoutMs: z.ZodNumber;
                        }, z.core.$strict>>;
                        jobs: z.ZodOptional<z.ZodObject<{
                            declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                                id: z.ZodString;
                                label: z.ZodString;
                                cron: z.ZodString;
                                timezone: z.ZodOptional<z.ZodString>;
                            }, z.core.$strict>>>;
                            runtime: z.ZodOptional<z.ZodObject<{
                                maxActive: z.ZodNumber;
                            }, z.core.$strict>>;
                        }, z.core.$strict>>;
                        platform: z.ZodOptional<z.ZodObject<{
                            actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                                adapter: z.ZodString;
                                action: z.ZodString;
                            }, z.core.$strict>>>;
                            raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>>;
                        llm: z.ZodOptional<z.ZodObject<{
                            maxCallsPerTurn: z.ZodNumber;
                            maxOutputTokens: z.ZodNumber;
                        }, z.core.$strict>>;
                        mcp: z.ZodOptional<z.ZodObject<{
                            servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                                transport: z.ZodLiteral<"streamable-http">;
                                name: z.ZodString;
                                url: z.ZodString;
                                headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                    secret: z.ZodString;
                                }, z.core.$strict>]>>>;
                            }, z.core.$strict>, z.ZodObject<{
                                transport: z.ZodLiteral<"stdio">;
                                name: z.ZodString;
                                command: z.ZodString;
                                args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                                env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                    secret: z.ZodString;
                                }, z.core.$strict>]>>>;
                            }, z.core.$strict>], "transport">>;
                        }, z.core.$strict>>;
                        context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            name: z.ZodString;
                            kind: z.ZodEnum<{
                                static: "static";
                                dynamic: "dynamic";
                            }>;
                            maxChars: z.ZodNumber;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            approvedBuilds: z.ZodOptional<z.ZodArray<z.ZodString>>;
            entries: z.ZodOptional<z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "DshPluginEntryId", "out">;
                entryKey: z.ZodString;
                moduleName: z.ZodString;
                suggestedScope: z.ZodEnum<{
                    agent: "agent";
                    host: "host";
                }>;
                selectedScope: z.ZodOptional<z.ZodEnum<{
                    agent: "agent";
                    host: "host";
                }>>;
                config: z.ZodJSONSchema;
                activations: z.ZodArray<z.ZodObject<{
                    targetKey: z.ZodString;
                    target: z.ZodEnum<{
                        agent: "agent";
                        host: "host";
                    }>;
                    agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
                    activatedAt: z.ZodNumber;
                    diagnostic: z.ZodOptional<z.ZodObject<{
                        status: z.ZodEnum<{
                            active: "active";
                            "restore-failed": "restore-failed";
                            "dispose-failed": "dispose-failed";
                            "load-failed": "load-failed";
                        }>;
                        phase: z.ZodEnum<{
                            update: "update";
                            restore: "restore";
                            dispose: "dispose";
                            import: "import";
                            apply: "apply";
                        }>;
                        message: z.ZodOptional<z.ZodString>;
                        observedAt: z.ZodNumber;
                    }, z.core.$strip>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly inspectDshPluginTarball: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        bytes: z.ZodCustom<Uint8Array<ArrayBuffer>, Uint8Array<ArrayBuffer>>;
        fileName: z.ZodOptional<z.ZodString>;
        operationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        token: z.ZodString;
        operationId: z.ZodOptional<z.ZodString>;
        packageName: z.ZodString;
        packageVersion: z.ZodString;
        packageDigest: z.ZodString;
        lockfileDigest: z.ZodString;
        blockedBuilds: z.ZodArray<z.ZodString>;
        clientUiDetected: z.ZodBoolean;
        hostUi: z.ZodOptional<z.ZodObject<{
            schemaVersion: z.ZodLiteral<1>;
            entryKey: z.ZodString;
            client: z.ZodString;
            css: z.ZodOptional<z.ZodString>;
            pages: z.ZodArray<z.ZodObject<{
                kind: z.ZodLiteral<"host-page">;
                entryId: z.ZodString;
                title: z.ZodString;
                description: z.ZodOptional<z.ZodString>;
                icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"host-icon">;
                    name: z.ZodEnum<{
                        "app-window": "app-window";
                        "bar-chart": "bar-chart";
                        "book-open": "book-open";
                        boxes: "boxes";
                        database: "database";
                        "file-text": "file-text";
                        folder: "folder";
                        globe: "globe";
                        "layout-dashboard": "layout-dashboard";
                        puzzle: "puzzle";
                        terminal: "terminal";
                        workflow: "workflow";
                        wrench: "wrench";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"svg">;
                    path: z.ZodString;
                    sha256: z.ZodString;
                }, z.core.$strict>], "kind">;
                objectPane: z.ZodEnum<{
                    hidden: "hidden";
                    navigation: "navigation";
                }>;
                startPath: z.ZodString;
            }, z.core.$strict>>;
            permissions: z.ZodDefault<z.ZodObject<{
                permissions: z.ZodArray<z.ZodEnum<{
                    "agents.read": "agents.read";
                    "channels.read": "channels.read";
                    "connections.read": "connections.read";
                    "extensions.read": "extensions.read";
                    "dsh-plugins.read": "dsh-plugins.read";
                    "runtime.read": "runtime.read";
                    "messages.read": "messages.read";
                    "assets.read": "assets.read";
                    "agents.manage": "agents.manage";
                    "channels.manage": "channels.manage";
                    "connections.manage": "connections.manage";
                    "credentials.write": "credentials.write";
                    "messages.send": "messages.send";
                    "notifications.publish": "notifications.publish";
                    "network.request": "network.request";
                }>>;
                networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
                capabilities: z.ZodOptional<z.ZodObject<{
                    network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        mode: z.ZodLiteral<"domains">;
                        domains: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>, z.ZodObject<{
                        mode: z.ZodLiteral<"config">;
                        fields: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>, z.ZodObject<{
                        mode: z.ZodLiteral<"unrestricted">;
                        purpose: z.ZodString;
                    }, z.core.$strict>], "mode">>;
                    storage: z.ZodOptional<z.ZodObject<{
                        scopes: z.ZodArray<z.ZodEnum<{
                            agent: "agent";
                            channel: "channel";
                            member: "member";
                            shared: "shared";
                        }>>;
                        quotaBytes: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strict>>;
                    assets: z.ZodOptional<z.ZodObject<{
                        write: z.ZodLiteral<true>;
                    }, z.core.$strict>>;
                    history: z.ZodOptional<z.ZodObject<{
                        read: z.ZodLiteral<true>;
                    }, z.core.$strict>>;
                    inboundHook: z.ZodOptional<z.ZodObject<{
                        reads: z.ZodEnum<{
                            triggered: "triggered";
                            all: "all";
                        }>;
                        mayHide: z.ZodBoolean;
                        mayForceTrigger: z.ZodBoolean;
                        timeoutMs: z.ZodNumber;
                    }, z.core.$strict>>;
                    jobs: z.ZodOptional<z.ZodObject<{
                        declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            label: z.ZodString;
                            cron: z.ZodString;
                            timezone: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>>;
                        runtime: z.ZodOptional<z.ZodObject<{
                            maxActive: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    platform: z.ZodOptional<z.ZodObject<{
                        actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                            adapter: z.ZodString;
                            action: z.ZodString;
                        }, z.core.$strict>>>;
                        raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    llm: z.ZodOptional<z.ZodObject<{
                        maxCallsPerTurn: z.ZodNumber;
                        maxOutputTokens: z.ZodNumber;
                    }, z.core.$strict>>;
                    mcp: z.ZodOptional<z.ZodObject<{
                        servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                            transport: z.ZodLiteral<"streamable-http">;
                            name: z.ZodString;
                            url: z.ZodString;
                            headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                secret: z.ZodString;
                            }, z.core.$strict>]>>>;
                        }, z.core.$strict>, z.ZodObject<{
                            transport: z.ZodLiteral<"stdio">;
                            name: z.ZodString;
                            command: z.ZodString;
                            args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                            env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                secret: z.ZodString;
                            }, z.core.$strict>]>>>;
                        }, z.core.$strict>], "transport">>;
                    }, z.core.$strict>>;
                    context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        kind: z.ZodEnum<{
                            static: "static";
                            dynamic: "dynamic";
                        }>;
                        maxChars: z.ZodNumber;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        entries: z.ZodArray<z.ZodObject<{
            entryKey: z.ZodString;
            moduleName: z.ZodString;
            suggestedScope: z.ZodEnum<{
                agent: "agent";
                host: "host";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly exportExtensionRevision: HostApiContract<"GET", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodCustom<Uint8Array<ArrayBuffer>, Uint8Array<ArrayBuffer>>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly inspectDshPluginInstall: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        spec: z.ZodString;
        operationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        token: z.ZodString;
        operationId: z.ZodOptional<z.ZodString>;
        packageName: z.ZodString;
        packageVersion: z.ZodString;
        packageDigest: z.ZodString;
        lockfileDigest: z.ZodString;
        blockedBuilds: z.ZodArray<z.ZodString>;
        clientUiDetected: z.ZodBoolean;
        hostUi: z.ZodOptional<z.ZodObject<{
            schemaVersion: z.ZodLiteral<1>;
            entryKey: z.ZodString;
            client: z.ZodString;
            css: z.ZodOptional<z.ZodString>;
            pages: z.ZodArray<z.ZodObject<{
                kind: z.ZodLiteral<"host-page">;
                entryId: z.ZodString;
                title: z.ZodString;
                description: z.ZodOptional<z.ZodString>;
                icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"host-icon">;
                    name: z.ZodEnum<{
                        "app-window": "app-window";
                        "bar-chart": "bar-chart";
                        "book-open": "book-open";
                        boxes: "boxes";
                        database: "database";
                        "file-text": "file-text";
                        folder: "folder";
                        globe: "globe";
                        "layout-dashboard": "layout-dashboard";
                        puzzle: "puzzle";
                        terminal: "terminal";
                        workflow: "workflow";
                        wrench: "wrench";
                    }>;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"svg">;
                    path: z.ZodString;
                    sha256: z.ZodString;
                }, z.core.$strict>], "kind">;
                objectPane: z.ZodEnum<{
                    hidden: "hidden";
                    navigation: "navigation";
                }>;
                startPath: z.ZodString;
            }, z.core.$strict>>;
            permissions: z.ZodDefault<z.ZodObject<{
                permissions: z.ZodArray<z.ZodEnum<{
                    "agents.read": "agents.read";
                    "channels.read": "channels.read";
                    "connections.read": "connections.read";
                    "extensions.read": "extensions.read";
                    "dsh-plugins.read": "dsh-plugins.read";
                    "runtime.read": "runtime.read";
                    "messages.read": "messages.read";
                    "assets.read": "assets.read";
                    "agents.manage": "agents.manage";
                    "channels.manage": "channels.manage";
                    "connections.manage": "connections.manage";
                    "credentials.write": "credentials.write";
                    "messages.send": "messages.send";
                    "notifications.publish": "notifications.publish";
                    "network.request": "network.request";
                }>>;
                networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
                capabilities: z.ZodOptional<z.ZodObject<{
                    network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        mode: z.ZodLiteral<"domains">;
                        domains: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>, z.ZodObject<{
                        mode: z.ZodLiteral<"config">;
                        fields: z.ZodArray<z.ZodString>;
                    }, z.core.$strict>, z.ZodObject<{
                        mode: z.ZodLiteral<"unrestricted">;
                        purpose: z.ZodString;
                    }, z.core.$strict>], "mode">>;
                    storage: z.ZodOptional<z.ZodObject<{
                        scopes: z.ZodArray<z.ZodEnum<{
                            agent: "agent";
                            channel: "channel";
                            member: "member";
                            shared: "shared";
                        }>>;
                        quotaBytes: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strict>>;
                    assets: z.ZodOptional<z.ZodObject<{
                        write: z.ZodLiteral<true>;
                    }, z.core.$strict>>;
                    history: z.ZodOptional<z.ZodObject<{
                        read: z.ZodLiteral<true>;
                    }, z.core.$strict>>;
                    inboundHook: z.ZodOptional<z.ZodObject<{
                        reads: z.ZodEnum<{
                            triggered: "triggered";
                            all: "all";
                        }>;
                        mayHide: z.ZodBoolean;
                        mayForceTrigger: z.ZodBoolean;
                        timeoutMs: z.ZodNumber;
                    }, z.core.$strict>>;
                    jobs: z.ZodOptional<z.ZodObject<{
                        declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            id: z.ZodString;
                            label: z.ZodString;
                            cron: z.ZodString;
                            timezone: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>>;
                        runtime: z.ZodOptional<z.ZodObject<{
                            maxActive: z.ZodNumber;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    platform: z.ZodOptional<z.ZodObject<{
                        actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                            adapter: z.ZodString;
                            action: z.ZodString;
                        }, z.core.$strict>>>;
                        raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    llm: z.ZodOptional<z.ZodObject<{
                        maxCallsPerTurn: z.ZodNumber;
                        maxOutputTokens: z.ZodNumber;
                    }, z.core.$strict>>;
                    mcp: z.ZodOptional<z.ZodObject<{
                        servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                            transport: z.ZodLiteral<"streamable-http">;
                            name: z.ZodString;
                            url: z.ZodString;
                            headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                secret: z.ZodString;
                            }, z.core.$strict>]>>>;
                        }, z.core.$strict>, z.ZodObject<{
                            transport: z.ZodLiteral<"stdio">;
                            name: z.ZodString;
                            command: z.ZodString;
                            args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                            env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                                secret: z.ZodString;
                            }, z.core.$strict>]>>>;
                        }, z.core.$strict>], "transport">>;
                    }, z.core.$strict>>;
                    context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        kind: z.ZodEnum<{
                            static: "static";
                            dynamic: "dynamic";
                        }>;
                        maxChars: z.ZodNumber;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        entries: z.ZodArray<z.ZodObject<{
            entryKey: z.ZodString;
            moduleName: z.ZodString;
            suggestedScope: z.ZodEnum<{
                agent: "agent";
                host: "host";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly commitDshPluginInstall: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        token: z.ZodString;
        approvedBuilds: z.ZodDefault<z.ZodArray<z.ZodString>>;
        operationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        packageId: z.core.$ZodBranded<z.ZodString, "DshPluginPackageId", "out">;
        operationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly inspectDshPluginEntryConfig: HostApiContract<"POST", z.ZodObject<{
        entryId: z.core.$ZodBranded<z.ZodString, "DshPluginEntryId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"schema">;
        schema: z.ZodJSONSchema;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"json">;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"incompatible">;
        reason: z.ZodString;
    }, z.core.$strict>], "mode">, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly activateDshPluginEntry: HostApiContract<"PUT", z.ZodObject<{
        entryId: z.core.$ZodBranded<z.ZodString, "DshPluginEntryId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        target: z.ZodEnum<{
            agent: "agent";
            host: "host";
        }>;
        agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
        config: z.ZodJSONSchema;
        permissionApproval: z.ZodOptional<z.ZodObject<{
            permissionDigest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        targetKey: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly deactivateDshPluginEntry: HostApiContract<"DELETE", z.ZodObject<{
        entryId: z.core.$ZodBranded<z.ZodString, "DshPluginEntryId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        targetKey: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        disabled: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly removeDshPluginPackage: HostApiContract<"DELETE", z.ZodObject<{
        packageId: z.core.$ZodBranded<z.ZodString, "DshPluginPackageId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        removed: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly inspectExtensionImport: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        bytes: z.ZodCustom<Uint8Array<ArrayBuffer>, Uint8Array<ArrayBuffer>>;
        fileName: z.ZodOptional<z.ZodString>;
        operationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        token: z.ZodString;
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
        slug: z.ZodString;
        displayName: z.ZodString;
        scope: z.ZodEnum<{
            agent: "agent";
            "host-adapter": "host-adapter";
            "host-ui": "host-ui";
        }>;
        idempotent: z.ZodBoolean;
        slugConflict: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    /**
     * Management-edge endpoints: they exist only when the Server is reached through its management edge (a management
     * key is set); clients tell that from the edge's CSRF cookie.
     */
    readonly listManagementDevices: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        devices: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ManagementDeviceId", "out">;
            label: z.ZodString;
            createdAt: z.ZodNumber;
            lastUsedAt: z.ZodOptional<z.ZodNumber>;
            revokedAt: z.ZodOptional<z.ZodNumber>;
            current: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly revokeManagementDevice: HostApiContract<"DELETE", z.ZodObject<{
        deviceId: z.core.$ZodBranded<z.ZodString, "ManagementDeviceId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        revoked: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly managementLogout: HostApiContract<"DELETE", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        authenticated: z.ZodLiteral<false>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getCommunityStatus: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        communityUrl: z.ZodString;
        environment: z.ZodNullable<z.ZodEnum<{
            production: "production";
            staging: "staging";
            development: "development";
        }>>;
        account: z.ZodNullable<z.ZodObject<{
            handle: z.ZodString;
            displayName: z.ZodString;
            avatarUrl: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        signedInAt: z.ZodNullable<z.ZodNumber>;
        updatesAvailable: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly startCommunityLogin: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        returnOrigin: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        authorizeUrl: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly communityLogout: HostApiContract<"DELETE", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        communityUrl: z.ZodString;
        environment: z.ZodNullable<z.ZodEnum<{
            production: "production";
            staging: "staging";
            development: "development";
        }>>;
        account: z.ZodNullable<z.ZodObject<{
            handle: z.ZodString;
            displayName: z.ZodString;
            avatarUrl: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        signedInAt: z.ZodNullable<z.ZodNumber>;
        updatesAvailable: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listCommunityExtensions: HostApiContract<"GET", z.ZodObject<{
        query: z.ZodOptional<z.ZodString>;
        scope: z.ZodOptional<z.ZodEnum<{
            agent: "agent";
            "host-adapter": "host-adapter";
            "host-ui": "host-ui";
        }>>;
        cursor: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        items: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
            scope: z.ZodEnum<{
                agent: "agent";
                "host-adapter": "host-adapter";
                "host-ui": "host-ui";
            }>;
            displayName: z.ZodString;
            summary: z.ZodString;
            tags: z.ZodArray<z.ZodString>;
            official: z.ZodBoolean;
            publisher: z.ZodObject<{
                handle: z.ZodString;
                displayName: z.ZodString;
                avatarUrl: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            latest: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                reviewStatus: z.ZodEnum<{
                    pending: "pending";
                    reviewing: "reviewing";
                    passed: "passed";
                    passed_with_notes: "passed_with_notes";
                    flagged: "flagged";
                    held: "held";
                    risk_confirmed: "risk_confirmed";
                    rejected: "rejected";
                    incomplete: "incomplete";
                }>;
                grade: z.ZodNullable<z.ZodEnum<{
                    A: "A";
                    B: "B";
                    C: "C";
                    D: "D";
                }>>;
                permissions: z.ZodArray<z.ZodObject<{
                    key: z.ZodString;
                    level: z.ZodEnum<{
                        normal: "normal";
                        elevated: "elevated";
                        high: "high";
                    }>;
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                packageSize: z.ZodNumber;
                requiresSdk: z.ZodNullable<z.ZodNumber>;
                notes: z.ZodString;
                createdAt: z.ZodNumber;
            }, z.core.$strict>>;
            downloads: z.ZodNumber;
            updatedAt: z.ZodNumber;
            pageUrl: z.ZodString;
        }, z.core.$strict>>;
        nextCursor: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getCommunityExtension: HostApiContract<"GET", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        scope: z.ZodEnum<{
            agent: "agent";
            "host-adapter": "host-adapter";
            "host-ui": "host-ui";
        }>;
        displayName: z.ZodString;
        summary: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
        official: z.ZodBoolean;
        publisher: z.ZodObject<{
            handle: z.ZodString;
            displayName: z.ZodString;
            avatarUrl: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        latest: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            reviewStatus: z.ZodEnum<{
                pending: "pending";
                reviewing: "reviewing";
                passed: "passed";
                passed_with_notes: "passed_with_notes";
                flagged: "flagged";
                held: "held";
                risk_confirmed: "risk_confirmed";
                rejected: "rejected";
                incomplete: "incomplete";
            }>;
            grade: z.ZodNullable<z.ZodEnum<{
                A: "A";
                B: "B";
                C: "C";
                D: "D";
            }>>;
            permissions: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                level: z.ZodEnum<{
                    normal: "normal";
                    elevated: "elevated";
                    high: "high";
                }>;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            packageSize: z.ZodNumber;
            requiresSdk: z.ZodNullable<z.ZodNumber>;
            notes: z.ZodString;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
        downloads: z.ZodNumber;
        updatedAt: z.ZodNumber;
        pageUrl: z.ZodString;
        description: z.ZodString;
        sourceUrl: z.ZodNullable<z.ZodString>;
        review: z.ZodNullable<z.ZodObject<{
            status: z.ZodEnum<{
                pending: "pending";
                reviewing: "reviewing";
                passed: "passed";
                passed_with_notes: "passed_with_notes";
                flagged: "flagged";
                held: "held";
                risk_confirmed: "risk_confirmed";
                rejected: "rejected";
                incomplete: "incomplete";
            }>;
            grade: z.ZodNullable<z.ZodEnum<{
                A: "A";
                B: "B";
                C: "C";
                D: "D";
            }>>;
            summary: z.ZodNullable<z.ZodString>;
            highlights: z.ZodArray<z.ZodObject<{
                severity: z.ZodString;
                title: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    /** 下载社区发布并按包摘要校验，结果与本地文件导入的检查相同，再经 `commitExtensionImport` 确认。 */
    readonly getCommunityEndpoint: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        url: z.ZodString;
        source: z.ZodEnum<{
            environment: "environment";
            default: "default";
            setting: "setting";
        }>;
        defaultUrl: z.ZodString;
        environmentUrl: z.ZodNullable<z.ZodString>;
        insecure: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    /** 修改社区地址；`url: null` 恢复为环境变量或默认地址。非加密的局域网地址需要确认风险。 */
    readonly updateCommunityEndpoint: HostApiContract<"PUT", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        url: z.ZodNullable<z.ZodString>;
        acknowledgeInsecure: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        url: z.ZodString;
        source: z.ZodEnum<{
            environment: "environment";
            default: "default";
            setting: "setting";
        }>;
        defaultUrl: z.ZodString;
        environmentUrl: z.ZodNullable<z.ZodString>;
        insecure: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly testCommunityEndpoint: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        url: z.ZodString;
        acknowledgeInsecure: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        ok: z.ZodBoolean;
        message: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        environment: z.ZodOptional<z.ZodEnum<{
            production: "production";
            staging: "staging";
            development: "development";
        }>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listCommunityInstalled: HostApiContract<"GET", z.ZodObject<{
        refresh: z.ZodOptional<z.ZodEnum<{
            1: "1";
        }>>;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        checkedAt: z.ZodNullable<z.ZodNumber>;
        items: z.ZodArray<z.ZodObject<{
            extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
            displayName: z.ZodString;
            revisionId: z.ZodString;
            source: z.ZodObject<{
                kind: z.ZodLiteral<"community">;
                communityUrl: z.ZodString;
                releaseId: z.ZodString;
                publisherHandle: z.ZodString;
                installedAt: z.ZodNumber;
            }, z.core.$strict>;
            sameCommunity: z.ZodBoolean;
            found: z.ZodBoolean;
            delisted: z.ZodBoolean;
            delistedReason: z.ZodNullable<z.ZodString>;
            releaseWithdrawn: z.ZodBoolean;
            latest: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                reviewStatus: z.ZodEnum<{
                    pending: "pending";
                    reviewing: "reviewing";
                    passed: "passed";
                    passed_with_notes: "passed_with_notes";
                    flagged: "flagged";
                    held: "held";
                    risk_confirmed: "risk_confirmed";
                    rejected: "rejected";
                    incomplete: "incomplete";
                }>;
                grade: z.ZodNullable<z.ZodEnum<{
                    A: "A";
                    B: "B";
                    C: "C";
                    D: "D";
                }>>;
                permissions: z.ZodArray<z.ZodObject<{
                    key: z.ZodString;
                    level: z.ZodEnum<{
                        normal: "normal";
                        elevated: "elevated";
                        high: "high";
                    }>;
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                packageSize: z.ZodNumber;
                requiresSdk: z.ZodNullable<z.ZodNumber>;
                notes: z.ZodString;
                createdAt: z.ZodNumber;
            }, z.core.$strict>>;
            updateAvailable: z.ZodBoolean;
            addedPermissions: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                level: z.ZodEnum<{
                    normal: "normal";
                    elevated: "elevated";
                    high: "high";
                }>;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listCommunityMine: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        items: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
            scope: z.ZodEnum<{
                agent: "agent";
                "host-adapter": "host-adapter";
                "host-ui": "host-ui";
            }>;
            displayName: z.ZodString;
            summary: z.ZodString;
            tags: z.ZodArray<z.ZodString>;
            official: z.ZodBoolean;
            publisher: z.ZodObject<{
                handle: z.ZodString;
                displayName: z.ZodString;
                avatarUrl: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            latest: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                reviewStatus: z.ZodEnum<{
                    pending: "pending";
                    reviewing: "reviewing";
                    passed: "passed";
                    passed_with_notes: "passed_with_notes";
                    flagged: "flagged";
                    held: "held";
                    risk_confirmed: "risk_confirmed";
                    rejected: "rejected";
                    incomplete: "incomplete";
                }>;
                grade: z.ZodNullable<z.ZodEnum<{
                    A: "A";
                    B: "B";
                    C: "C";
                    D: "D";
                }>>;
                permissions: z.ZodArray<z.ZodObject<{
                    key: z.ZodString;
                    level: z.ZodEnum<{
                        normal: "normal";
                        elevated: "elevated";
                        high: "high";
                    }>;
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                packageSize: z.ZodNumber;
                requiresSdk: z.ZodNullable<z.ZodNumber>;
                notes: z.ZodString;
                createdAt: z.ZodNumber;
            }, z.core.$strict>>;
            downloads: z.ZodNumber;
            updatedAt: z.ZodNumber;
            pageUrl: z.ZodString;
            releases: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                reviewStatus: z.ZodEnum<{
                    pending: "pending";
                    reviewing: "reviewing";
                    passed: "passed";
                    passed_with_notes: "passed_with_notes";
                    flagged: "flagged";
                    held: "held";
                    risk_confirmed: "risk_confirmed";
                    rejected: "rejected";
                    incomplete: "incomplete";
                }>;
                grade: z.ZodNullable<z.ZodEnum<{
                    A: "A";
                    B: "B";
                    C: "C";
                    D: "D";
                }>>;
                permissions: z.ZodArray<z.ZodObject<{
                    key: z.ZodString;
                    level: z.ZodEnum<{
                        normal: "normal";
                        elevated: "elevated";
                        high: "high";
                    }>;
                    label: z.ZodString;
                    detail: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                packageSize: z.ZodNumber;
                requiresSdk: z.ZodNullable<z.ZodNumber>;
                notes: z.ZodString;
                createdAt: z.ZodNumber;
                withdrawn: z.ZodBoolean;
            }, z.core.$strict>>;
            delisted: z.ZodBoolean;
            delistedReason: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getCommunityReleaseReview: HostApiContract<"GET", z.ZodObject<{
        releaseId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        releaseId: z.ZodString;
        status: z.ZodEnum<{
            pending: "pending";
            reviewing: "reviewing";
            passed: "passed";
            passed_with_notes: "passed_with_notes";
            flagged: "flagged";
            held: "held";
            risk_confirmed: "risk_confirmed";
            rejected: "rejected";
            incomplete: "incomplete";
        }>;
        grade: z.ZodNullable<z.ZodEnum<{
            A: "A";
            B: "B";
            C: "C";
            D: "D";
        }>>;
        deterministic: z.ZodArray<z.ZodObject<{
            severity: z.ZodEnum<{
                info: "info";
                warning: "warning";
                risk: "risk";
                block: "block";
            }>;
            title: z.ZodString;
            detail: z.ZodString;
            file: z.ZodOptional<z.ZodString>;
            line: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        ai: z.ZodNullable<z.ZodObject<{
            summary: z.ZodString;
            verdict: z.ZodString;
            grade: z.ZodEnum<{
                A: "A";
                B: "B";
                C: "C";
                D: "D";
            }>;
            dimensions: z.ZodArray<z.ZodObject<{
                key: z.ZodEnum<{
                    security: "security";
                    transparency: "transparency";
                    reliability: "reliability";
                    context_cost: "context_cost";
                    usability: "usability";
                    maintainability: "maintainability";
                    compliance: "compliance";
                }>;
                grade: z.ZodEnum<{
                    A: "A";
                    B: "B";
                    C: "C";
                    D: "D";
                }>;
                notes: z.ZodString;
            }, z.core.$strict>>;
            findings: z.ZodArray<z.ZodObject<{
                dimension: z.ZodEnum<{
                    security: "security";
                    transparency: "transparency";
                    reliability: "reliability";
                    context_cost: "context_cost";
                    usability: "usability";
                    maintainability: "maintainability";
                    compliance: "compliance";
                }>;
                severity: z.ZodEnum<{
                    info: "info";
                    warning: "warning";
                    risk: "risk";
                    suggestion: "suggestion";
                    critical: "critical";
                }>;
                title: z.ZodString;
                detail: z.ZodString;
                file: z.ZodOptional<z.ZodString>;
                line: z.ZodOptional<z.ZodNumber>;
                suggestion: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            exploitability: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        model: z.ZodNullable<z.ZodString>;
        error: z.ZodNullable<z.ZodString>;
        decisions: z.ZodArray<z.ZodObject<{
            decision: z.ZodString;
            note: z.ZodString;
            by: z.ZodString;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
        finishedAt: z.ZodNullable<z.ZodNumber>;
        reportUrl: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly requestCommunityReview: HostApiContract<"POST", z.ZodObject<{
        releaseId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        ok: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly withdrawCommunityRelease: HostApiContract<"POST", z.ZodObject<{
        releaseId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        ok: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly importCommunityRelease: HostApiContract<"POST", z.ZodObject<{
        releaseId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        token: z.ZodString;
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
        slug: z.ZodString;
        displayName: z.ZodString;
        scope: z.ZodEnum<{
            agent: "agent";
            "host-adapter": "host-adapter";
            "host-ui": "host-ui";
        }>;
        idempotent: z.ZodBoolean;
        slugConflict: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly publishToCommunity: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
        notes: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        releaseId: z.ZodString;
        reviewStatus: z.ZodEnum<{
            pending: "pending";
            reviewing: "reviewing";
            passed: "passed";
            passed_with_notes: "passed_with_notes";
            flagged: "flagged";
            held: "held";
            risk_confirmed: "risk_confirmed";
            rejected: "rejected";
            incomplete: "incomplete";
        }>;
        pageUrl: z.ZodString;
        reportUrl: z.ZodString;
        findings: z.ZodArray<z.ZodObject<{
            severity: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly testMcpServer: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        server: z.ZodDiscriminatedUnion<[z.ZodObject<{
            transport: z.ZodLiteral<"streamable-http">;
            name: z.ZodString;
            url: z.ZodString;
            headers: z.ZodDefault<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                value: z.ZodString;
                secret: z.ZodDefault<z.ZodBoolean>;
            }, z.core.$strict>>>;
        }, z.core.$strict>, z.ZodObject<{
            transport: z.ZodLiteral<"stdio">;
            name: z.ZodString;
            command: z.ZodString;
            args: z.ZodDefault<z.ZodArray<z.ZodString>>;
            env: z.ZodDefault<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                value: z.ZodString;
                secret: z.ZodDefault<z.ZodBoolean>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "transport">;
    }, z.core.$strict>, z.ZodObject<{
        ok: z.ZodBoolean;
        message: z.ZodString;
        serverName: z.ZodOptional<z.ZodString>;
        tools: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly createMcpExtension: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        displayName: z.ZodString;
        description: z.ZodDefault<z.ZodString>;
        server: z.ZodDiscriminatedUnion<[z.ZodObject<{
            transport: z.ZodLiteral<"streamable-http">;
            name: z.ZodString;
            url: z.ZodString;
            headers: z.ZodDefault<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                value: z.ZodString;
                secret: z.ZodDefault<z.ZodBoolean>;
            }, z.core.$strict>>>;
        }, z.core.$strict>, z.ZodObject<{
            transport: z.ZodLiteral<"stdio">;
            name: z.ZodString;
            command: z.ZodString;
            args: z.ZodDefault<z.ZodArray<z.ZodString>>;
            env: z.ZodDefault<z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                value: z.ZodString;
                secret: z.ZodDefault<z.ZodBoolean>;
            }, z.core.$strict>>>;
        }, z.core.$strict>], "transport">;
    }, z.core.$strict>, z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
        secretFields: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly commitExtensionImport: HostApiContract<"POST", z.ZodObject<{
        token: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        localSlug: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
        idempotent: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dshSettings: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        namespaces: z.ZodArray<z.ZodObject<{
            ns: z.ZodString;
            schema: z.ZodJSONSchema;
            resolved: z.ZodJSONSchema;
            base: z.ZodOptional<z.ZodJSONSchema>;
            user: z.ZodOptional<z.ZodJSONSchema>;
            applies: z.ZodEnum<{
                live: "live";
                restart: "restart";
            }>;
            secrets: z.ZodArray<z.ZodObject<{
                path: z.ZodArray<z.ZodString>;
                set: z.ZodBoolean;
            }, z.core.$strict>>;
            revision: z.ZodNumber;
            writable: z.ZodBoolean;
            owner: z.ZodOptional<z.ZodObject<{
                packageName: z.ZodString;
                packageVersion: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dshSettingsMutate: HostApiContract<"POST", z.ZodObject<{
        namespace: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodNumber;
        ops: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            op: z.ZodLiteral<"set">;
            path: z.ZodArray<z.ZodString>;
            value: z.ZodJSONSchema;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"unset">;
            path: z.ZodArray<z.ZodString>;
        }, z.core.$strict>], "op">>;
    }, z.core.$strict>, z.ZodObject<{
        ns: z.ZodString;
        schema: z.ZodJSONSchema;
        resolved: z.ZodJSONSchema;
        base: z.ZodOptional<z.ZodJSONSchema>;
        user: z.ZodOptional<z.ZodJSONSchema>;
        applies: z.ZodEnum<{
            live: "live";
            restart: "restart";
        }>;
        secrets: z.ZodArray<z.ZodObject<{
            path: z.ZodArray<z.ZodString>;
            set: z.ZodBoolean;
        }, z.core.$strict>>;
        revision: z.ZodNumber;
        writable: z.ZodBoolean;
        owner: z.ZodOptional<z.ZodObject<{
            packageName: z.ZodString;
            packageVersion: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dshCredentialsDescribe: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        refs: z.ZodArray<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        credentials: z.ZodRecord<z.ZodString, z.ZodObject<{
            configured: z.ZodBoolean;
            source: z.ZodOptional<z.ZodString>;
            writable: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dshCredentialSet: HostApiContract<"PUT", z.ZodObject<{
        ref: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        configured: z.ZodBoolean;
        source: z.ZodOptional<z.ZodString>;
        writable: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dshCredentialUnset: HostApiContract<"DELETE", z.ZodObject<{
        ref: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        configured: z.ZodBoolean;
        source: z.ZodOptional<z.ZodString>;
        writable: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly llmProviders: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        writable: z.ZodBoolean;
        protocols: z.ZodArray<z.ZodString>;
        providers: z.ZodArray<z.ZodObject<{
            provider: z.ZodString;
            displayName: z.ZodString;
            settingsNs: z.ZodString;
            settingsPath: z.ZodArray<z.ZodString>;
            settingsRevision: z.ZodNumber;
            declared: z.ZodBoolean;
            active: z.ZodBoolean;
            configured: z.ZodBoolean;
            baseURL: z.ZodOptional<z.ZodString>;
            api: z.ZodOptional<z.ZodString>;
            credential: z.ZodOptional<z.ZodObject<{
                configured: z.ZodBoolean;
                source: z.ZodOptional<z.ZodString>;
                writable: z.ZodBoolean;
            }, z.core.$strict>>;
            models: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                contextWindow: z.ZodOptional<z.ZodNumber>;
                maxTokens: z.ZodOptional<z.ZodNumber>;
                inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    text: "text";
                    image: "image";
                }>>>;
            }, z.core.$strict>>;
            modelsCustomized: z.ZodBoolean;
            discoverable: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly llmDiscoverModels: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        provider: z.ZodOptional<z.ZodString>;
        settingsNs: z.ZodOptional<z.ZodString>;
        baseURL: z.ZodOptional<z.ZodURL>;
        api: z.ZodOptional<z.ZodString>;
        apiKey: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        models: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodOptional<z.ZodString>;
            contextWindow: z.ZodOptional<z.ZodNumber>;
            maxTokens: z.ZodOptional<z.ZodNumber>;
            inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                text: "text";
                image: "image";
            }>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly llmTestProvider: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
        settingsNs: z.ZodOptional<z.ZodString>;
        apiKey: z.ZodOptional<z.ZodString>;
        baseURL: z.ZodOptional<z.ZodURL>;
        api: z.ZodOptional<z.ZodString>;
        models: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodOptional<z.ZodString>;
            contextWindow: z.ZodOptional<z.ZodNumber>;
            maxTokens: z.ZodOptional<z.ZodNumber>;
            inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                text: "text";
                image: "image";
            }>>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>, z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly llmProviderRemovalImpact: HostApiContract<"GET", z.ZodObject<{
        provider: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        provider: z.ZodString;
        displayName: z.ZodString;
        declared: z.ZodBoolean;
        expectedRevision: z.ZodNumber;
        models: z.ZodArray<z.ZodString>;
        blockedReason: z.ZodString;
        references: z.ZodArray<z.ZodObject<{
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            displayName: z.ZodString;
            model: z.ZodString;
            role: z.ZodEnum<{
                primary: "primary";
                vision: "vision";
            }>;
            scope: z.ZodEnum<{
                configuration: "configuration";
                context: "context";
            }>;
            channelId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
            channelName: z.ZodOptional<z.ZodString>;
            episodeStatus: z.ZodOptional<z.ZodEnum<{
                active: "active";
                opening: "opening";
            }>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly llmRemoveProvider: HostApiContract<"DELETE", z.ZodObject<{
        provider: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        writable: z.ZodBoolean;
        protocols: z.ZodArray<z.ZodString>;
        providers: z.ZodArray<z.ZodObject<{
            provider: z.ZodString;
            displayName: z.ZodString;
            settingsNs: z.ZodString;
            settingsPath: z.ZodArray<z.ZodString>;
            settingsRevision: z.ZodNumber;
            declared: z.ZodBoolean;
            active: z.ZodBoolean;
            configured: z.ZodBoolean;
            baseURL: z.ZodOptional<z.ZodString>;
            api: z.ZodOptional<z.ZodString>;
            credential: z.ZodOptional<z.ZodObject<{
                configured: z.ZodBoolean;
                source: z.ZodOptional<z.ZodString>;
                writable: z.ZodBoolean;
            }, z.core.$strict>>;
            models: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                contextWindow: z.ZodOptional<z.ZodNumber>;
                maxTokens: z.ZodOptional<z.ZodNumber>;
                inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    text: "text";
                    image: "image";
                }>>>;
            }, z.core.$strict>>;
            modelsCustomized: z.ZodBoolean;
            discoverable: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly llmRestoreProviderModels: HostApiContract<"POST", z.ZodObject<{
        provider: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        writable: z.ZodBoolean;
        protocols: z.ZodArray<z.ZodString>;
        providers: z.ZodArray<z.ZodObject<{
            provider: z.ZodString;
            displayName: z.ZodString;
            settingsNs: z.ZodString;
            settingsPath: z.ZodArray<z.ZodString>;
            settingsRevision: z.ZodNumber;
            declared: z.ZodBoolean;
            active: z.ZodBoolean;
            configured: z.ZodBoolean;
            baseURL: z.ZodOptional<z.ZodString>;
            api: z.ZodOptional<z.ZodString>;
            credential: z.ZodOptional<z.ZodObject<{
                configured: z.ZodBoolean;
                source: z.ZodOptional<z.ZodString>;
                writable: z.ZodBoolean;
            }, z.core.$strict>>;
            models: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                contextWindow: z.ZodOptional<z.ZodNumber>;
                maxTokens: z.ZodOptional<z.ZodNumber>;
                inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    text: "text";
                    image: "image";
                }>>>;
            }, z.core.$strict>>;
            modelsCustomized: z.ZodBoolean;
            discoverable: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly llmSaveProvider: HostApiContract<"POST", z.ZodObject<{
        provider: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodNumber;
        apiKey: z.ZodOptional<z.ZodString>;
        displayName: z.ZodOptional<z.ZodString>;
        baseURL: z.ZodOptional<z.ZodURL>;
        api: z.ZodOptional<z.ZodString>;
        models: z.ZodOptional<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            name: z.ZodOptional<z.ZodString>;
            contextWindow: z.ZodOptional<z.ZodNumber>;
            maxTokens: z.ZodOptional<z.ZodNumber>;
            inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                text: "text";
                image: "image";
            }>>>;
        }, z.core.$strict>>>;
    }, z.core.$strict>, z.ZodObject<{
        writable: z.ZodBoolean;
        protocols: z.ZodArray<z.ZodString>;
        providers: z.ZodArray<z.ZodObject<{
            provider: z.ZodString;
            displayName: z.ZodString;
            settingsNs: z.ZodString;
            settingsPath: z.ZodArray<z.ZodString>;
            settingsRevision: z.ZodNumber;
            declared: z.ZodBoolean;
            active: z.ZodBoolean;
            configured: z.ZodBoolean;
            baseURL: z.ZodOptional<z.ZodString>;
            api: z.ZodOptional<z.ZodString>;
            credential: z.ZodOptional<z.ZodObject<{
                configured: z.ZodBoolean;
                source: z.ZodOptional<z.ZodString>;
                writable: z.ZodBoolean;
            }, z.core.$strict>>;
            models: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                name: z.ZodString;
                contextWindow: z.ZodOptional<z.ZodNumber>;
                maxTokens: z.ZodOptional<z.ZodNumber>;
                inputModalities: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    text: "text";
                    image: "image";
                }>>>;
            }, z.core.$strict>>;
            modelsCustomized: z.ZodBoolean;
            discoverable: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly testConnection: HostApiContract<"POST", z.ZodObject<{
        connectionId: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        direction: z.ZodEnum<{
            receive: "receive";
            send: "send";
        }>;
        channelId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
    }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        status: z.ZodLiteral<"received">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        platformMessageId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"sent">;
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        platformMessageId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodEnum<{
            "waiting-for-message": "waiting-for-message";
            "needs-channel": "needs-channel";
            "needs-target": "needs-target";
            "not-connected": "not-connected";
        }>;
        message: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodLiteral<"failed">;
        kind: z.ZodString;
        message: z.ZodString;
        retryAfterMs: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>], "status">, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicInventory: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        rows: z.ZodArray<z.ZodObject<{
            pluginId: z.ZodString;
            agentId: z.ZodString;
            packages: z.ZodArray<z.ZodObject<{
                packageId: z.ZodString;
                name: z.ZodString;
                purpose: z.ZodString;
                hasHostHalf: z.ZodBoolean;
                hasClientHalf: z.ZodBoolean;
            }, z.core.$strict>>;
            currentPackageId: z.ZodOptional<z.ZodString>;
            nextPackageId: z.ZodOptional<z.ZodString>;
            activeRun: z.ZodOptional<z.ZodObject<{
                pluginRunId: z.ZodString;
                packageId: z.ZodString;
            }, z.core.$strict>>;
            latestRun: z.ZodOptional<z.ZodObject<{
                pluginRunId: z.ZodString;
                packageId: z.ZodString;
                mode: z.ZodEnum<{
                    run: "run";
                    update: "update";
                }>;
                status: z.ZodEnum<{
                    rejected: "rejected";
                    "awaiting-approval": "awaiting-approval";
                    "starting-host": "starting-host";
                    "client-pending": "client-pending";
                    running: "running";
                    waiting: "waiting";
                    failed: "failed";
                    cancelled: "cancelled";
                    stopped: "stopped";
                }>;
                approvalRequestId: z.ZodOptional<z.ZodString>;
                requiresApproval: z.ZodOptional<z.ZodBoolean>;
                host: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                client: z.ZodObject<{
                    status: z.ZodEnum<{
                        pending: "pending";
                        running: "running";
                        waiting: "waiting";
                        failed: "failed";
                        stopped: "stopped";
                        absent: "absent";
                    }>;
                    waitingFor: z.ZodArray<z.ZodString>;
                    error: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                error: z.ZodOptional<z.ZodObject<{
                    phase: z.ZodEnum<{
                        approval: "approval";
                        "host-load": "host-load";
                        "host-apply": "host-apply";
                        "client-load": "client-load";
                        "client-apply": "client-apply";
                        "client-render": "client-render";
                    }>;
                    message: z.ZodString;
                    stack: z.ZodOptional<z.ZodString>;
                    pluginId: z.ZodString;
                    packageId: z.ZodString;
                    pluginRunId: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicApprove: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        requestId: z.ZodString;
        pluginRunId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        accepted: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicDecline: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        requestId: z.ZodString;
        pluginRunId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        accepted: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicInvoke: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        pluginRunId: z.ZodString;
        method: z.ZodString;
        args: z.ZodOptional<z.ZodJSONSchema>;
    }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        ok: z.ZodLiteral<true>;
        value: z.ZodJSONSchema;
    }, z.core.$strict>, z.ZodObject<{
        ok: z.ZodLiteral<false>;
        message: z.ZodString;
    }, z.core.$strict>], "ok">, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicRunHostHalf: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        packageId: z.ZodString;
        mode: z.ZodEnum<{
            run: "run";
            update: "update";
        }>;
        requestId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        approveFutureVersions: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        ok: z.ZodLiteral<true>;
        pluginId: z.ZodString;
        packageId: z.ZodString;
        pluginRunId: z.ZodString;
        waitingFor: z.ZodArray<z.ZodString>;
        startedHere: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        message: z.ZodString;
        stack: z.ZodOptional<z.ZodString>;
        ok: z.ZodLiteral<false>;
    }, z.core.$strict>], "ok">, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicSettleUserRun: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        resolution: z.ZodDiscriminatedUnion<[z.ZodObject<{
            ok: z.ZodLiteral<true>;
            pluginRunId: z.ZodString;
            waitingFor: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            ok: z.ZodLiteral<false>;
            reason: z.ZodEnum<{
                rejected: "rejected";
                "host-half-failed": "host-half-failed";
                "client-half-failed": "client-half-failed";
            }>;
            pluginRunId: z.ZodOptional<z.ZodString>;
            startedHere: z.ZodOptional<z.ZodBoolean>;
            message: z.ZodOptional<z.ZodString>;
            stack: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>], "ok">;
    }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        ok: z.ZodLiteral<true>;
        status: z.ZodEnum<{
            "awaiting-approval": "awaiting-approval";
            running: "running";
            starting: "starting";
        }>;
        pluginId: z.ZodString;
        packageId: z.ZodString;
        pluginRunId: z.ZodString;
        waitingFor: z.ZodArray<z.ZodString>;
        clientWaitingFor: z.ZodOptional<z.ZodArray<z.ZodString>>;
        currentPackageId: z.ZodOptional<z.ZodString>;
        nextPackageId: z.ZodOptional<z.ZodString>;
        mode: z.ZodEnum<{
            run: "run";
            update: "update";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        ok: z.ZodLiteral<false>;
        reason: z.ZodEnum<{
            rejected: "rejected";
            cancelled: "cancelled";
            "host-half-failed": "host-half-failed";
            "client-half-failed": "client-half-failed";
            "plugin-missing": "plugin-missing";
            "package-missing": "package-missing";
            "invalid-mode": "invalid-mode";
            "transition-in-flight": "transition-in-flight";
            "not-running": "not-running";
        }>;
        message: z.ZodString;
        stack: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>], "ok">, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicGetClientCode: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        pluginRunId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        code: z.ZodString;
        name: z.ZodString;
        pluginId: z.ZodString;
        packageId: z.ZodString;
        pluginRunId: z.ZodString;
        permissions: z.ZodDefault<z.ZodObject<{
            permissions: z.ZodArray<z.ZodEnum<{
                "agents.read": "agents.read";
                "channels.read": "channels.read";
                "connections.read": "connections.read";
                "extensions.read": "extensions.read";
                "dsh-plugins.read": "dsh-plugins.read";
                "runtime.read": "runtime.read";
                "messages.read": "messages.read";
                "assets.read": "assets.read";
                "agents.manage": "agents.manage";
                "channels.manage": "channels.manage";
                "connections.manage": "connections.manage";
                "credentials.write": "credentials.write";
                "messages.send": "messages.send";
                "notifications.publish": "notifications.publish";
                "network.request": "network.request";
            }>>;
            networkOrigins: z.ZodDefault<z.ZodArray<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>>;
            capabilities: z.ZodOptional<z.ZodObject<{
                network: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    mode: z.ZodLiteral<"domains">;
                    domains: z.ZodArray<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"config">;
                    fields: z.ZodArray<z.ZodString>;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"unrestricted">;
                    purpose: z.ZodString;
                }, z.core.$strict>], "mode">>;
                storage: z.ZodOptional<z.ZodObject<{
                    scopes: z.ZodArray<z.ZodEnum<{
                        agent: "agent";
                        channel: "channel";
                        member: "member";
                        shared: "shared";
                    }>>;
                    quotaBytes: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                assets: z.ZodOptional<z.ZodObject<{
                    write: z.ZodLiteral<true>;
                }, z.core.$strict>>;
                history: z.ZodOptional<z.ZodObject<{
                    read: z.ZodLiteral<true>;
                }, z.core.$strict>>;
                inboundHook: z.ZodOptional<z.ZodObject<{
                    reads: z.ZodEnum<{
                        triggered: "triggered";
                        all: "all";
                    }>;
                    mayHide: z.ZodBoolean;
                    mayForceTrigger: z.ZodBoolean;
                    timeoutMs: z.ZodNumber;
                }, z.core.$strict>>;
                jobs: z.ZodOptional<z.ZodObject<{
                    declared: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        id: z.ZodString;
                        label: z.ZodString;
                        cron: z.ZodString;
                        timezone: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>>;
                    runtime: z.ZodOptional<z.ZodObject<{
                        maxActive: z.ZodNumber;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                platform: z.ZodOptional<z.ZodObject<{
                    actions: z.ZodDefault<z.ZodArray<z.ZodObject<{
                        adapter: z.ZodString;
                        action: z.ZodString;
                    }, z.core.$strict>>>;
                    raw: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                llm: z.ZodOptional<z.ZodObject<{
                    maxCallsPerTurn: z.ZodNumber;
                    maxOutputTokens: z.ZodNumber;
                }, z.core.$strict>>;
                mcp: z.ZodOptional<z.ZodObject<{
                    servers: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                        transport: z.ZodLiteral<"streamable-http">;
                        name: z.ZodString;
                        url: z.ZodString;
                        headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                            secret: z.ZodString;
                        }, z.core.$strict>]>>>;
                    }, z.core.$strict>, z.ZodObject<{
                        transport: z.ZodLiteral<"stdio">;
                        name: z.ZodString;
                        command: z.ZodString;
                        args: z.ZodDefault<z.ZodArray<z.ZodString>>;
                        env: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodObject<{
                            secret: z.ZodString;
                        }, z.core.$strict>]>>>;
                    }, z.core.$strict>], "transport">>;
                }, z.core.$strict>>;
                context: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    kind: z.ZodEnum<{
                        static: "static";
                        dynamic: "dynamic";
                    }>;
                    maxChars: z.ZodNumber;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicReportRenderFailure: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        pluginRunId: z.ZodString;
        failure: z.ZodObject<{
            slot: z.ZodString;
            message: z.ZodString;
            stack: z.ZodOptional<z.ZodString>;
            abdicated: z.ZodBoolean;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        ok: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicReportGuardFailure: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        pluginRunId: z.ZodString;
        message: z.ZodString;
        stack: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        ok: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dynamicReportClientVerification: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        packageId: z.ZodString;
        pluginRunId: z.ZodString;
        renderedPanels: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            anchor: z.ZodEnum<{
                agent: "agent";
                channel: "channel";
                extension: "extension";
                connection: "connection";
            }>;
            title: z.ZodString;
            icon: z.ZodOptional<z.ZodEnum<{
                "app-window": "app-window";
                "bar-chart": "bar-chart";
                "book-open": "book-open";
                boxes: "boxes";
                database: "database";
                "file-text": "file-text";
                folder: "folder";
                globe: "globe";
                "layout-dashboard": "layout-dashboard";
                puzzle: "puzzle";
                terminal: "terminal";
                workflow: "workflow";
                wrench: "wrench";
            }>>;
            densities: z.ZodArray<z.ZodEnum<{
                compact: "compact";
                full: "full";
            }>>;
            role: z.ZodOptional<z.ZodEnum<{
                status: "status";
                diagnostics: "diagnostics";
                setup: "setup";
            }>>;
            when: z.ZodOptional<z.ZodObject<{
                channelKinds: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    internal: "internal";
                    direct: "direct";
                    group: "group";
                }>>>;
            }, z.core.$strict>>;
            kind: z.ZodLiteral<"panel">;
        }, z.core.$strict>>>;
        renderedToolViews: z.ZodDefault<z.ZodArray<z.ZodString>>;
        renderedMessageRenderers: z.ZodDefault<z.ZodArray<z.ZodString>>;
        renderedPages: z.ZodDefault<z.ZodArray<z.ZodObject<{
            kind: z.ZodLiteral<"host-page">;
            entryId: z.ZodString;
            title: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            icon: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"host-icon">;
                name: z.ZodEnum<{
                    "app-window": "app-window";
                    "bar-chart": "bar-chart";
                    "book-open": "book-open";
                    boxes: "boxes";
                    database: "database";
                    "file-text": "file-text";
                    folder: "folder";
                    globe: "globe";
                    "layout-dashboard": "layout-dashboard";
                    puzzle: "puzzle";
                    terminal: "terminal";
                    workflow: "workflow";
                    wrench: "wrench";
                }>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"svg">;
                path: z.ZodString;
                sha256: z.ZodString;
            }, z.core.$strict>], "kind">;
            objectPane: z.ZodEnum<{
                hidden: "hidden";
                navigation: "navigation";
            }>;
            startPath: z.ZodString;
        }, z.core.$strict>>>;
        usedUiComponents: z.ZodDefault<z.ZodArray<z.ZodEnum<{
            Button: "Button";
            IconButton: "IconButton";
            Input: "Input";
            Textarea: "Textarea";
            Select: "Select";
            Switch: "Switch";
            Tabs: "Tabs";
            Dialog: "Dialog";
            Popover: "Popover";
            Tooltip: "Tooltip";
            Field: "Field";
            StatusBadge: "StatusBadge";
            InlineFeedback: "InlineFeedback";
            EmptyState: "EmptyState";
            Spinner: "Spinner";
            PageHeader: "PageHeader";
            MetricStrip: "MetricStrip";
            Metric: "Metric";
            Section: "Section";
            Stack: "Stack";
            Grid: "Grid";
            DataTable: "DataTable";
            PropertyList: "PropertyList";
            PropertyRow: "PropertyRow";
        }>>>;
        pageGeometry: z.ZodDefault<z.ZodArray<z.ZodObject<{
            entryId: z.ZodString;
            objectPane: z.ZodEnum<{
                hidden: "hidden";
                navigation: "navigation";
            }>;
            viewport: z.ZodObject<{
                width: z.ZodNumber;
                height: z.ZodNumber;
            }, z.core.$strict>;
            insets: z.ZodObject<{
                top: z.ZodNumber;
                right: z.ZodNumber;
                bottom: z.ZodNumber;
                left: z.ZodNumber;
            }, z.core.$strict>;
            contentAxesAligned: z.ZodBoolean;
            horizontalOverflow: z.ZodBoolean;
            titleDistinct: z.ZodBoolean;
        }, z.core.$strict>>>;
        navigationEntries: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        ok: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly saveExtensionFromDynamic: HostApiContract<"POST", z.ZodObject<{}, z.core.$strict>, z.ZodUnion<readonly [z.ZodObject<{
        taskId: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
        attemptId: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
        displayName: z.ZodString;
        slug: z.ZodString;
        description: z.ZodDefault<z.ZodString>;
        targetExtensionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        episodeId: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
        pluginId: z.ZodString;
        packageId: z.ZodString;
        displayName: z.ZodString;
        slug: z.ZodString;
        description: z.ZodDefault<z.ZodString>;
        targetExtensionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">>;
    }, z.core.$strict>]>, z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
        activation: z.ZodLiteral<"inactive">;
        installation: z.ZodOptional<z.ZodLiteral<"uninstalled">>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly extensionClientCall: HostApiContract<"POST", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        method: z.ZodString;
        input: z.ZodOptional<z.ZodJSONSchema>;
    }, z.core.$strict>, z.ZodObject<{
        value: z.ZodJSONSchema;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly extensionClientDiagnostic: HostApiContract<"POST", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        status: z.ZodEnum<{
            failed: "failed";
            loaded: "loaded";
        }>;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        accepted: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly hostExtensionClientDiagnostic: HostApiContract<"POST", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodEnum<{
            failed: "failed";
            loaded: "loaded";
        }>;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        accepted: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly activateExtension: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
        permissionApproval: z.ZodOptional<z.ZodObject<{
            permissionDigest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        activation: z.ZodObject<{
            agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
            extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
            extensionRevisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
            config: z.ZodJSONSchema;
            configuredSecrets: z.ZodOptional<z.ZodArray<z.ZodString>>;
            activatedAt: z.ZodNumber;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly deactivateExtension: HostApiContract<"DELETE", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        disabled: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateExtensionActivationConfig: HostApiContract<"PUT", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        config: z.ZodJSONSchema;
        secrets: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        config: z.ZodJSONSchema;
        configuredSecrets: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateHostExtensionConfig: HostApiContract<"PUT", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        config: z.ZodJSONSchema;
    }, z.core.$strict>, z.ZodObject<{
        config: z.ZodJSONSchema;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly installHostExtension: HostApiContract<"PUT", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        revisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
        permissionApproval: z.ZodOptional<z.ZodObject<{
            permissionDigest: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        installation: z.ZodObject<{
            extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
            extensionRevisionId: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
            installedAt: z.ZodNumber;
            config: z.ZodJSONSchema;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly uninstallHostExtension: HostApiContract<"DELETE", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        uninstalled: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateHostUiPagePreferences: HostApiContract<"PUT", z.ZodObject<{}, z.core.$strict>, z.ZodObject<{
        expectedRevision: z.ZodNumber;
        entries: z.ZodArray<z.ZodObject<{
            pageInstanceId: z.core.$ZodBranded<z.ZodString, "HostUiPageInstanceId", "out">;
            visible: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        revision: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly callHostUiPage: HostApiContract<"POST", z.ZodObject<{
        pageInstanceId: z.core.$ZodBranded<z.ZodString, "HostUiPageInstanceId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        method: z.ZodString;
        input: z.ZodDefault<z.ZodJSONSchema>;
    }, z.core.$strict>, z.ZodObject<{
        value: z.ZodJSONSchema;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly reportHostUiPageDiagnostic: HostApiContract<"POST", z.ZodObject<{
        pageInstanceId: z.core.$ZodBranded<z.ZodString, "HostUiPageInstanceId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        status: z.ZodEnum<{
            ready: "ready";
            "load-failed": "load-failed";
            "navigation-failed": "navigation-failed";
            "rpc-failed": "rpc-failed";
        }>;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        recorded: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly markChannelRead: HostApiContract<"POST", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        upTo: z.ZodOptional<z.ZodObject<{
            occurredAt: z.ZodNumber;
            sourceId: z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        activity: z.ZodObject<{
            lastActivityAt: z.ZodOptional<z.ZodNumber>;
            lastMessage: z.ZodOptional<z.ZodObject<{
                role: z.ZodEnum<{
                    agent: "agent";
                    system: "system";
                    member: "member";
                    admin: "admin";
                }>;
                author: z.ZodString;
                preview: z.ZodString;
                occurredAt: z.ZodNumber;
            }, z.core.$strict>>;
            unreadCount: z.ZodNumber;
            unreadCapped: z.ZodBoolean;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listAttention: HostApiContract<"GET", z.ZodObject<{}, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        revision: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            kind: z.ZodEnum<{
                "delivery-unconfirmed": "delivery-unconfirmed";
                "delivery-failed": "delivery-failed";
                "turn-failed": "turn-failed";
                "authoring-approval": "authoring-approval";
                "connection-unhealthy": "connection-unhealthy";
                "agent-model-unavailable": "agent-model-unavailable";
                "agent-vision-unavailable": "agent-vision-unavailable";
            }>;
            severity: z.ZodEnum<{
                info: "info";
                warning: "warning";
                critical: "critical";
            }>;
            subject: z.ZodObject<{
                kind: z.ZodEnum<{
                    agent: "agent";
                    channel: "channel";
                    connection: "connection";
                    outbound: "outbound";
                    "authoring-task": "authoring-task";
                }>;
                id: z.ZodString;
            }, z.core.$strict>;
            related: z.ZodObject<{
                channelId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ChannelId", "out">>;
                agentId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AgentId", "out">>;
                connectionId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">>;
                taskId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">>;
                outboundId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">>;
            }, z.core.$strict>;
            title: z.ZodString;
            detail: z.ZodString;
            action: z.ZodObject<{
                kind: z.ZodEnum<{
                    "open-channel": "open-channel";
                    "resolve-delivery": "resolve-delivery";
                    "open-authoring-task": "open-authoring-task";
                    "open-connection": "open-connection";
                    "open-agent": "open-agent";
                }>;
                label: z.ZodString;
            }, z.core.$strict>;
            occurredAt: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly dismissAttention: HostApiContract<"POST", z.ZodObject<{
        attentionId: z.ZodString;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        dismissed: z.ZodLiteral<true>;
        revision: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getChannelPending: HostApiContract<"GET", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        episodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
        items: z.ZodArray<z.ZodObject<{
            admissionId: z.ZodString;
            target: z.ZodEnum<{
                "next-step": "next-step";
                "next-turn": "next-turn";
            }>;
            events: z.ZodArray<z.ZodObject<{
                eventId: z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">;
                author: z.ZodString;
                preview: z.ZodString;
                receivedAt: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly stopChannelTask: HostApiContract<"POST", z.ZodObject<{
        channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        expectedEpisodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
    }, z.core.$strict>, z.ZodObject<{
        result: z.ZodEnum<{
            stopped: "stopped";
            idle: "idle";
        }>;
        episodeId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">>;
        retainedPending: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly resolveOutbound: HostApiContract<"POST", z.ZodObject<{
        outboundId: z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        action: z.ZodEnum<{
            retry: "retry";
            "confirm-delivered": "confirm-delivered";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        outboundId: z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">;
        action: z.ZodEnum<{
            retry: "retry";
            "confirm-delivered": "confirm-delivered";
        }>;
        deliveryState: z.ZodEnum<{
            unknown: "unknown";
            failed: "failed";
            planned: "planned";
            sending: "sending";
            sent: "sent";
            "partially-sent": "partially-sent";
        }>;
        resolvedAt: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly getChannelActivity: HostApiContract<"GET", z.ZodObject<{
        window: z.ZodDefault<z.ZodString>;
        bucket: z.ZodDefault<z.ZodString>;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        from: z.ZodNumber;
        to: z.ZodNumber;
        bucketMs: z.ZodNumber;
        channels: z.ZodArray<z.ZodObject<{
            channelId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
            counts: z.ZodArray<z.ZodNumber>;
            total: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly listAgentRevisions: HostApiContract<"GET", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        currentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
        revisions: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
            revision: z.ZodNumber;
            createdAt: z.ZodNumber;
            displayName: z.ZodString;
            model: z.ZodObject<{
                provider: z.ZodString;
                model: z.ZodString;
            }, z.core.$strict>;
            changedFields: z.ZodArray<z.ZodEnum<{
                model: "model";
                name: "name";
                approvalPolicy: "approvalPolicy";
                persona: "persona";
                imagePolicy: "imagePolicy";
                capabilities: "capabilities";
            }>>;
            current: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly restoreAgentRevision: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        revisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        expectedCurrentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        currentRevisionId: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly updateAgentAppearance: HostApiContract<"PATCH", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        hue: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        avatarAssetId: z.ZodOptional<z.ZodNull>;
    }, z.core.$strict>, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        appearance: z.ZodObject<{
            hue: z.ZodOptional<z.ZodNumber>;
            avatarAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly uploadAgentAvatar: HostApiContract<"POST", z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        bytes: z.ZodCustom<Uint8Array<ArrayBuffer>, Uint8Array<ArrayBuffer>>;
        fileName: z.ZodOptional<z.ZodString>;
        operationId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        agentId: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
        appearance: z.ZodObject<{
            hue: z.ZodOptional<z.ZodNumber>;
            avatarAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    readonly deleteLocalExtension: HostApiContract<"DELETE", z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    }, z.core.$strict>, z.ZodUndefined, z.ZodObject<{
        deleted: z.ZodLiteral<true>;
    }, z.core.$strict>, z.ZodObject<{
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
};
export type HostApiContractName = keyof typeof HostApiContracts;
export type HostApiParams<Name extends HostApiContractName> = z.input<(typeof HostApiContracts)[Name]['params']>;
export type HostApiRequest<Name extends HostApiContractName> = z.input<(typeof HostApiContracts)[Name]['request']>;
export type HostApiResponse<Name extends HostApiContractName> = z.output<(typeof HostApiContracts)[Name]['response']>;
export type HostApiContractParams<Contract> = Contract extends {
    readonly params: z.ZodType<unknown, infer Input>;
} ? Input : never;
export type HostApiContractRequest<Contract> = Contract extends {
    readonly request: z.ZodType<unknown, infer Input>;
} ? Input : never;
export type HostApiContractResponse<Contract> = Contract extends {
    readonly response: z.ZodType<infer Output, unknown>;
} ? Output : never;
export declare function buildHostApiContractPath<Params extends AnySchema>(contract: {
    readonly path: string;
    readonly params: Params;
}, input: unknown): string;
export declare function buildHostApiPath<Name extends HostApiContractName>(name: Name, input: HostApiParams<Name>): string;
export {};
//# sourceMappingURL=host-api.d.ts.map