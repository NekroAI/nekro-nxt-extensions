import { z } from 'zod';
export declare const ServerInstanceIdSchema: z.core.$ZodBranded<z.ZodString, "ServerInstanceId", "out">;
export type ServerInstanceId = z.output<typeof ServerInstanceIdSchema>;
export declare const ManagementDeviceIdSchema: z.core.$ZodBranded<z.ZodString, "ManagementDeviceId", "out">;
export type ManagementDeviceId = z.output<typeof ManagementDeviceIdSchema>;
export declare const InstanceDescriptorWireSchema: z.ZodObject<{
    format: z.ZodLiteral<"nxt.instance-descriptor">;
    descriptorVersion: z.ZodNumber;
    instanceId: z.core.$ZodBranded<z.ZodString, "ServerInstanceId", "out">;
    releaseId: z.ZodString;
    productVersion: z.ZodString;
    managementProtocol: z.ZodNumber;
    desktopChromeProtocol: z.ZodNumber;
    transport: z.ZodString;
}, z.core.$loose>;
export type InstanceDescriptorWire = z.output<typeof InstanceDescriptorWireSchema>;
export declare const InstanceDescriptorSchema: z.ZodObject<{
    format: z.ZodLiteral<"nxt.instance-descriptor">;
    descriptorVersion: z.ZodLiteral<1>;
    instanceId: z.core.$ZodBranded<z.ZodString, "ServerInstanceId", "out">;
    releaseId: z.ZodString;
    productVersion: z.ZodString;
    managementProtocol: z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>]>;
    desktopChromeProtocol: z.ZodLiteral<1>;
    transport: z.ZodEnum<{
        "loopback-http": "loopback-http";
        "auto-tls-pinned-v1": "auto-tls-pinned-v1";
        "explicit-http-v1": "explicit-http-v1";
    }>;
}, z.core.$strict>;
export type InstanceDescriptor = z.output<typeof InstanceDescriptorSchema>;
export declare const ManagementChallengeResponseSchema: z.ZodObject<{
    challengeId: z.ZodString;
    serverNonce: z.ZodString;
    instanceId: z.core.$ZodBranded<z.ZodString, "ServerInstanceId", "out">;
    spkiSha256: z.ZodString;
    expiresAt: z.ZodNumber;
}, z.core.$strict>;
export type ManagementChallengeResponse = z.output<typeof ManagementChallengeResponseSchema>;
export declare const InsecureHttpManagementChallengeResponseSchema: z.ZodObject<{
    challengeId: z.ZodString;
    serverNonce: z.ZodString;
    instanceId: z.core.$ZodBranded<z.ZodString, "ServerInstanceId", "out">;
    transportBinding: z.ZodString;
    expiresAt: z.ZodNumber;
}, z.core.$strict>;
export type InsecureHttpManagementChallengeResponse = z.output<typeof InsecureHttpManagementChallengeResponseSchema>;
export declare const ManagementDeviceEnrollmentRequestSchema: z.ZodObject<{
    challengeId: z.ZodString;
    clientNonce: z.ZodString;
    proof: z.ZodString;
    label: z.ZodString;
    clientReleaseId: z.ZodString;
}, z.core.$strict>;
export type ManagementDeviceEnrollmentRequest = z.input<typeof ManagementDeviceEnrollmentRequestSchema>;
export declare const ManagementDeviceEnrollmentResponseSchema: z.ZodObject<{
    deviceId: z.core.$ZodBranded<z.ZodString, "ManagementDeviceId", "out">;
    deviceSecret: z.ZodString;
}, z.core.$strict>;
export type ManagementDeviceEnrollmentResponse = z.output<typeof ManagementDeviceEnrollmentResponseSchema>;
export declare const ManagementSessionRequestSchema: z.ZodObject<{
    deviceId: z.core.$ZodBranded<z.ZodString, "ManagementDeviceId", "out">;
    deviceSecret: z.ZodString;
}, z.core.$strict>;
export type ManagementSessionRequest = z.input<typeof ManagementSessionRequestSchema>;
export declare const ManagementSessionResponseSchema: z.ZodObject<{
    authenticated: z.ZodLiteral<true>;
    deviceId: z.core.$ZodBranded<z.ZodString, "ManagementDeviceId", "out">;
    csrfToken: z.ZodString;
}, z.core.$strict>;
export type ManagementSessionResponse = z.output<typeof ManagementSessionResponseSchema>;
export declare const ManagementDeviceViewSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "ManagementDeviceId", "out">;
    label: z.ZodString;
    createdAt: z.ZodNumber;
    lastUsedAt: z.ZodOptional<z.ZodNumber>;
    revokedAt: z.ZodOptional<z.ZodNumber>;
    current: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type ManagementDeviceView = z.output<typeof ManagementDeviceViewSchema>;
export declare const ClientNotificationSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        "action-required": "action-required";
    }>;
    title: z.ZodString;
    body: z.ZodString;
    occurredAt: z.ZodNumber;
    route: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ClientNotification = z.output<typeof ClientNotificationSchema>;
export declare const MANAGEMENT_PAIR_PROOF_PREFIX: "nxt-management-pair-v1";
export declare const managementPairProofMessage: (input: {
    readonly challengeId: string;
    readonly serverNonce: string;
    readonly clientNonce: string;
    readonly instanceId: ServerInstanceId;
    readonly spkiSha256: string;
}) => string;
export declare const INSECURE_HTTP_MANAGEMENT_PAIR_PROOF_PREFIX: "nxt-management-pair-insecure-http-v1";
export declare const insecureHttpManagementPairProofMessage: (input: {
    readonly challengeId: string;
    readonly serverNonce: string;
    readonly clientNonce: string;
    readonly instanceId: ServerInstanceId;
    readonly transportBinding: string;
}) => string;
//# sourceMappingURL=management-api.d.ts.map