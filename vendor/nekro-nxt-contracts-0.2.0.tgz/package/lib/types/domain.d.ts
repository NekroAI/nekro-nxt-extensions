import { z } from 'zod';
export declare const AgentIdSchema: z.core.$ZodBranded<z.ZodString, "AgentId", "out">;
export declare const AgentRevisionIdSchema: z.core.$ZodBranded<z.ZodString, "AgentRevisionId", "out">;
export declare const ConnectionIdSchema: z.core.$ZodBranded<z.ZodString, "ConnectionId", "out">;
export declare const ConnectionEventIdSchema: z.core.$ZodBranded<z.ZodString, "ConnectionEventId", "out">;
export declare const ChannelIdSchema: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
export declare const ChannelEventIdSchema: z.core.$ZodBranded<z.ZodString, "ChannelEventId", "out">;
export declare const PlatformIdentityIdSchema: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
export declare const ChannelMemberIdSchema: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
export declare const AdmissionIdSchema: z.core.$ZodBranded<z.ZodString, "AdmissionId", "out">;
export declare const OutboundIntentIdSchema: z.core.$ZodBranded<z.ZodString, "OutboundIntentId", "out">;
export declare const LogicalMessageIdSchema: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
export declare const PhysicalDeliveryIdSchema: z.core.$ZodBranded<z.ZodString, "PhysicalDeliveryId", "out">;
export declare const AssetIdSchema: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
export declare const EpisodeIdSchema: z.core.$ZodBranded<z.ZodString, "EpisodeId", "out">;
export declare const EpisodeHandoffIdSchema: z.core.$ZodBranded<z.ZodString, "EpisodeHandoffId", "out">;
export declare const ExtensionIdSchema: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
export declare const ExtensionRevisionIdSchema: z.core.$ZodBranded<z.ZodString, "ExtensionRevisionId", "out">;
export declare const DshPluginPackageIdSchema: z.core.$ZodBranded<z.ZodString, "DshPluginPackageId", "out">;
export declare const DshPluginEntryIdSchema: z.core.$ZodBranded<z.ZodString, "DshPluginEntryId", "out">;
export declare const HostUiPageInstanceIdSchema: z.core.$ZodBranded<z.ZodString, "HostUiPageInstanceId", "out">;
export declare const AuthoringTaskIdSchema: z.core.$ZodBranded<z.ZodString, "AuthoringTaskId", "out">;
export declare const AuthoringAttemptIdSchema: z.core.$ZodBranded<z.ZodString, "AuthoringAttemptId", "out">;
export type AgentId = z.infer<typeof AgentIdSchema>;
export type AgentRevisionId = z.infer<typeof AgentRevisionIdSchema>;
export type ConnectionId = z.infer<typeof ConnectionIdSchema>;
export type ConnectionEventId = z.infer<typeof ConnectionEventIdSchema>;
export type ChannelId = z.infer<typeof ChannelIdSchema>;
export type ChannelEventId = z.infer<typeof ChannelEventIdSchema>;
export type PlatformIdentityId = z.infer<typeof PlatformIdentityIdSchema>;
export type ChannelMemberId = z.infer<typeof ChannelMemberIdSchema>;
export type AdmissionId = z.infer<typeof AdmissionIdSchema>;
export type OutboundIntentId = z.infer<typeof OutboundIntentIdSchema>;
export type LogicalMessageId = z.infer<typeof LogicalMessageIdSchema>;
export type PhysicalDeliveryId = z.infer<typeof PhysicalDeliveryIdSchema>;
export type AssetId = z.infer<typeof AssetIdSchema>;
export type EpisodeId = z.infer<typeof EpisodeIdSchema>;
export type EpisodeHandoffId = z.infer<typeof EpisodeHandoffIdSchema>;
export type ExtensionId = z.infer<typeof ExtensionIdSchema>;
export type ExtensionRevisionId = z.infer<typeof ExtensionRevisionIdSchema>;
export type DshPluginPackageId = z.infer<typeof DshPluginPackageIdSchema>;
export type DshPluginEntryId = z.infer<typeof DshPluginEntryIdSchema>;
export type HostUiPageInstanceId = z.infer<typeof HostUiPageInstanceIdSchema>;
export type AuthoringTaskId = z.infer<typeof AuthoringTaskIdSchema>;
export type AuthoringAttemptId = z.infer<typeof AuthoringAttemptIdSchema>;
export declare const AdapterActivityKeySchema: z.ZodString;
export type AdapterActivityKey = z.infer<typeof AdapterActivityKeySchema>;
export declare const PromptSegmentSchema: z.ZodUnion<readonly [z.ZodObject<{
    type: z.ZodLiteral<"text">;
    text: z.ZodString;
}, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"reference">;
    kind: z.ZodLiteral<"platform-user">;
    targetId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
    labelSnapshot: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"reference">;
    kind: z.ZodLiteral<"channel">;
    targetId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
    labelSnapshot: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"reference">;
    kind: z.ZodLiteral<"extension">;
    targetId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    labelSnapshot: z.ZodString;
}, z.core.$strict>], "kind">]>;
export declare const PROMPT_DOCUMENT_MAX_REFERENCES = 128;
export declare const PROMPT_DOCUMENT_MAX_PLAIN_TEXT_LENGTH: number;
export declare const PromptDocumentV1Schema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    segments: z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
        type: z.ZodLiteral<"text">;
        text: z.ZodString;
    }, z.core.$strict>, z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"reference">;
        kind: z.ZodLiteral<"platform-user">;
        targetId: z.core.$ZodBranded<z.ZodString, "PlatformIdentityId", "out">;
        labelSnapshot: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"reference">;
        kind: z.ZodLiteral<"channel">;
        targetId: z.core.$ZodBranded<z.ZodString, "ChannelId", "out">;
        labelSnapshot: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"reference">;
        kind: z.ZodLiteral<"extension">;
        targetId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        labelSnapshot: z.ZodString;
    }, z.core.$strict>], "kind">]>>;
}, z.core.$strict>;
export type PromptSegment = z.output<typeof PromptSegmentSchema>;
export type PromptDocumentV1 = z.output<typeof PromptDocumentV1Schema>;
export declare const promptDocumentFromText: (text: string) => PromptDocumentV1;
export declare const promptDocumentPlainText: (document: PromptDocumentV1) => string;
export declare const normalizePromptDocument: (input: unknown) => PromptDocumentV1;
export type JsonValue = null | boolean | number | string | JsonValue[] | {
    readonly [key: string]: JsonValue;
};
export declare const JsonValueSchema: z.ZodJSONSchema;
export declare function parseJsonValue(input: unknown): JsonValue;
/** Package identity and source for one DSH extension visible in the current Host. */
export interface DshPluginCatalogEntry {
    readonly packageName: string;
    readonly packageVersion: string;
    readonly origin: 'builtin' | 'profile' | 'dynamic' | 'installed';
    readonly settingsNamespaces: readonly string[];
    readonly loadError?: {
        readonly code: string;
        readonly message: string;
    };
}
export type DshPluginInstallSource = 'registry' | 'tarball' | 'imported';
export type DshPluginActivationScope = 'host' | 'agent';
export interface DshPluginPackageRecord {
    readonly id: DshPluginPackageId;
    readonly packageName: string;
    readonly packageVersion: string;
    readonly source: DshPluginInstallSource;
    readonly packageDigest: string;
    readonly integrity?: string;
    readonly lockfileDigest: string;
    readonly manifest: JsonValue;
    readonly approvedBuilds: readonly string[];
    readonly installedAt: number;
}
export interface DshPluginEntryRecord {
    readonly id: DshPluginEntryId;
    readonly packageId: DshPluginPackageId;
    readonly entryKey: string;
    readonly moduleName: string;
    readonly suggestedScope: DshPluginActivationScope;
    readonly selectedScope?: DshPluginActivationScope;
    readonly config: JsonValue;
    readonly createdAt: number;
}
export interface DshPluginActivationRecord {
    readonly entryId: DshPluginEntryId;
    readonly targetKey: string;
    readonly target: DshPluginActivationScope;
    readonly agentId?: AgentId;
    readonly activatedAt: number;
}
export interface DshPluginDiagnosticRecord {
    readonly entryId: DshPluginEntryId;
    readonly targetKey: string;
    readonly status: 'active' | 'load-failed' | 'restore-failed' | 'dispose-failed';
    readonly phase: 'import' | 'apply' | 'update' | 'dispose' | 'restore';
    readonly message?: string;
    readonly observedAt: number;
}
export interface DshSettingsNamespaceView {
    readonly ns: string;
    readonly schema: unknown;
    readonly resolved: unknown;
    readonly base?: unknown;
    readonly user?: unknown;
    readonly applies: 'live' | 'restart';
    readonly secrets: readonly {
        readonly path: readonly string[];
        readonly set: boolean;
    }[];
    readonly revision: number;
    readonly writable: boolean;
    readonly owner?: {
        readonly packageName: string;
        readonly packageVersion: string;
    };
}
export type DshSettingsPathOperation = {
    readonly op: 'set';
    readonly path: readonly string[];
    readonly value: unknown;
} | {
    readonly op: 'unset';
    readonly path: readonly string[];
};
export interface DshSettingsMutationRequest {
    readonly expectedRevision: number;
    readonly ops: readonly DshSettingsPathOperation[];
}
export interface DshCredentialView {
    readonly configured: boolean;
    readonly source?: string;
    readonly writable: boolean;
}
export declare const RICH_EXTENSION_MAX_BYTES: number;
export declare const RichExtensionSchema: z.ZodJSONSchema;
export declare const RichTargetUrlSchema: z.ZodURL;
export declare const MessagePartSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"text">;
    text: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"mention">;
    memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"image">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
    alt: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"file">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
    name: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"audio">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"quote">;
    messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"rich">;
    adapterKey: z.ZodString;
    kind: z.ZodString;
    summary: z.ZodString;
    title: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodString>;
    targetUrl: z.ZodOptional<z.ZodURL>;
    previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
    extension: z.ZodOptional<z.ZodJSONSchema>;
}, z.core.$strict>], "type">;
export type MessagePart = z.infer<typeof MessagePartSchema>;
export declare const MessagePartsSchema: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"text">;
    text: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"mention">;
    memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"image">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
    alt: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"file">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
    name: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"audio">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"quote">;
    messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"rich">;
    adapterKey: z.ZodString;
    kind: z.ZodString;
    summary: z.ZodString;
    title: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodString>;
    targetUrl: z.ZodOptional<z.ZodURL>;
    previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
    extension: z.ZodOptional<z.ZodJSONSchema>;
}, z.core.$strict>], "type">>;
export declare const NonEmptyMessagePartsSchema: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"text">;
    text: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"mention">;
    memberId: z.core.$ZodBranded<z.ZodString, "ChannelMemberId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"image">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
    alt: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"file">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
    name: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"audio">;
    assetId: z.core.$ZodBranded<z.ZodString, "AssetId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"quote">;
    messageId: z.core.$ZodBranded<z.ZodString, "LogicalMessageId", "out">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"rich">;
    adapterKey: z.ZodString;
    kind: z.ZodString;
    summary: z.ZodString;
    title: z.ZodOptional<z.ZodString>;
    source: z.ZodOptional<z.ZodString>;
    targetUrl: z.ZodOptional<z.ZodURL>;
    previewAssetId: z.ZodOptional<z.core.$ZodBranded<z.ZodString, "AssetId", "out">>;
    extension: z.ZodOptional<z.ZodJSONSchema>;
}, z.core.$strict>], "type">>;
export declare function parseMessageParts(input: unknown): MessagePart[];
export declare const messagePartAssetIds: (part: MessagePart) => readonly AssetId[];
export declare const messagePartAssetId: (part: MessagePart) => AssetId | undefined;
/** Flatten a rich part for search and model context. */
export declare const richPartContextText: (part: Extract<MessagePart, {
    type: "rich";
}>) => string;
export declare const messagePartsSearchText: (parts: readonly MessagePart[]) => string;
//# sourceMappingURL=domain.d.ts.map