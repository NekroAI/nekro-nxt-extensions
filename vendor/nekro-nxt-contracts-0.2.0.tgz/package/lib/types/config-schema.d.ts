import { z } from 'zod';
import { type JsonValue } from './domain.js';
/**
 * The single configuration format: serialized Schemastery (`Schema.toJSON()`), restricted to the subset the
 * product form can render and the Host can validate without executing Schema callbacks.
 *
 * Supported nodes: object (dict), string, number, natural, percent, boolean, const, union of consts (enum) and
 * array of primitives. `meta.role: 'secret'` marks a write-only credential. NekroNXT reads three extra meta keys:
 * `hint` (help text), `advanced` (collapsed by default) and `visibleWhen` (show only when a sibling equals a value).
 */
export declare const CONFIG_SCHEMA_MAX_BYTES: number;
export declare const ConfigSchemaMetaSchema: z.ZodObject<{
    description: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodRecord<z.ZodString, z.ZodString>]>>;
    hint: z.ZodOptional<z.ZodString>;
    required: z.ZodOptional<z.ZodBoolean>;
    default: z.ZodOptional<z.ZodJSONSchema>;
    role: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    min: z.ZodOptional<z.ZodNumber>;
    max: z.ZodOptional<z.ZodNumber>;
    step: z.ZodOptional<z.ZodNumber>;
    pattern: z.ZodOptional<z.ZodObject<{
        source: z.ZodString;
        flags: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    advanced: z.ZodOptional<z.ZodBoolean>;
    group: z.ZodOptional<z.ZodString>;
    visibleWhen: z.ZodOptional<z.ZodObject<{
        key: z.ZodString;
        equals: z.ZodJSONSchema;
    }, z.core.$strict>>;
}, z.core.$loose>;
export type ConfigSchemaMeta = z.output<typeof ConfigSchemaMetaSchema>;
export type ConfigSchemaNode = {
    readonly type: 'object';
    readonly dict: Readonly<Record<string, ConfigSchemaNode>>;
    readonly meta?: ConfigSchemaMeta | undefined;
} | {
    readonly type: 'string' | 'number' | 'natural' | 'percent' | 'boolean';
    readonly meta?: ConfigSchemaMeta | undefined;
} | {
    readonly type: 'const';
    readonly value: JsonValue;
    readonly meta?: ConfigSchemaMeta | undefined;
} | {
    readonly type: 'union';
    readonly list: readonly ConfigSchemaNode[];
    readonly meta?: ConfigSchemaMeta | undefined;
} | {
    readonly type: 'array';
    readonly inner: ConfigSchemaNode;
    readonly meta?: ConfigSchemaMeta | undefined;
};
export declare const ConfigSchemaNodeSchema: z.ZodType<ConfigSchemaNode>;
/** A whole configuration document: always an object at the root. */
export declare const ConfigSchemaDocumentSchema: z.ZodType<ConfigSchemaNode, unknown, z.core.$ZodTypeInternals<ConfigSchemaNode, unknown>> & z.ZodType<{
    readonly type: "object";
    readonly dict: Readonly<Record<string, ConfigSchemaNode>>;
    readonly meta?: ConfigSchemaMeta | undefined;
}, unknown, z.core.$ZodTypeInternals<{
    readonly type: "object";
    readonly dict: Readonly<Record<string, ConfigSchemaNode>>;
    readonly meta?: ConfigSchemaMeta | undefined;
}, unknown>>;
export type ConfigSchemaDocument = Extract<ConfigSchemaNode, {
    readonly type: 'object';
}>;
export declare const EMPTY_CONFIG_SCHEMA: ConfigSchemaDocument;
export type ConfigFieldKind = 'string' | 'number' | 'boolean' | 'enum' | 'secret' | 'array' | 'object';
export interface ConfigField {
    readonly key: string;
    readonly kind: ConfigFieldKind;
    readonly title: string;
    readonly hint?: string;
    readonly required: boolean;
    readonly default?: JsonValue;
    readonly advanced: boolean;
    readonly group?: string;
    readonly options?: readonly {
        readonly value: JsonValue;
        readonly label: string;
    }[];
    readonly node: ConfigSchemaNode;
}
export declare const configDescription: (meta: ConfigSchemaMeta | undefined) => string | undefined;
export declare const configFieldKind: (node: ConfigSchemaNode) => ConfigFieldKind;
export declare const configFields: (document: ConfigSchemaDocument) => readonly ConfigField[];
export declare const configSecretKeys: (document: ConfigSchemaDocument) => readonly string[];
export interface ConfigValidationIssue {
    readonly path: string;
    readonly message: string;
}
/**
 * Validates a configuration value against a document and fills declared defaults. Secret fields are not part of the
 * stored value; callers pass them through the credential store instead.
 */
export declare const validateConfigValue: (document: ConfigSchemaDocument, value: JsonValue | undefined, options?: {
    readonly skipKeys?: readonly string[];
}) => {
    readonly value: Readonly<Record<string, JsonValue>>;
    readonly issues: readonly ConfigValidationIssue[];
};
/** Throws the first validation issue as a user-readable error. */
export declare const parseConfigValue: (document: ConfigSchemaDocument, value: JsonValue | undefined, options?: {
    readonly skipKeys?: readonly string[];
}) => Readonly<Record<string, JsonValue>>;
interface FieldOptions<Value extends JsonValue> {
    readonly hint?: string;
    readonly default?: Value;
    readonly required?: boolean;
    readonly advanced?: boolean;
    readonly group?: string;
}
/** Builds serialized Schemastery documents without depending on the Schemastery runtime. */
export declare const configSchema: {
    readonly object: (dict: Readonly<Record<string, ConfigSchemaNode>>) => ConfigSchemaDocument;
    readonly string: (title: string, options?: FieldOptions<string> & {
        readonly multiline?: boolean;
    }) => ConfigSchemaNode;
    readonly secret: (title: string, options?: Omit<FieldOptions<string>, "default">) => ConfigSchemaNode;
    readonly number: (title: string, options?: FieldOptions<number> & {
        readonly min?: number;
        readonly max?: number;
        readonly integer?: boolean;
    }) => ConfigSchemaNode;
    readonly boolean: (title: string, options?: FieldOptions<boolean>) => ConfigSchemaNode;
    readonly enum: (title: string, choices: readonly {
        readonly value: string | number;
        readonly label: string;
    }[], options?: FieldOptions<string | number>) => ConfigSchemaNode;
};
export {};
//# sourceMappingURL=config-schema.d.ts.map