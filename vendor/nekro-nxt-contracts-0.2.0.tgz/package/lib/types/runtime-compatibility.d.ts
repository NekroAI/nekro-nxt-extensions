import { z } from 'zod';
export declare const RuntimeCompatibilityDiagnosticSchema: z.ZodObject<{
    objectKind: z.ZodEnum<{
        agent: "agent";
        "model-provider": "model-provider";
        extension: "extension";
        "dsh-plugin": "dsh-plugin";
        adapter: "adapter";
        "client-page": "client-page";
    }>;
    objectId: z.ZodString;
    objectVersion: z.ZodString;
    configurationRevision: z.ZodString;
    runtimeFingerprint: z.ZodString;
    status: z.ZodEnum<{
        checking: "checking";
        compatible: "compatible";
        isolated: "isolated";
    }>;
    phase: z.ZodEnum<{
        configuration: "configuration";
        dependency: "dependency";
        build: "build";
        load: "load";
        render: "render";
        restore: "restore";
        dispose: "dispose";
    }>;
    reason: z.ZodOptional<z.ZodString>;
    retryable: z.ZodBoolean;
    checkedAt: z.ZodNumber;
}, z.core.$strict>;
export type RuntimeCompatibilityDiagnostic = z.infer<typeof RuntimeCompatibilityDiagnosticSchema>;
export declare const HostUpgradeSummarySchema: z.ZodObject<{
    runtimeVersion: z.ZodString;
    sessionCompatibilityId: z.ZodString;
    backupId: z.ZodOptional<z.ZodString>;
    resetContexts: z.ZodBoolean;
    diagnostics: z.ZodArray<z.ZodObject<{
        objectKind: z.ZodEnum<{
            agent: "agent";
            "model-provider": "model-provider";
            extension: "extension";
            "dsh-plugin": "dsh-plugin";
            adapter: "adapter";
            "client-page": "client-page";
        }>;
        objectId: z.ZodString;
        objectVersion: z.ZodString;
        configurationRevision: z.ZodString;
        runtimeFingerprint: z.ZodString;
        status: z.ZodEnum<{
            checking: "checking";
            compatible: "compatible";
            isolated: "isolated";
        }>;
        phase: z.ZodEnum<{
            configuration: "configuration";
            dependency: "dependency";
            build: "build";
            load: "load";
            render: "render";
            restore: "restore";
            dispose: "dispose";
        }>;
        reason: z.ZodOptional<z.ZodString>;
        retryable: z.ZodBoolean;
        checkedAt: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type HostUpgradeSummary = z.infer<typeof HostUpgradeSummarySchema>;
//# sourceMappingURL=runtime-compatibility.d.ts.map