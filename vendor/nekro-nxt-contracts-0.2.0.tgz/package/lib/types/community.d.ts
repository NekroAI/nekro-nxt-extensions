import { z } from 'zod';
/**
 * NekroNXT 社区在本机的投影。Host 代理社区开放接口并把结果归一到这些结构；社区新增的字段在 Host 处丢弃，
 * 不直接透传给页面。审查状态与社区 `ReviewStatus` 一致。
 */
export declare const COMMUNITY_REVIEW_STATUSES: readonly ["pending", "reviewing", "passed", "passed_with_notes", "flagged", "held", "risk_confirmed", "rejected", "incomplete"];
export declare const CommunityReviewStatusSchema: z.ZodEnum<{
    pending: "pending";
    reviewing: "reviewing";
    passed: "passed";
    passed_with_notes: "passed_with_notes";
    flagged: "flagged";
    held: "held";
    risk_confirmed: "risk_confirmed";
    rejected: "rejected";
    incomplete: "incomplete";
}>;
export type CommunityReviewStatus = z.output<typeof CommunityReviewStatusSchema>;
export declare const CommunityGradeSchema: z.ZodEnum<{
    A: "A";
    B: "B";
    C: "C";
    D: "D";
}>;
export declare const CommunityReleaseIdSchema: z.ZodString;
export declare const CommunityAccountSchema: z.ZodObject<{
    handle: z.ZodString;
    displayName: z.ZodString;
    avatarUrl: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export type CommunityAccount = z.output<typeof CommunityAccountSchema>;
export declare const CommunityEnvironmentSchema: z.ZodEnum<{
    production: "production";
    staging: "staging";
    development: "development";
}>;
export type CommunityEnvironment = z.output<typeof CommunityEnvironmentSchema>;
export declare const CommunityStatusSchema: z.ZodObject<{
    communityUrl: z.ZodString;
    environment: z.ZodNullable<z.ZodEnum<{
        production: "production";
        staging: "staging";
        development: "development";
    }>>;
    account: z.ZodNullable<z.ZodObject<{
        handle: z.ZodString;
        displayName: z.ZodString;
        avatarUrl: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    signedInAt: z.ZodNullable<z.ZodNumber>;
    updatesAvailable: z.ZodNumber;
}, z.core.$strict>;
export type CommunityStatus = z.output<typeof CommunityStatusSchema>;
export declare const CommunityPermissionItemSchema: z.ZodObject<{
    key: z.ZodString;
    level: z.ZodEnum<{
        normal: "normal";
        elevated: "elevated";
        high: "high";
    }>;
    label: z.ZodString;
    detail: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type CommunityPermissionItem = z.output<typeof CommunityPermissionItemSchema>;
export declare const CommunityReleaseSchema: z.ZodObject<{
    id: z.ZodString;
    reviewStatus: z.ZodEnum<{
        pending: "pending";
        reviewing: "reviewing";
        passed: "passed";
        passed_with_notes: "passed_with_notes";
        flagged: "flagged";
        held: "held";
        risk_confirmed: "risk_confirmed";
        rejected: "rejected";
        incomplete: "incomplete";
    }>;
    grade: z.ZodNullable<z.ZodEnum<{
        A: "A";
        B: "B";
        C: "C";
        D: "D";
    }>>;
    permissions: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        level: z.ZodEnum<{
            normal: "normal";
            elevated: "elevated";
            high: "high";
        }>;
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    packageSize: z.ZodNumber;
    requiresSdk: z.ZodNullable<z.ZodNumber>;
    notes: z.ZodString;
    createdAt: z.ZodNumber;
}, z.core.$strict>;
export type CommunityRelease = z.output<typeof CommunityReleaseSchema>;
/** 社区为官方扩展保留的发布者标识：官方扩展由多位官方成员维护，对外不显示个人账号。 */
export declare const COMMUNITY_OFFICIAL_HANDLE = "nekro-nxt";
/** 发布者的展示文字：官方扩展显示「NekroNXT 官方」，其余显示 @账号。 */
export declare const communityPublisherLabel: (handle: string) => string;
export declare const CommunityExtensionSummarySchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    scope: z.ZodEnum<{
        agent: "agent";
        "host-adapter": "host-adapter";
        "host-ui": "host-ui";
    }>;
    displayName: z.ZodString;
    summary: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    official: z.ZodBoolean;
    publisher: z.ZodObject<{
        handle: z.ZodString;
        displayName: z.ZodString;
        avatarUrl: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    latest: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        reviewStatus: z.ZodEnum<{
            pending: "pending";
            reviewing: "reviewing";
            passed: "passed";
            passed_with_notes: "passed_with_notes";
            flagged: "flagged";
            held: "held";
            risk_confirmed: "risk_confirmed";
            rejected: "rejected";
            incomplete: "incomplete";
        }>;
        grade: z.ZodNullable<z.ZodEnum<{
            A: "A";
            B: "B";
            C: "C";
            D: "D";
        }>>;
        permissions: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            level: z.ZodEnum<{
                normal: "normal";
                elevated: "elevated";
                high: "high";
            }>;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        packageSize: z.ZodNumber;
        requiresSdk: z.ZodNullable<z.ZodNumber>;
        notes: z.ZodString;
        createdAt: z.ZodNumber;
    }, z.core.$strict>>;
    downloads: z.ZodNumber;
    updatedAt: z.ZodNumber;
    pageUrl: z.ZodString;
}, z.core.$strict>;
export type CommunityExtensionSummary = z.output<typeof CommunityExtensionSummarySchema>;
export declare const CommunityExtensionDetailSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    scope: z.ZodEnum<{
        agent: "agent";
        "host-adapter": "host-adapter";
        "host-ui": "host-ui";
    }>;
    displayName: z.ZodString;
    summary: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    official: z.ZodBoolean;
    publisher: z.ZodObject<{
        handle: z.ZodString;
        displayName: z.ZodString;
        avatarUrl: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    latest: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        reviewStatus: z.ZodEnum<{
            pending: "pending";
            reviewing: "reviewing";
            passed: "passed";
            passed_with_notes: "passed_with_notes";
            flagged: "flagged";
            held: "held";
            risk_confirmed: "risk_confirmed";
            rejected: "rejected";
            incomplete: "incomplete";
        }>;
        grade: z.ZodNullable<z.ZodEnum<{
            A: "A";
            B: "B";
            C: "C";
            D: "D";
        }>>;
        permissions: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            level: z.ZodEnum<{
                normal: "normal";
                elevated: "elevated";
                high: "high";
            }>;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        packageSize: z.ZodNumber;
        requiresSdk: z.ZodNullable<z.ZodNumber>;
        notes: z.ZodString;
        createdAt: z.ZodNumber;
    }, z.core.$strict>>;
    downloads: z.ZodNumber;
    updatedAt: z.ZodNumber;
    pageUrl: z.ZodString;
    description: z.ZodString;
    sourceUrl: z.ZodNullable<z.ZodString>;
    review: z.ZodNullable<z.ZodObject<{
        status: z.ZodEnum<{
            pending: "pending";
            reviewing: "reviewing";
            passed: "passed";
            passed_with_notes: "passed_with_notes";
            flagged: "flagged";
            held: "held";
            risk_confirmed: "risk_confirmed";
            rejected: "rejected";
            incomplete: "incomplete";
        }>;
        grade: z.ZodNullable<z.ZodEnum<{
            A: "A";
            B: "B";
            C: "C";
            D: "D";
        }>>;
        summary: z.ZodNullable<z.ZodString>;
        highlights: z.ZodArray<z.ZodObject<{
            severity: z.ZodString;
            title: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CommunityExtensionDetail = z.output<typeof CommunityExtensionDetailSchema>;
export declare const CommunityEndpointSchema: z.ZodObject<{
    url: z.ZodString;
    source: z.ZodEnum<{
        environment: "environment";
        default: "default";
        setting: "setting";
    }>;
    defaultUrl: z.ZodString;
    environmentUrl: z.ZodNullable<z.ZodString>;
    insecure: z.ZodBoolean;
}, z.core.$strict>;
export type CommunityEndpoint = z.output<typeof CommunityEndpointSchema>;
export declare const CommunitySourceSchema: z.ZodObject<{
    kind: z.ZodLiteral<"community">;
    communityUrl: z.ZodString;
    releaseId: z.ZodString;
    publisherHandle: z.ZodString;
    installedAt: z.ZodNumber;
}, z.core.$strict>;
export type CommunitySource = z.output<typeof CommunitySourceSchema>;
export declare const CommunityInstalledItemSchema: z.ZodObject<{
    extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    displayName: z.ZodString;
    revisionId: z.ZodString;
    source: z.ZodObject<{
        kind: z.ZodLiteral<"community">;
        communityUrl: z.ZodString;
        releaseId: z.ZodString;
        publisherHandle: z.ZodString;
        installedAt: z.ZodNumber;
    }, z.core.$strict>;
    sameCommunity: z.ZodBoolean;
    found: z.ZodBoolean;
    delisted: z.ZodBoolean;
    delistedReason: z.ZodNullable<z.ZodString>;
    releaseWithdrawn: z.ZodBoolean;
    latest: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        reviewStatus: z.ZodEnum<{
            pending: "pending";
            reviewing: "reviewing";
            passed: "passed";
            passed_with_notes: "passed_with_notes";
            flagged: "flagged";
            held: "held";
            risk_confirmed: "risk_confirmed";
            rejected: "rejected";
            incomplete: "incomplete";
        }>;
        grade: z.ZodNullable<z.ZodEnum<{
            A: "A";
            B: "B";
            C: "C";
            D: "D";
        }>>;
        permissions: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            level: z.ZodEnum<{
                normal: "normal";
                elevated: "elevated";
                high: "high";
            }>;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        packageSize: z.ZodNumber;
        requiresSdk: z.ZodNullable<z.ZodNumber>;
        notes: z.ZodString;
        createdAt: z.ZodNumber;
    }, z.core.$strict>>;
    updateAvailable: z.ZodBoolean;
    addedPermissions: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        level: z.ZodEnum<{
            normal: "normal";
            elevated: "elevated";
            high: "high";
        }>;
        label: z.ZodString;
        detail: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CommunityInstalledItem = z.output<typeof CommunityInstalledItemSchema>;
export declare const CommunityInstalledSchema: z.ZodObject<{
    checkedAt: z.ZodNullable<z.ZodNumber>;
    items: z.ZodArray<z.ZodObject<{
        extensionId: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
        displayName: z.ZodString;
        revisionId: z.ZodString;
        source: z.ZodObject<{
            kind: z.ZodLiteral<"community">;
            communityUrl: z.ZodString;
            releaseId: z.ZodString;
            publisherHandle: z.ZodString;
            installedAt: z.ZodNumber;
        }, z.core.$strict>;
        sameCommunity: z.ZodBoolean;
        found: z.ZodBoolean;
        delisted: z.ZodBoolean;
        delistedReason: z.ZodNullable<z.ZodString>;
        releaseWithdrawn: z.ZodBoolean;
        latest: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            reviewStatus: z.ZodEnum<{
                pending: "pending";
                reviewing: "reviewing";
                passed: "passed";
                passed_with_notes: "passed_with_notes";
                flagged: "flagged";
                held: "held";
                risk_confirmed: "risk_confirmed";
                rejected: "rejected";
                incomplete: "incomplete";
            }>;
            grade: z.ZodNullable<z.ZodEnum<{
                A: "A";
                B: "B";
                C: "C";
                D: "D";
            }>>;
            permissions: z.ZodArray<z.ZodObject<{
                key: z.ZodString;
                level: z.ZodEnum<{
                    normal: "normal";
                    elevated: "elevated";
                    high: "high";
                }>;
                label: z.ZodString;
                detail: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            packageSize: z.ZodNumber;
            requiresSdk: z.ZodNullable<z.ZodNumber>;
            notes: z.ZodString;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
        updateAvailable: z.ZodBoolean;
        addedPermissions: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            level: z.ZodEnum<{
                normal: "normal";
                elevated: "elevated";
                high: "high";
            }>;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const CommunityMyExtensionSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "ExtensionId", "out">;
    scope: z.ZodEnum<{
        agent: "agent";
        "host-adapter": "host-adapter";
        "host-ui": "host-ui";
    }>;
    displayName: z.ZodString;
    summary: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    official: z.ZodBoolean;
    publisher: z.ZodObject<{
        handle: z.ZodString;
        displayName: z.ZodString;
        avatarUrl: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    latest: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        reviewStatus: z.ZodEnum<{
            pending: "pending";
            reviewing: "reviewing";
            passed: "passed";
            passed_with_notes: "passed_with_notes";
            flagged: "flagged";
            held: "held";
            risk_confirmed: "risk_confirmed";
            rejected: "rejected";
            incomplete: "incomplete";
        }>;
        grade: z.ZodNullable<z.ZodEnum<{
            A: "A";
            B: "B";
            C: "C";
            D: "D";
        }>>;
        permissions: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            level: z.ZodEnum<{
                normal: "normal";
                elevated: "elevated";
                high: "high";
            }>;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        packageSize: z.ZodNumber;
        requiresSdk: z.ZodNullable<z.ZodNumber>;
        notes: z.ZodString;
        createdAt: z.ZodNumber;
    }, z.core.$strict>>;
    downloads: z.ZodNumber;
    updatedAt: z.ZodNumber;
    pageUrl: z.ZodString;
    releases: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        reviewStatus: z.ZodEnum<{
            pending: "pending";
            reviewing: "reviewing";
            passed: "passed";
            passed_with_notes: "passed_with_notes";
            flagged: "flagged";
            held: "held";
            risk_confirmed: "risk_confirmed";
            rejected: "rejected";
            incomplete: "incomplete";
        }>;
        grade: z.ZodNullable<z.ZodEnum<{
            A: "A";
            B: "B";
            C: "C";
            D: "D";
        }>>;
        permissions: z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            level: z.ZodEnum<{
                normal: "normal";
                elevated: "elevated";
                high: "high";
            }>;
            label: z.ZodString;
            detail: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        packageSize: z.ZodNumber;
        requiresSdk: z.ZodNullable<z.ZodNumber>;
        notes: z.ZodString;
        createdAt: z.ZodNumber;
        withdrawn: z.ZodBoolean;
    }, z.core.$strict>>;
    delisted: z.ZodBoolean;
    delistedReason: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export type CommunityMyExtension = z.output<typeof CommunityMyExtensionSchema>;
export declare const COMMUNITY_REVIEW_DIMENSIONS: readonly ["security", "transparency", "reliability", "context_cost", "usability", "maintainability", "compliance"];
export declare const COMMUNITY_REVIEW_DIMENSION_LABELS: Readonly<Record<(typeof COMMUNITY_REVIEW_DIMENSIONS)[number], string>>;
/** 作者看到的完整审查报告。 */
export declare const CommunityReviewReportSchema: z.ZodObject<{
    releaseId: z.ZodString;
    status: z.ZodEnum<{
        pending: "pending";
        reviewing: "reviewing";
        passed: "passed";
        passed_with_notes: "passed_with_notes";
        flagged: "flagged";
        held: "held";
        risk_confirmed: "risk_confirmed";
        rejected: "rejected";
        incomplete: "incomplete";
    }>;
    grade: z.ZodNullable<z.ZodEnum<{
        A: "A";
        B: "B";
        C: "C";
        D: "D";
    }>>;
    deterministic: z.ZodArray<z.ZodObject<{
        severity: z.ZodEnum<{
            info: "info";
            warning: "warning";
            risk: "risk";
            block: "block";
        }>;
        title: z.ZodString;
        detail: z.ZodString;
        file: z.ZodOptional<z.ZodString>;
        line: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    ai: z.ZodNullable<z.ZodObject<{
        summary: z.ZodString;
        verdict: z.ZodString;
        grade: z.ZodEnum<{
            A: "A";
            B: "B";
            C: "C";
            D: "D";
        }>;
        dimensions: z.ZodArray<z.ZodObject<{
            key: z.ZodEnum<{
                security: "security";
                transparency: "transparency";
                reliability: "reliability";
                context_cost: "context_cost";
                usability: "usability";
                maintainability: "maintainability";
                compliance: "compliance";
            }>;
            grade: z.ZodEnum<{
                A: "A";
                B: "B";
                C: "C";
                D: "D";
            }>;
            notes: z.ZodString;
        }, z.core.$strict>>;
        findings: z.ZodArray<z.ZodObject<{
            dimension: z.ZodEnum<{
                security: "security";
                transparency: "transparency";
                reliability: "reliability";
                context_cost: "context_cost";
                usability: "usability";
                maintainability: "maintainability";
                compliance: "compliance";
            }>;
            severity: z.ZodEnum<{
                info: "info";
                warning: "warning";
                risk: "risk";
                suggestion: "suggestion";
                critical: "critical";
            }>;
            title: z.ZodString;
            detail: z.ZodString;
            file: z.ZodOptional<z.ZodString>;
            line: z.ZodOptional<z.ZodNumber>;
            suggestion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        exploitability: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    model: z.ZodNullable<z.ZodString>;
    error: z.ZodNullable<z.ZodString>;
    decisions: z.ZodArray<z.ZodObject<{
        decision: z.ZodString;
        note: z.ZodString;
        by: z.ZodString;
        createdAt: z.ZodNumber;
    }, z.core.$strict>>;
    finishedAt: z.ZodNullable<z.ZodNumber>;
    reportUrl: z.ZodString;
}, z.core.$strict>;
export type CommunityReviewReport = z.output<typeof CommunityReviewReportSchema>;
/** 安装者看到的审查标签：只描述审查发现，不做「安全」担保。 */
export declare const communityReviewLabel: (status: CommunityReviewStatus) => {
    readonly tone: "neutral" | "ok" | "accent" | "warn" | "bad";
    readonly label: string;
};
//# sourceMappingURL=community.d.ts.map